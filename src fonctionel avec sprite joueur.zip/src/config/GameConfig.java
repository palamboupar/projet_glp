package config;
/**
 * Game configuration class
 * started : 29/01/2025
 * last modified : 30/01/2025
 * @author PALEOLOGOS amael
 * @version 0.1
 * 
 */

public class GameConfig {
	public static final int WINDOW_WIDTH = 900;
	public static final int WINDOW_HEIGHT = 900;
	public static final int MAP_WIDTH = 800;
	public static final int MAP_HEIGHT = 800;
	
	public static final int BLOCK_SIZE = 40;
	
	public static final int LINE_COUNT = MAP_HEIGHT / BLOCK_SIZE;
	public static final int COLUMN_COUNT = MAP_WIDTH / BLOCK_SIZE;
	
	public static final int GAME_SPEED = 500;

}

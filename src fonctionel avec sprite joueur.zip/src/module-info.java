/**
 * 
 */
/**
 * 
 */
module GLP_RPG_2 {
	requires java.desktop;
}
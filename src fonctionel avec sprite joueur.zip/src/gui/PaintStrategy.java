package gui;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import config.GameConfig;
import engine.map.Tile;
import engine.map.Map;
import engine.player.PlayerEntity;
import engine.mobile.Enemy;
import engine.staticObject.Wall;
import engine.process.Utility;

public class PaintStrategy {
	public void paint(Map map, Graphics graphics) {
		int blockSize = GameConfig.BLOCK_SIZE;
		Tile[][] tiles = map.getTiles();

		for (int lineIndex = 0; lineIndex < map.getLineCount(); lineIndex++) {
			for (int columnIndex = 0; columnIndex < map.getColumnCount(); columnIndex++) {
				Tile tile = tiles[lineIndex][columnIndex];

				if ((lineIndex + columnIndex) % 2 == 0) {
					graphics.setColor(Color.GRAY);
					graphics.fillRect(tile.getColumn() * blockSize, tile.getLine() * blockSize, blockSize, blockSize);
				}
			}
		}
	}

	public void paint(PlayerEntity player, Graphics graphics) {
		Tile position = player.getPosition();
		int lastMovement = player.getLM();
		int blockSize = GameConfig.BLOCK_SIZE;

		int y = position.getLine();
		int x = position.getColumn();
		switch (lastMovement) {
		case 0:{
			graphics.drawImage(Utility.readImage("src/images/playerLeft.png"),x * blockSize, y * blockSize, blockSize, blockSize,null);
			break;
			}
		case 1:{
			graphics.drawImage(Utility.readImage("src/images/playerRight.png"),x * blockSize, y * blockSize, blockSize, blockSize,null);
			break;
			}
		case 2:{
			graphics.drawImage(Utility.readImage("src/images/playerUp.png"),x * blockSize, y * blockSize, blockSize, blockSize,null);
			break;
			}
		case 3:{
			graphics.drawImage(Utility.readImage("src/images/playerDown.png"),x * blockSize, y * blockSize, blockSize, blockSize,null);
			break;
			}
		}
	}
	public void paintE(ArrayList<Enemy> enemies, Graphics graphics) {
		for (Enemy enemy : enemies) {

			int blockSize = GameConfig.BLOCK_SIZE;

			int y = enemy.getPosition().getLine();
			int x = enemy.getPosition().getColumn();

			graphics.setColor(Color.RED);
			graphics.fillOval(x * blockSize, y * blockSize, blockSize, blockSize);
		}
	}


	public void paintW(ArrayList<Wall> walls, Graphics graphics) {
		for (Wall wall : walls) {

			int blockSize = GameConfig.BLOCK_SIZE;

			int y = wall.getPosition().getLine();
			int x = wall.getPosition().getColumn();

			graphics.setColor(Color.BLACK);
			graphics.fillRect(x * blockSize, y * blockSize, blockSize, blockSize);
		}
	}
}

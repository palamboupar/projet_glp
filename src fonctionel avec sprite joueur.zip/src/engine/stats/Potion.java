package engine.stats;

import java.util.ArrayList;

public class Potion extends Item {
	public Potion(String name, ArrayList<Stat> itemStats, int price) {
		super(name, itemStats, price);
	}
}

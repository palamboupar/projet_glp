package engine.stats;

import java.util.ArrayList;

public class EnemyStats {
	private String type;
	private ArrayList<Stat> enemyStats;
	private ArrayList<Item> enemyLoot;
	private int enemyXp;
	private int enemyGold;
	
	public EnemyStats(String type, ArrayList<Stat> enemyStats, ArrayList<Item> enemyLoot, int enemyXp, int enemyGold) {
		this.type=type;
		this.enemyStats=enemyStats;
		this.enemyLoot=enemyLoot;
		this.enemyXp=enemyXp;
		this.enemyGold=enemyGold;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ArrayList<Stat> getEnemyStats() {
		return enemyStats;
	}

	public void setEnemyStats(ArrayList<Stat> enemyStats) {
		this.enemyStats = enemyStats;
	}

	public ArrayList<Item> getEnemyLoot() {
		return enemyLoot;
	}

	public void setEnemyLoot(ArrayList<Item> enemyLoot) {
		this.enemyLoot = enemyLoot;
	}

	public int getEnemyXp() {
		return enemyXp;
	}

	public void setEnemyXp(int enemyXp) {
		this.enemyXp = enemyXp;
	}

	public int getEnemyGold() {
		return enemyGold;
	}

	public void setEnemyGold(int enemyGold) {
		this.enemyGold = enemyGold;
	}
}

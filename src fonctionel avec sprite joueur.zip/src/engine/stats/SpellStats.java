package engine.stats;

public class SpellStats {
	private String name;
	private int manaCost;
	private int effectArea;
	
	public SpellStats(String name, int manaCost, int effectArea) {
		this.name=name;
		this.manaCost=manaCost;
		this.effectArea=effectArea;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getManaCost() {
		return manaCost;
	}

	public void setManaCost(int manaCost) {
		this.manaCost = manaCost;
	}

	public int getEffectArea() {
		return effectArea;
	}

	public void setEffectArea(int effectArea) {
		this.effectArea = effectArea;
	}
}

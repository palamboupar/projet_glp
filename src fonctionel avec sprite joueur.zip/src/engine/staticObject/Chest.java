package engine.staticObject;

import java.util.ArrayList;
import engine.map.Tile;
import engine.stats.*;

public class Chest extends StaticElement{
	private ArrayList<Item> chestLoot;
	private int chestGold;
	
	public Chest(Tile position, ArrayList<Item> chestLoot, int chestGold) {
		super(position);
		this.chestLoot=chestLoot;
		this.chestGold=chestGold;
	}

	public ArrayList<Item> getChestLoot() {
		return chestLoot;
	}

	public void setChestLoot(ArrayList<Item> chestLoot) {
		this.chestLoot = chestLoot;
	}

	public int getChestGold() {
		return chestGold;
	}

	public void setChestGold(int chestGold) {
		this.chestGold = chestGold;
	}
}

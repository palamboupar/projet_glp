package engine.staticObject;

import engine.map.Tile;

public class Wall extends StaticElement{
	public Wall(Tile position) {
		super(position);
	}
}
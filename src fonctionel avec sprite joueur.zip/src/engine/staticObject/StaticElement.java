package engine.staticObject;

import engine.map.Tile;

public abstract class StaticElement {
	private Tile position;
	
	public StaticElement(Tile position){
		this.position=position;
	}
	public Tile getPosition() {
		return position;
	}

	public void setPosition(Tile position) {
		this.position = position;
	}
}

package engine.player;

import engine.stats.*;
import java.util.ArrayList;

public class PlayerStats {
	private String type;
	private ArrayList<Stat> playerStats;
	private ArrayList<Equipement> equipements;
	
	public PlayerStats(String type, ArrayList<Stat> playerStats, ArrayList<Equipement> equipements) {
		this.type=type;
		this.playerStats=playerStats;
		this.equipements=equipements;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ArrayList<Stat> getPlayerStats() {
		return playerStats;
	}

	public void setPlayerStats(ArrayList<Stat> playerStats) {
		this.playerStats = playerStats;
	}

	public ArrayList<Equipement> getEquipements() {
		return equipements;
	}

	public void setEquipements(ArrayList<Equipement> equipements) {
		this.equipements = equipements;
	}
}

package engine.player;

import engine.map.Tile;

public class PlayerEntity {
	private Tile position;
	private int lastMovement; //0=left 1=right 2=up 3=down
	
	public PlayerEntity(Tile position) {
		this.position=position;
		lastMovement=2;
	}

	public Tile getPosition() {
		return position;
	}
	
	public void setPosition(Tile position) {
		this.position=position;
	}

	public int getLM() {
		return lastMovement;
	}

	public void setLM(int lastMovement) {
		this.lastMovement = lastMovement;
	}
	
}

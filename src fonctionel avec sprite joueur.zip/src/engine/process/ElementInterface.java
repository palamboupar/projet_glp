package engine.process;

import java.util.ArrayList;

import engine.mobile.Enemy;
import engine.player.PlayerEntity;
import engine.staticObject.Wall;

public interface ElementInterface {

	void setP(PlayerEntity player);

	void moveLeftPlayer();

	void moveRightPlayer();
	
	void moveUpPlayer();
	
	void moveDownPlayer();
	
	void add(Wall w);
	void add(Enemy e);

	void nextRound();
	
	ArrayList<Wall> getW();
	
	ArrayList<Enemy> getE();
	
	PlayerEntity getP();
}

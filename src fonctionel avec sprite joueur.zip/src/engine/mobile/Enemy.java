package engine.mobile;

import engine.map.Tile;

public class Enemy extends MobileElement{
	public Enemy(Tile position) {
		super(position);
	}
}

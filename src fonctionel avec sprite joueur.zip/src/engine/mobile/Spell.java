package engine.mobile;

import engine.map.Tile;

public class Spell extends MobileElement{
	public Spell(Tile position) {
		super(position);
	}
}

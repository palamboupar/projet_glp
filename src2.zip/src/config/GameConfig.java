package config;
/**
 * Game configuration class
 * started : 29/01/2025
 * last modified : 30/01/2025
 * @author PALEOLOGOS amael
 * @version 0.1
 * 
 */

public class GameConfig {
	public static final int WINDOW_WIDTH = 1000;
	public static final int WINDOW_HEIGHT = 1000;
	public static final int MAP_WIDTH = 1000;
	public static final int MAP_HEIGHT = 1000;
	
	public static final int TILE_SIZE = 50;
	
	public static final int LINE_COUNT = MAP_HEIGHT / TILE_SIZE;
	public static final int COLUMN_COUNT = MAP_WIDTH / TILE_SIZE;
	
	public static final int GAME_SPEED = 400;

}

package engine.process;


import config.GameConfig;
import engine.map.Tile;
import engine.mobile.Enemy;
import engine.map.Map;
import engine.player.PlayerEntity;
import engine.staticObject.Wall;

/**
 * class for the map
 * started : 30/01/2025
 * last modified : 30/01/2025
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 * 
 */
public class GameBuilder {
	public static Map buildMap() {
		return new Map(GameConfig.LINE_COUNT, GameConfig.COLUMN_COUNT);
	}
	public static ElementInterface buildInitMobile(Map map) {
		ElementInterface manager = new ElementManager(map);
		
		initializeWall(manager);
		initializeSlime(manager);
		intializePlayer(map, manager);
		
		return manager;
	}
	
	private static void initializeWall(ElementInterface manager) {
		for (int lineIndex=0;lineIndex < GameConfig.LINE_COUNT; lineIndex++) {
			Wall w=new Wall(new Tile(lineIndex,0));
			manager.add(w);
			Wall x=new Wall(new Tile(lineIndex,GameConfig.COLUMN_COUNT-1));
			manager.add(x);
		}
		for (int columnIndex = 0; columnIndex < GameConfig.COLUMN_COUNT; columnIndex++) {
			Wall w=new Wall(new Tile(0,columnIndex));
			manager.add(w);
			Wall x=new Wall(new Tile(GameConfig.LINE_COUNT-1,columnIndex));
			manager.add(x);
		}
	}
	private static void initializeSlime(ElementInterface manager) {
		for(int i=Utility.getRandomNumber(5, 10);i>0;i--){
			int x = Utility.getRandomNumber(1,GameConfig.LINE_COUNT-2);
			int y = Utility.getRandomNumber(1,GameConfig.COLUMN_COUNT-2);
			Enemy e=new Enemy(new Tile(x,y),"Slime");
			manager.add(e);
		}
	}
	
	private static void intializePlayer(Map map, ElementInterface manager) {
		Tile tile = map.getTile(GameConfig.LINE_COUNT - 2, (GameConfig.COLUMN_COUNT - 1) / 2);
		PlayerEntity player = new PlayerEntity(tile);
		manager.setP(player);
	}


}

package engine.process;

import java.util.ArrayList;
import java.util.Iterator;

import engine.map.*;
import engine.mobile.Enemy;
import engine.player.PlayerEntity;
import engine.staticObject.Wall;

/**
 * class for the map
 * started : 30/01/2025
 * last modified : 30/01/2025
 * @author PALEOLOGOS amael & BOUCHELAGHEM Ali
 * @version 0.1
 * 
 */
public class ElementManager implements ElementInterface {
	private Map map;
	private ArrayList<Wall> walls = new ArrayList<Wall>();
	private PlayerEntity player;
	private ArrayList<Enemy> enemies = new ArrayList<Enemy>();
	int t=0;
	private ArrayList<Tile> attackZone=new ArrayList<Tile>();
	
	public ElementManager(Map map) {
		this.map = map;
	}
	
	public void nextRound() {
		t=t+1;
		moveEnemy(t);
	}
	
	public void setP(PlayerEntity player) {
		this.player=player;
	}
	
	public Boolean iterWall(Tile t) {
		Iterator<Wall> iter = walls.iterator();
	    while ( iter.hasNext() ) {
	    	Tile tile = iter.next().getPosition();
	    	if (tile.getLine()==t.getLine() && tile.getColumn()==t.getColumn()) {
	    		return true;
	    	}
	    }
	    return false;
	}
	
	public void moveLeftPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine(), position.getColumn() - 1);

		if (iterWall(wantedPosition)==false) {
			player.setPosition(wantedPosition);
			player.setLM(0);
		}
	}

	@Override
	public void moveRightPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine(), position.getColumn() + 1);

		if (iterWall(wantedPosition)==false) {
			player.setPosition(wantedPosition);
			player.setLM(1);
		}
	}
	@Override
	public void moveUpPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine()-1, position.getColumn());

		if (iterWall(wantedPosition)==false) {
			player.setPosition(wantedPosition);
			player.setLM(2);
		}
	}
	@Override
	public void moveDownPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine()+1, position.getColumn() );

		if (iterWall(wantedPosition)==false) {
			player.setPosition(wantedPosition);
			player.setLM(3);
		}
	}
	public void add(Wall w) {
		walls.add(w);
	}
	public void add(Enemy e) {
		enemies.add(e);
	}

	public ArrayList<Wall> getW() {
		return walls;
	}

	public ArrayList<Enemy> getE() {
		return enemies;
	}
	public PlayerEntity getP() {
		return player;
	}
	public void moveEnemy(int t) {
		for (int i=enemies.size()-1;i>=0;i--) {
			Enemy e=enemies.get(i);
			if (t%e.getStats().getEnemyStats().get(1).getValue()==0) {
				enemies.remove(i);
				int move=Utility.getRandomNumber(0,3);
				switch(move) {
				case 0:
					Tile l=new Tile(e.getPosition().getLine(),e.getPosition().getColumn()-1);
					if (iterWall(l)==false) {
						e.setPosition(l);
					}
					break;
				case 1:
					Tile r=new Tile(e.getPosition().getLine(),e.getPosition().getColumn()+1);
					if (iterWall(r)==false) {
						e.setPosition(r);
					}
					break;
				case 2:
					Tile u=new Tile(e.getPosition().getLine()-1,e.getPosition().getColumn());
					if (iterWall(u)==false) {
						e.setPosition(u);
					}
					break;
				case 3:
					Tile d=new Tile(e.getPosition().getLine()+1,e.getPosition().getColumn());
					if (iterWall(d)==false) {
						e.setPosition(d);
					}
					break;
				}
				enemies.add(i, e);	
			}
		}
	}
	public void attack() {
		Tile position=player.getPosition();
		int LM=player.getLM();
		int range=player.getStats().getEquipements().get(0).getRange();
		attackZone.clear();
		switch (LM) {
		case 0:{
			attackZone.add(new Tile(position.getLine(),position.getColumn()-range));
			break;
			}
		case 1:{
			attackZone.add(new Tile(position.getLine(),position.getColumn()+range));
			break;
			}
		case 2:{
			attackZone.add(new Tile(position.getLine()-range,position.getColumn()));
			break;
			}
		case 3:{
			attackZone.add(new Tile(position.getLine()+range,position.getColumn()));
			break;
			}
		}
		for (Tile tile : attackZone) {
			ArrayList<Enemy> toRemove=new ArrayList<Enemy>();
			Iterator<Enemy> iter = enemies.iterator();
		    while ( iter.hasNext() ) {
		    	Enemy e = iter.next();
		    	if (tile.getLine()==e.getPosition().getLine() && tile.getColumn()==e.getPosition().getColumn()) {
		    		toRemove.add(e);
		    	}
		    }  
		    for(Enemy e : toRemove) {
		    	enemies.remove(e);
		    }	
		    toRemove.clear();
		}
		attackZone.clear();
	}
		
}

package engine.map;

public class Map {
	private Tile[][]tiles;
	private int lineCount;
	private int columnCount;
	
	public Map(int lineCount, int columnCount) {
		init(lineCount, columnCount);

		for (int lineIndex = 0; lineIndex < lineCount; lineIndex++) {
			for (int columnIndex = 0; columnIndex < columnCount; columnIndex++) {
				tiles[lineIndex][columnIndex] = new Tile(lineIndex, columnIndex);
			}
		}
	}
	private void init(int lineCount, int columnCount) {
		this.lineCount = lineCount;	
		this.columnCount = columnCount;

		tiles = new Tile[lineCount][columnCount];
		
	
	}
	public Tile getTile(int line, int column) {
		return tiles[line][column];
	}
	public Tile[][] getTiles() {
		return tiles;
	}
	public void setTiles(Tile[][] tiles) {
		this.tiles = tiles;
	}
	public int getLineCount() {
		return lineCount;
	}
	public void setLineCount(int lineCount) {
		this.lineCount = lineCount;
	}
	public int getColumnCount() {
		return columnCount;
	}
	public void setColumnCount(int columnCount) {
		this.columnCount = columnCount;
	}

}

package engine.staticObject;

import java.util.ArrayList;

import engine.map.Tile;
import engine.stats.*;

public class Shop extends StaticElement {
	private ArrayList<Item> stock;
	private int shopGold;
	
	public Shop(Tile position, ArrayList<Item> stock, int shopGold) {
		super(position);
		this.stock=stock;
		this.shopGold=shopGold;
		
	}

	public ArrayList<Item> getStock() {
		return stock;
	}

	public void setStock(ArrayList<Item> stock) {
		this.stock = stock;
	}

	public int getShopGold() {
		return shopGold;
	}

	public void setShopGold(int shopGold) {
		this.shopGold = shopGold;
	}
	

}

package engine.mobile;

import engine.map.Tile;
import engine.stats.EnemyStatistics;

public class Enemy extends MobileElement{
	private EnemyStatistics stats;
	public Enemy(Tile position,String type) {
		super(position);
		this.stats=new EnemyStatistics(type) ;
	}
	public EnemyStatistics getStats() {
		return stats;
	}
	public void setStats(EnemyStatistics stats) {
		this.stats = stats;
	}
	
}

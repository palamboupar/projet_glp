package engine.player;

import engine.stats.*;
import java.util.ArrayList;

public class PlayerStatistics {
	private String type;
	private ArrayList<Stat> playerStats;
	private ArrayList<Item> equipements;
	
	public PlayerStatistics(String type,ArrayList<Stat> playerStats, ArrayList<Item> equipements) {
		this.type=type;
		this.playerStats=playerStats;
		this.equipements=equipements;
	}
	public PlayerStatistics() {//test class
		this.type="test";
		Stat HP=new Stat("HP",10);
		ArrayList<Stat> tmpStats=new ArrayList <Stat>();
		tmpStats.add(HP);
		this.playerStats=tmpStats;
		ArrayList<Stat> weaponStats=new ArrayList<Stat>();
		Stat DMG=new Stat("DMG",1);
		weaponStats.add(DMG);
		Weapon baseWeapon=new Weapon("baseWeapon",weaponStats,1,1);
		ArrayList<Item> equipementsTmp=new ArrayList<Item>();
		equipementsTmp.add(baseWeapon);
		this.equipements=equipementsTmp;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ArrayList<Stat> getPlayerStats() {
		return playerStats;
	}

	public void setPlayerStats(ArrayList<Stat> playerStats) {
		this.playerStats = playerStats;
	}

	public ArrayList<Item> getEquipements() {
		return equipements;
	}

	public void setEquipements(ArrayList<Item> equipements) {
		this.equipements = equipements;
	}
}

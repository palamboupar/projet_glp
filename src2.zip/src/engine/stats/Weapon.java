package engine.stats;

import java.util.ArrayList;


public class Weapon extends Item {
	private int range;
	public Weapon(String name, ArrayList<Stat> itemStats, int price,int range) {
		super(name, itemStats, price);
		this.range=range;
	}
	public int getRange() {
		return range;
	}
	public void setRange(int range) {
		this.range = range;
	}
	
}

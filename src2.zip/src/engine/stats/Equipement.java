package engine.stats;

import java.util.ArrayList;

public class Equipement extends Item {
	public Equipement(String name, ArrayList<Stat> itemStats, int price) {
		super(name, itemStats, price);
	}
	public int getRange() {
		return 0;
	}
}

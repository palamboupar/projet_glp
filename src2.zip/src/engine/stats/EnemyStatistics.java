package engine.stats;

import java.util.ArrayList;

public class EnemyStatistics {
	private String type;
	private ArrayList<Stat> enemyStats;
	private ArrayList<Item> enemyLoot;
	private int enemyXp;
	private int enemyGold;
	
	public EnemyStatistics(String type, ArrayList<Stat> enemyStats, ArrayList<Item> enemyLoot, int enemyXp, int enemyGold) {
		this.type=type;
		this.enemyStats=enemyStats;
		this.enemyLoot=enemyLoot;
		this.enemyXp=enemyXp;
		this.enemyGold=enemyGold;
	}
	public EnemyStatistics(String type) {
		switch (type){
		case "Slime":{
			this.type=type;
			Stat HP=new Stat("HP",1);
			Stat Speed=new Stat("Speed",2);
			ArrayList<Stat> tmpStats=new ArrayList <Stat>();
			tmpStats.add(HP);
			tmpStats.add(Speed);
			this.enemyStats=tmpStats;
			this.enemyLoot=null;
			this.enemyXp=1;
			this.enemyGold=1;
			
			}
		}
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ArrayList<Stat> getEnemyStats() {
		return enemyStats;
	}

	public void setEnemyStats(ArrayList<Stat> enemyStats) {
		this.enemyStats = enemyStats;
	}

	public ArrayList<Item> getEnemyLoot() {
		return enemyLoot;
	}

	public void setEnemyLoot(ArrayList<Item> enemyLoot) {
		this.enemyLoot = enemyLoot;
	}

	public int getEnemyXp() {
		return enemyXp;
	}

	public void setEnemyXp(int enemyXp) {
		this.enemyXp = enemyXp;
	}

	public int getEnemyGold() {
		return enemyGold;
	}

	public void setEnemyGold(int enemyGold) {
		this.enemyGold = enemyGold;
	}
}

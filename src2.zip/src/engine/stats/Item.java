package engine.stats;

import java.util.ArrayList;

public abstract class Item {
	private String name;
	private ArrayList<Stat> itemStats;
	private int price;
	
	public Item(String name, ArrayList<Stat> itemStats, int price) {
		this.name=name;
		this.itemStats=itemStats;
		this.price=price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Stat> getItemStats() {
		return itemStats;
	}

	public void setItemStats(ArrayList<Stat> itemStats) {
		this.itemStats = itemStats;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public abstract int getRange();
}

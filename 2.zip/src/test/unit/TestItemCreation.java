package test.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import engine.process.factory.ItemFactory;
import engine.stats.*;

/**
 * Unit test class for testing the creation of items using the ItemFactory.
 * <p>
 * This class contains tests for verifying the correct creation of various items,
 * including checking if the properties of the created items match the expected values.
 * 
 * @author PALEOLOGOS Amaël & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class TestItemCreation {
    private Item item;

    /**
     * Initializes the test items before each test is run.
     * This method is annotated with {@code @Before} to ensure it is executed
     * before each test case to prepare the test environment.
     */
    @Before
    public void initItem() {
       item = ItemFactory.woodenHelmet();
    }
    @Test
    public void testItem() {
    	assertNotNull(item);
    	assertTrue(item instanceof Equipement);
    	assertEquals(item.getType(),0);
    }
}

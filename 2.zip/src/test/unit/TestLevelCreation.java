package test.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import engine.map.Map;
import engine.process.ElementInterface;
import engine.process.Lvl1Builder;
import engine.process.Lvl2Builder;
import engine.process.Lvl3Builder;

/**
 * 
 * @author PALEOLOGOS Amaël & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class TestLevelCreation {
	private Map map1;
	private ElementInterface manager1;
	private Map map2;
	private ElementInterface manager2;
	private Map map3;
	private ElementInterface manager3;
    @Before
    public void initLvl() {
    	map1 = Lvl1Builder.buildMap();
		manager1 = Lvl1Builder.buildInitMobile(map1,"warior");
		manager2=manager1;
		map2 = Lvl2Builder.buildMap();
        manager2 = Lvl2Builder.buildMobile(map2, manager2);
        manager3=manager2;
        map3 = Lvl3Builder.buildMap();
        manager3 = Lvl3Builder.buildMobile(map3, manager3);
    }
    @Test
    public void testLvl1() {
    	assertNotNull(manager1.getB());
    	assertNotNull(manager1.getP());
    	assertNotNull(manager1.getChests());
    	assertEquals(manager1.getChests().size(),2);
    	assertNotNull(manager1.getShop());
    	assertNotNull(manager1.getW());
    	assertNotNull(manager1.getE());
    }
    @Test
    public void testLvl2() {
    	assertNotNull(manager2.getB());
    	assertNotNull(manager2.getP());
    	assertNotNull(manager2.getChests());
    	assertEquals(manager2.getChests().size(),2);
    	assertNotNull(manager2.getShop());
    	assertNotNull(manager2.getW());
    	assertNotNull(manager2.getE());
    }
    @Test
    public void testLvl3() {
    	assertNotNull(manager3.getB());
    	assertNotNull(manager3.getP());
    	assertNotNull(manager3.getChests());
    	assertEquals(manager3.getChests().size(),2);
    	assertNotNull(manager3.getShop());
    	assertNotNull(manager3.getW());
    	assertNotNull(manager3.getE());
    }
}
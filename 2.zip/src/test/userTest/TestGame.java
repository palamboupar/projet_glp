package test.userTest;

import gui.StartMenu;

/**
 * A simple test class to launch the RPG Start Menu GUI.
 * This class serves as an entry point for testing the user interface by
 * opening the start menu of the RPG game. It creates an instance of 
 * {@link StartMenu} and displays the menu to the user.
 * It is used to verify if the GUI is correctly displayed and that 
 * the initial start menu functions as expected.
 * 
 * @author PALEOLOGOS Amaël & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class TestGame {
    /**
     * The main method which serves as the entry point for launching the game.
     * <p>
     * This method initializes the {@link StartMenu} class with the title "RPG".
     * 
     * @param args Command-line arguments (not used in this test)
     */
    public static void main(String[] args) {
        new StartMenu("RPG");
    }
}

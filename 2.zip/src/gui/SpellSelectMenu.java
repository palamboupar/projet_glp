package gui;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SpellSelectMenu extends JDialog {

    private static final long serialVersionUID = 1L;
    @SuppressWarnings("unchecked")
	private final JComboBox<String>[] spellSelectors = new JComboBox[3];

    private final String[] spellNames = {
        "Fireball", "Explosion", "Fire Zone", "Volcano Blast",    // Fire
        "Ice Spike", "Frost", "Tornado", "Snowfall",              // Water
        "Minor Heal", "Major Heal", "Invincibility", "Second Chance" // Heal
    };

    private final int[] spellLevels = {
        1, 3, 5, 10,  // Fire
        1, 3, 5, 10,  // Water
        1, 3, 5, 10   // Heal
    };

    private final String[] spellCategories = {
        "fire", "fire", "fire", "fire",    // Fire
        "water", "water", "water", "water",// Water
        "heal", "heal", "heal", "heal"     // Heal
    };

    public SpellSelectMenu(GameGUI parent, int lvl, List<String> selectedCategories) {
        super(parent, "Choisir les sorts", true);
        setLayout(new BorderLayout());
        setUndecorated(true);

        List<String> availableSpells = new ArrayList<>();
        for (int i = 0; i < spellNames.length; i++) {
            if (lvl >= spellLevels[i] && selectedCategories.contains(spellCategories[i])) {
                availableSpells.add(spellNames[i]);
            }
        }

        if (availableSpells.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Aucun sort disponible pour votre niveau et catégorie.", "Erreur", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        JPanel selectorPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        for (int i = 0; i < 3; i++) {
            JLabel label = new JLabel("Sort pour touche " + (i + 1) + " :");
            spellSelectors[i] = new JComboBox<>(availableSpells.toArray(new String[0]));
            selectorPanel.add(label);
            selectorPanel.add(spellSelectors[i]);
        }

        JButton confirmBtn = new JButton("Valider");
        confirmBtn.addActionListener(e -> {
            int[] selected = new int[3];
            for (int i = 0; i < 3; i++) {
                String selectedSpell = (String) spellSelectors[i].getSelectedItem();
                selected[i] = switch (selectedSpell) {
                    case "Fireball" -> 1;
                    case "Explosion" -> 2;
                    case "Fire Zone" -> 3;
                    case "Volcano Blast" -> 4;
                    case "Ice Spike" -> 5;
                    case "Frost" -> 6;
                    case "Tornado" -> 7;
                    case "Snowfall" -> 8;
                    case "Minor Heal" -> 9;
                    case "Major Heal" -> 10;
                    case "Invincibility" -> 11;
                    case "Second Chance" -> 12;
                    default -> 1;
                };
            }
            parent.setSelectedSpells(selected);
            dispose();
            GameGUI.runing = true;
        });

        add(new JLabel("Attribuez un sort à chaque touche :", JLabel.CENTER), BorderLayout.NORTH);
        add(selectorPanel, BorderLayout.CENTER);
        add(confirmBtn, BorderLayout.SOUTH);

        setSize(350, 250);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
    }
}

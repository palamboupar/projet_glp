package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import config.GameConfig;
import engine.map.Map;
import engine.process.Lvl1Builder;
import engine.process.Lvl2Builder;
import engine.process.Lvl3Builder;
import engine.process.factory.SpellFactory;
import engine.process.ElementInterface;

/**
 * This class represents the main game window and graphical interface of the RPG.
 * It handles the rendering of the map and various panels such as stats, inventory,
 * and equipment. It also controls the game loop and manages user input.
 * 
 * @author PALEOLOGOS Amaël & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class GameGUI extends JFrame implements Runnable {

	private static final long serialVersionUID = 1L;
	public static boolean runing=false;
	public static int death;
	private Map map;
	private final static Dimension preferredSize = new Dimension(GameConfig.WINDOW_WIDTH, GameConfig.WINDOW_HEIGHT);
	private ElementInterface manager;
	private GameDisplay dashboard;
	private StatsPanel statsPanel;
	private CapacityPanel capacityPanel;
	private InfoPanel infoPanel;
	private InventoryPanel invPanel;
	private EquipementPanel equipPanel;
	private int level=1;
	private Container contentPane;
	private int shopTimer=0;
	private int[] selectedSpells = {0,0,0};
	private ArrayList<String> selectedCategories = new ArrayList<>();


	/**
	 * Constructor for the GameGUI class
	 * @param title the window title
	 * @param type the selected player type
	 */
	public GameGUI(String title,String type) {
		super(title);
		init(type);
	}

	/**
	 * Initializes the game GUI, panels and starts game components
	 * @param type the selected player type
	 */
	private void init(String type) {
		death=0;
		contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		KeyControls keyControls = new KeyControls();
		addKeyListener(keyControls);
		setFocusable(true);
		requestFocusInWindow();
		
		map = Lvl1Builder.buildMap();
		manager = Lvl1Builder.buildInitMobile(map,type);
		dashboard = new GameDisplay(map, manager,level);
		statsPanel = new StatsPanel();
		capacityPanel = new CapacityPanel();
		infoPanel = new InfoPanel();
		invPanel = new InventoryPanel(manager);
		equipPanel = new EquipementPanel(manager);
		
		MouseControls mouseControls = new MouseControls();
		dashboard.addMouseListener(mouseControls);
		dashboard.setPreferredSize(preferredSize);
		contentPane.add(dashboard, BorderLayout.CENTER);
		
		JPanel downPanel= new JPanel();
		downPanel.setLayout(new GridLayout(1,3));
		downPanel.setBackground(Color.GRAY);
		downPanel.add(statsPanel);
		downPanel.add(infoPanel);
		downPanel.add(capacityPanel);
		contentPane.add(downPanel, BorderLayout.SOUTH);
		
		JPanel leftPanel= new JPanel();
		leftPanel.setLayout(new GridLayout(2,1));
		leftPanel.setBackground(Color.GRAY);
		leftPanel.add(equipPanel);
		leftPanel.add(invPanel);
		contentPane.add(leftPanel, BorderLayout.EAST);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		setPreferredSize(preferredSize);
		setResizable(true);
		statsPanel.updateValuesStats(manager.getP());
		capacityPanel.updateSpells(selectedSpells);
		new MagicSelectionMenu(this, type).setVisible(true);
	}
	public void setSelectedCategories(ArrayList<String> categories) {
	    this.selectedCategories = categories;
	}


	/**
	 * Main game loop that updates components and transitions between levels.
	 */
	@Override
	public void run() {
	    while (true) {
	        if (runing) {
	            try {
	                Thread.sleep(GameConfig.GAME_SPEED);
	            } catch (InterruptedException e) {
	                System.out.println(e.getMessage());
	            }
	            if(death==1) {
	        		death=0;
	        		runing=false;
	        		new DeathMenu(GameGUI.this);
	        		
	        	}
	            if (shopTimer>0) {
	            	shopTimer-=1;
	            }
	            manager.nextRound();
	            dashboard.repaint();
	            statsPanel.updateValuesStats(manager.getP());
	            equipPanel.updateValuesEquip();
	            invPanel.updateValuesInv();
	            infoPanel.updateValuesInfo(manager.getP());
	            if (manager.shopAccess()==true&&shopTimer==0) {
	            	shopTimer=5;
	            	runing=false;
	            	new ShopMenu(manager).setVisible(true);
	            }
	            if (manager.getLvlUp()==1) {
	            	manager.setLvlUp(0);
	            	new LevelUpDialog(GameGUI.this, manager);
	            }
	            if (manager.getB() == null) {
	                switch (level) {
	                	case 0:
	                		break;
	                    case 1:
	                        level += 1;
	                        map = Lvl2Builder.buildMap();
	                        manager = Lvl2Builder.buildMobile(map, manager);
	                        break;
	                    case 2:
	                        level += 1;
	                        map = Lvl3Builder.buildMap();
	                        manager = Lvl3Builder.buildMobile(map, manager);
	                        break;
	                    case 3:
	                        System.out.println("fin");
	                        runing = false;
	                        new EndGameMenu(GameGUI.this);
	                        level=0;
	                        break;
	                    default:
	                        System.out.println("Niveau inconnu !");
	                        break;
	                }
	
	                contentPane.remove(dashboard);
	                dashboard = new GameDisplay(map, manager, level);
	                dashboard.addMouseListener(new MouseControls());
	                dashboard.setPreferredSize(preferredSize);
	                contentPane.add(dashboard, BorderLayout.CENTER);
	                contentPane.revalidate();
	            }
	        } else {
	            try {
	                Thread.sleep(100);
	            } catch (InterruptedException e) {
	                System.out.println(e.getMessage());
	            }
	        }
	    }
	}
	
	private String getSpellCategory(int spellId) {
	    if (spellId >= 1 && spellId <= 4) return "fire";
	    if (spellId >= 5 && spellId <= 8) return "water";
	    if (spellId >= 9 && spellId <= 12) return "heal";
	    return "";
	}

	private int getRequiredLevel(int spellId) {
	    if (spellId == 1 || spellId == 5 || spellId == 9) return 1;
	    if (spellId == 2 || spellId == 6 || spellId == 10) return 3;
	    if (spellId == 3 || spellId == 7 || spellId == 11) return 5;
	    if (spellId == 4 || spellId == 8 || spellId == 12) return 10;
	    return 99; // impossible sinon
	}
	
	private void useSelectedSpell(int index) {
	    int spellId = selectedSpells[index];
	    if (spellId == 0) {
	        return;
	    }

	    String category = getSpellCategory(spellId);
	    int requiredLevel = getRequiredLevel(spellId);

	    if (!selectedCategories.contains(category)) {
	        JOptionPane.showMessageDialog(this, 
	            "You didn't select the category: " + category, 
	            "Magic Category Error", 
	            JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    if (manager.getP().getStats().getLevel() < requiredLevel) {
	        JOptionPane.showMessageDialog(this, 
	            "You need to be level " + requiredLevel + " to use this magic!", 
	            "Level Error", 
	            JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    switch (spellId) {
	        case 1:
	            manager.useSpell(SpellFactory.fireball(manager.getP()));
	            break;
	        case 2:
	            manager.useSpell(SpellFactory.explosion(manager.getP()));
	            break;
	        case 3:
	            manager.useSpell(SpellFactory.firezone(manager.getP()));
	            break;
	        case 4:
	            manager.useSpell(SpellFactory.volcanoBlast(manager.getP()));
	            break;
	        case 5:
	            manager.useSpell(SpellFactory.iceSpike(manager.getP()));
	            break;
	        case 6:
	            manager.useSpell(SpellFactory.frost(manager.getP()));
	            break;
	        case 7:
	            manager.useSpell(SpellFactory.tornado(manager.getP()));
	            break;
	        case 8:
	            manager.useSpell(SpellFactory.snowfall(manager.getP()));
	            break;
	        case 9:
	            manager.useSpell(SpellFactory.minorheal(manager.getP()));
	            break;
	        case 10:
	            manager.useSpell(SpellFactory.majorrheal(manager.getP()));
	            break;
	        case 11:
	            manager.useSpell(SpellFactory.invincibility(manager.getP()));
	            break;
	        case 12:
	            manager.useSpell(SpellFactory.secondchance(manager.getP()));
	            JOptionPane.showMessageDialog(this, 
	    	            "You can only use this spell once", 
	    	            "Spell Info", 
	    	            JOptionPane.PLAIN_MESSAGE);
	            break;
	        default:
	            break;
	    }
	}

	public void setSelectedSpells(int[] newSpells) {
	    this.selectedSpells = newSpells;
	    capacityPanel.updateSpells(selectedSpells);
	    capacityPanel.repaint();
	}

	/**
	 * Handles keyboard input from the user.
	 */
	private class KeyControls implements KeyListener {

		@Override
		public void keyPressed(KeyEvent event) {
			int keyCode = event.getKeyCode();
			if (keyCode == KeyEvent.VK_ESCAPE) {
			    if (runing) {
			        runing = false;
			        new PauseMenu(GameGUI.this);
			    } else {
			        runing = true;
			    }
			    return;
			}

		    if (!runing) {
		        return;
		    }

		    switch (keyCode) {
		        case KeyEvent.VK_Q:
		            manager.moveLeftPlayer();
		            break;
		        case KeyEvent.VK_D:
		            manager.moveRightPlayer();
		            break;
		        case KeyEvent.VK_Z:
		            manager.moveUpPlayer();
		            break;
		        case KeyEvent.VK_S:
		            manager.moveDownPlayer();
		            break;
		        case KeyEvent.VK_E:
		            if (runing) {
		                runing = false;
		                new SpellSelectMenu(GameGUI.this,manager.getP().getStats().getLevel(),selectedCategories);
		            }
		            break;
		        case KeyEvent.VK_1:
		            useSelectedSpell(0);
		            break;
		        case KeyEvent.VK_2:
		            useSelectedSpell(1);
		            break;
		        case KeyEvent.VK_3:
		            useSelectedSpell(2);
		            break;
		        default:
		            break;
		    }
		}

		@Override
		public void keyTyped(KeyEvent e) {

		}

		@Override
		public void keyReleased(KeyEvent e) {

		}
	}

	/**
	 * Handles mouse input from the user.
	 */
	private class MouseControls implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
			if (e.getButton() == MouseEvent.BUTTON1){
				manager.attack();
            } 
			else if (e.getButton() == MouseEvent.BUTTON3){
            	manager.use();
			}
		}

		@Override
		public void mousePressed(MouseEvent e) {
		}

		@Override
		public void mouseReleased(MouseEvent e) {

		}

		@Override
		public void mouseEntered(MouseEvent e) {

		}

		@Override
		public void mouseExited(MouseEvent e) {

		}
	}
}

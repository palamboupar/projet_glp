package gui;

import java.awt.Graphics;
import java.util.ArrayList;
import javax.swing.JPanel;
import engine.map.Map;
import engine.map.Tile;
import engine.player.PlayerEntity;
import engine.mobile.Boss;
import engine.mobile.Enemy;
import engine.staticObject.Chest;
import engine.staticObject.Shop;
import engine.staticObject.Wall;
import engine.process.ElementInterface;

/**
 * This class is responsible for rendering the game map and its elements
 * on the screen. It extends {@link JPanel} to provide a custom drawing
 * surface for the game display.
 * It handles rendering of various game objects such as the player, enemies,
 * walls, boss, attack zones, chests, and the shop using the {@link PaintStrategy}.
 * Based on the level, it loads the appropriate textures for the game elements.
 * 
 * @author PALEOLOGOS Amaël & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class GameDisplay extends JPanel {

    private static final long serialVersionUID = 1L;
    private Map map;  
    private ElementInterface manager;  
    private PaintStrategy paintStrategy = new PaintStrategy(); 

    /**
     * Constructor to initialize the game display with a map, manager, and level.
     * 
     * @param map The game map to be displayed
     * @param manager The manager that controls game elements such as player, enemies, etc.
     * @param level The current game level (1, 2, or 3)
     */
    public GameDisplay(Map map, ElementInterface manager, int level) {
        this.map = map;
        this.manager = manager;
        switch (level) {
        case(1):
            paintStrategy.loadLv1Textures();
            break;
        case(2):
            paintStrategy.loadLv2Textures();
            break;
        case(3):
            paintStrategy.loadLv3Textures();
            break;
        }
    }

    /**
     * Paints the game components to the screen.
     * <p>
     * This method calls the {@link PaintStrategy} to render the map, player, enemies,
     * walls, boss, attack zones, chests, and shop based on the current game state.
     * 
     * @param g The graphics context used for painting
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        paintStrategy.paint(map, g);
        PlayerEntity player = manager.getP();
        paintStrategy.paint(player, g);
        ArrayList<Wall> walls = manager.getW();
        if (walls != null) {
            paintStrategy.paintW(walls, g);
        }
        Boss b = manager.getB();
        if (b != null) {
            paintStrategy.paintB(b, g);
        }
        ArrayList<Enemy> enemies = manager.getE();
        if (enemies != null) {
            paintStrategy.paintE(enemies, g);
        }
        ArrayList<Tile> azeLast = manager.getAZEL();
        paintStrategy.paintAZEL(azeLast, g);
        azeLast.clear();
        manager.setAZEL(azeLast);

        ArrayList<Tile> azLast = manager.getAZL();
        paintStrategy.paintAZ(azLast, g);
        azLast.clear();
        manager.setAZL(azLast);
        
        ArrayList<Tile> azsLast = manager.getAZSL();
        paintStrategy.paintAZSL(azsLast, g);
        azsLast.clear();
        manager.setAZSL(azsLast);
        
        ArrayList<Chest> chests = manager.getChests();
        if (chests != null) {
            paintStrategy.paintC(chests, g);
        }
        Shop shop = manager.getShop();
        paintStrategy.paint(shop, g);
    }
}

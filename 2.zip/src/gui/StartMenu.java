package gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * Class representing the start menu of the RPG game.
 * This menu allows the player to start a new game, resume an existing game, access the menu, or close the application.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class StartMenu extends JFrame {

    private static final long serialVersionUID = 1L;
    private final static Dimension preferredSize = new Dimension(500, 80);
    private JLabel northText;
    private JButton westText;
    private JButton eastText;
    private JButton southText;

    /**
     * Main constructor for the StartMenu class.
     * Initializes the start menu window with buttons and the associated actions.
     * 
     * @param title The title of the window.
     */
    public StartMenu(String title) {
        super(title);
        init();
    }

    /**
     * Initializes the start menu window and its components.
     * Creates and configures the buttons and labels, and assigns actions to each button.
     */
    private void init() {
        Container contentPane = getContentPane();
        contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));
        contentPane.setPreferredSize(preferredSize);

        northText = new JLabel("RPG");
        westText = new JButton("Start");
        eastText = new JButton("Menu");
        southText = new JButton("Close");
        
        add(northText);
        westText.addActionListener(new StartAction());
        add(westText);
        eastText.addActionListener(new MenuAction());
        add(eastText);
        southText.addActionListener(new CloseAction());
        add(southText);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setVisible(true);
        setPreferredSize(preferredSize);
        setResizable(true);
    }

    /**
     * Action listener for the "Start" button.
     * Opens the class selection menu and closes the current start menu.
     */
    private class StartAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new ClassMenu("RPG");
            dispose();
        }
    }

    /**
     * Action listener for the "Menu" button.
     * Currently not implemented but can be used to show additional menu options.
     */
    private class MenuAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
        }
    }

    /**
     * Action listener for the "Close" button.
     * Closes the application when clicked.
     */
    private class CloseAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }
}

package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

import engine.process.ElementInterface;
import engine.stats.Item;

/**
 * Panel class responsible for displaying the player's inventory in the GUI.
 * It allows the user to interact with the inventory by right-clicking to equip or drop items.
 * It also displays the inventory list using a JList component and handles mouse events.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class InventoryPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private JLabel label = new JLabel("Inventory");  
    private JList<Item> itemList;  
    private DefaultListModel<Item> listModel;  
    private JScrollPane scroll;  
    private JPopupMenu contextMenu;  
    private Item selectedItem;  
    private int hoveredIndex = -1;  
    private ElementInterface manager;  

    /**
     * Constructs the InventoryPanel object with the specified game manager.
     * Initializes the layout, list model, mouse listeners, and context menu.
     * 
     * @param manager the game manager handling the player and inventory
     */
    public InventoryPanel(ElementInterface manager) {
        this.manager = manager;
        setLayout(new GridLayout(2, 1));
        setBackground(Color.GRAY);
        add(label);
        listModel = new DefaultListModel<>();
        itemList = new JList<>(listModel);
        itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        itemList.setCellRenderer(new CustomCellRenderer());  
        MouseItem mouseItem = new MouseItem();
        itemList.addMouseMotionListener(mouseItem);
        itemList.addMouseListener(mouseItem);
        scroll = new JScrollPane(itemList);
        add(scroll);

        initContextMenu();  
    }

    /**
     * Initializes the context menu for item interactions, including options to equip or drop items.
     */
    private void initContextMenu() {
        contextMenu = new JPopupMenu();
        JMenuItem equipItem = new JMenuItem("Équiper");  
        JMenuItem dropItem = new JMenuItem("Jeter");  
        contextMenu.add(equipItem);
        contextMenu.add(dropItem);
        equipItem.addActionListener(new EquipItemListener());
        dropItem.addActionListener(new DropItemListener());
    }

    /**
     * Updates the inventory display by clearing the existing list and adding the current inventory items.
     */
    public void updateValuesInv() {
        listModel.clear();
        List<Item> inventory = manager.getP().getStats().getInventory();  
        for (Item item : inventory) {
            listModel.addElement(item);  
        }
    }

    /**
     * Mouse listener class to handle interactions with the inventory list items.
     * It handles mouse movements, item clicks, and hover effects.
     */
    private class MouseItem extends MouseAdapter {

        /**
         * Handles mouse movement events to update the hovered item index.
         * 
         * @param e the mouse event triggered by the user
         */
        @Override
        public void mouseMoved(MouseEvent e) {
            int index = itemList.locationToIndex(e.getPoint());
            if (index != hoveredIndex) {
                hoveredIndex = index;
                itemList.repaint();  
            }
        }

        /**
         * Handles mouse exit events to reset the hovered item index.
         * 
         * @param e the mouse event triggered by the user
         */
        @Override
        public void mouseExited(MouseEvent e) {
            hoveredIndex = -1;  
            itemList.repaint();  
        }

        /**
         * Handles mouse click events. Left-click selects the item, and right-click shows the context menu.
         * 
         * @param e the mouse event triggered by the user
         */
        @Override
        public void mouseClicked(MouseEvent e) {
            if (e.getButton() == MouseEvent.BUTTON1) {
            } else if (e.getButton() == MouseEvent.BUTTON3) {
                int index = itemList.locationToIndex(e.getPoint());
                if (index != -1) {
                    itemList.setSelectedIndex(index);  
                    selectedItem = listModel.getElementAt(index);  
                    contextMenu.show(itemList, e.getX(), e.getY());  
                }
            }
        }
    }

    /**
     * Custom cell renderer for the JList to highlight the hovered item.
     * It changes the background color of the item when hovered.
     */
    private class CustomCellRenderer extends DefaultListCellRenderer {
        private static final long serialVersionUID = 1L;

        /**
         * Customizes the rendering of list cells to highlight the hovered item.
         * 
         * @param list the JList being rendered
         * @param value the value of the item at the given index
         * @param index the index of the item in the list
         * @param isSelected whether the item is selected
         * @param cellHasFocus whether the item has focus
         * @return the component used to render the item
         */
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (index == hoveredIndex) {
                label.setBackground(Color.LIGHT_GRAY);  
            }
            return label;
        }
    }

    /**
     * Action listener for equipping the selected item.
     * It equips the selected item from the inventory.
     */
    private class EquipItemListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (selectedItem != null) {
                manager.equipItem(selectedItem);  
            }
        }
    }

    /**
     * Action listener for dropping the selected item.
     * It removes the selected item from the inventory.
     */
    private class DropItemListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (selectedItem != null) {
                manager.dropItem(selectedItem);  
            }
        }
    }
}

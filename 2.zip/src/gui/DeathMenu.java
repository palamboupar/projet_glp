package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * EndGameMenu displays a modal dialog when the game ends.
 */
public class DeathMenu extends JDialog {

    private static final long serialVersionUID = 1L;

    public DeathMenu(JFrame parent) {
        super(parent, "Fin du Jeu", true);
        setSize(300, 150);
        setUndecorated(true);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(3, 1));

        JLabel label = new JLabel("Vous êtes mort!", JLabel.CENTER);
        JButton menuButton = new JButton("Menu Principal");
        JButton quitButton = new JButton("Quitter");

        menuButton.addActionListener(new MenuButtonListener(parent));
        quitButton.addActionListener(e -> System.exit(0));

        add(label);
        add(menuButton);
        add(quitButton);

        setVisible(true);
    }

    /**
     * Action listener to return to the main menu.
     */
    private class MenuButtonListener implements ActionListener {
        private JFrame parent;

        public MenuButtonListener(JFrame parent) {
            this.parent = parent;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            if (parent != null) parent.dispose();
            new StartMenu("RPG");
        }
    }
}

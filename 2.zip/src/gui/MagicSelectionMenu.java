package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MagicSelectionMenu extends JDialog {

	private static final long serialVersionUID = 1L;
	private ArrayList<String> selectedCategories;
	@SuppressWarnings("unused")
	private String type;

	public MagicSelectionMenu(GameGUI parent, String type) {
		super(parent, "Select Magic", true);
		this.type = type;
		this.selectedCategories = new ArrayList<>();

		setLayout(new BorderLayout());
		setUndecorated(true);

		JLabel instructionLabel = new JLabel("Choose your magic category:");
		instructionLabel.setHorizontalAlignment(SwingConstants.CENTER);
		add(instructionLabel, BorderLayout.NORTH);

		JPanel spellsPanel = new JPanel();
		spellsPanel.setLayout(new GridLayout(3, 1));
		JCheckBox fireBox = new JCheckBox("Fire");
		JCheckBox waterBox = new JCheckBox("Water");
		JCheckBox healBox = new JCheckBox("Heal");
		spellsPanel.add(fireBox);
		spellsPanel.add(waterBox);
		spellsPanel.add(healBox);
		add(spellsPanel, BorderLayout.CENTER);

		JButton validateButton = new JButton("Validate");
		validateButton.addActionListener(new ValidateButtonListener(parent, fireBox, waterBox, healBox));
		add(validateButton, BorderLayout.SOUTH);

		setSize(300, 250);
		setLocationRelativeTo(parent);
	}

	/**
	 * Gère la validation de la sélection de magie.
	 */
	private class ValidateButtonListener implements ActionListener {
		private GameGUI parent;
		private JCheckBox fireBox, waterBox, healBox;

		public ValidateButtonListener(GameGUI parent, JCheckBox fireBox, JCheckBox waterBox, JCheckBox healBox) {
			this.parent = parent;
			this.fireBox = fireBox;
			this.waterBox = waterBox;
			this.healBox = healBox;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			int count = 0;
			if (fireBox.isSelected()) count++;
			if (waterBox.isSelected()) count++;
			if (healBox.isSelected()) count++;

			if ((type.equalsIgnoreCase("warior") && count != 1) || (type.equalsIgnoreCase("mage") && count != 2)) {
				JOptionPane.showMessageDialog(MagicSelectionMenu.this,
						type.equalsIgnoreCase("warior") ? "Warior must select exactly ONE magic!" : "Mage must select exactly TWO magics!",
						"Selection Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			if (fireBox.isSelected()) selectedCategories.add("fire");
			if (waterBox.isSelected()) selectedCategories.add("water");
			if (healBox.isSelected()) selectedCategories.add("heal");

			parent.setSelectedCategories(selectedCategories);
			dispose();
			GameGUI.runing = true;
		}
	}
}
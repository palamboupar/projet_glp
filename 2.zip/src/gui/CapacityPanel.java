package gui;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Panel class that displays capacity-related information in the GUI.
 * It contains labels and is designed to be part of the user interface.
 * The layout of the panel is set as a GridLayout to manage the components.
 * 
 */
public class CapacityPanel extends JPanel {

    private static final long serialVersionUID = 1L;
    
    private JLabel titleLabel = new JLabel("Capacités :");
    private JLabel spell1Label = new JLabel("1 - ");
    private JLabel spell2Label = new JLabel("2 - ");
    private JLabel spell3Label = new JLabel("3 - ");

    public CapacityPanel() {
        setLayout(new GridLayout(4, 1));
        setBackground(Color.GRAY);
        add(titleLabel);
        add(spell1Label);
        add(spell2Label);
        add(spell3Label);
    }

    public void updateSpells(int[] spellIds) {
        spell1Label.setText("1 - " + getSpellName(spellIds[0]));
        spell2Label.setText("2 - " + getSpellName(spellIds[1]));
        spell3Label.setText("3 - " + getSpellName(spellIds[2]));
    }

    private String getSpellName(int id) {
        return switch (id) {
            case 1 -> "Fireball";
            case 2 -> "Explosion";
            case 3 -> "Fire Zone";
            case 4 -> "Volcano Blast";
            case 5 -> "Ice Spike";
            case 6 -> "Frost";
            case 7 -> "Tornado";
            case 8 -> "Snowfall";
            case 9 -> "Minor Heal";
            case 10 -> "Major Heal";
            case 11 -> "Invincibility";
            case 12 -> "Second Chance";
            default -> "Empty";
        };
    }
}
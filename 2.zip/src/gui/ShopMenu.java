package gui;

import javax.swing.*;
import engine.process.ElementInterface;
import engine.stats.Item;
import java.awt.*;
import java.awt.event.*;

/**
 * This class represents the Shop Menu in the game, allowing the player to buy and sell items.
 * It displays the player's inventory and the shop's stock in two separate lists, along with 
 * options to buy, sell, or quit. It updates the display based on the player's gold and the 
 * available stock in the shop.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class ShopMenu extends JFrame {
    private static final long serialVersionUID = 1L;
    private DefaultListModel<Item> playerModel = new DefaultListModel<>();  
    private DefaultListModel<Item> shopModel = new DefaultListModel<>();   
    private JList<Item> playerList = new JList<>(playerModel);  
    private JList<Item> shopList = new JList<>(shopModel);  
    private JButton buyButton = new JButton("Acheter"); 
    private JButton sellButton = new JButton("Vendre"); 
    private JButton quitButton = new JButton("Quitter");  
    private JLabel playerGoldLabel = new JLabel();  
    private JLabel shopGoldLabel = new JLabel();  
    private Item selectedPlayerItem;  
    private Item selectedShopItem;  
    private ElementInterface manager;  

    /**
     * Constructs the ShopMenu, initializing the interface with components like buttons, labels, 
     * and inventory lists. It also sets up event listeners for interactions with the inventory.
     * 
     * @param manager the game manager that handles the player's inventory and shop
     */
    public ShopMenu(ElementInterface manager) {
        this.manager = manager;

        setTitle("Magasin");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setUndecorated(true); 
        setLayout(new BorderLayout());
        JPanel topPanel = new JPanel(new GridLayout(1, 2));
        topPanel.add(playerGoldLabel);
        topPanel.add(shopGoldLabel);
        add(topPanel, BorderLayout.NORTH);
        JPanel mainPanel = new JPanel(new GridLayout(1, 2));
        JPanel playerPanel = createInventoryPanel("Inventaire Joueur", playerList, sellButton);
        JPanel shopPanel = createInventoryPanel("Magasin", shopList, buyButton);
        mainPanel.add(playerPanel);
        mainPanel.add(shopPanel);
        add(mainPanel, BorderLayout.CENTER);
        JPanel bottomPanel = new JPanel();
        quitButton.addActionListener(e -> {
            GameGUI.runing = true;
            dispose();  
        });
        bottomPanel.add(quitButton);
        add(bottomPanel, BorderLayout.SOUTH);
        playerList.setCellRenderer(new ShopCellRenderer());
        shopList.setCellRenderer(new ShopCellRenderer());
        playerList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        shopList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        playerList.addMouseListener(new PlayerItemClickListener());
        shopList.addMouseListener(new ShopItemClickListener());
        buyButton.addActionListener(new BuyItemListener());
        sellButton.addActionListener(new SellItemListener());
        refresh();  
        setVisible(true);
    }

    /**
     * Creates a panel for displaying either the player's inventory or the shop's stock.
     * It includes a title, a list of items, and a button to interact with the items.
     * 
     * @param title the title of the panel (e.g., "Inventaire Joueur" or "Magasin")
     * @param list the list to display the items
     * @param button the button to trigger buy or sell actions
     * @return the created panel with the list and button
     */
    private JPanel createInventoryPanel(String title, JList<Item> list, JButton button) {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel(title, JLabel.CENTER);
        JScrollPane scroll = new JScrollPane(list);
        panel.add(label, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(button, BorderLayout.SOUTH);
        return panel;
    }

    /**
     * Refreshes the contents of the shop menu, updating the player's inventory and the shop's stock.
     * It also updates the labels displaying the player's and shop's gold amounts.
     */
    private void refresh() {
        playerModel.clear();
        shopModel.clear();

        for (Item item : manager.getP().getStats().getInventory()) {
            playerModel.addElement(item);  
        }
        for (Item item : manager.getShop().getStock()) {
            shopModel.addElement(item);  
        }

        playerGoldLabel.setText("Or du joueur : " + manager.getP().getStats().getGold() + " ⚜");
        shopGoldLabel.setText("Or du magasin : " + manager.getShop().getShopGold() + " ⚖");
    }

    /**
     * Custom cell renderer for the inventory lists, displaying item names and prices.
     */
    private static class ShopCellRenderer extends DefaultListCellRenderer {
        private static final long serialVersionUID = 1L;

        /**
         * Renders the item list cells, showing the item name and price.
         * 
         * @param list the list being rendered
         * @param value the value of the item at the given index
         * @param index the index of the item in the list
         * @param isSelected whether the item is selected
         * @param cellHasFocus whether the item has focus
         * @return the component used to render the item
         */
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Item) {
                Item item = (Item) value;
                label.setText(item.getName() + " - " + item.getPrice() + " or");  
            }
            return label;
        }
    }

    /**
     * Mouse listener for handling player item selection.
     * It updates the selected player item when clicked.
     */
    private class PlayerItemClickListener extends MouseAdapter {
        @Override
        public void mouseClicked(MouseEvent e) {
            selectedPlayerItem = playerList.getSelectedValue();  
        }
    }

    /**
     * Mouse listener for handling shop item selection.
     * It updates the selected shop item when clicked.
     */
    private class ShopItemClickListener extends MouseAdapter {
        @Override
        public void mouseClicked(MouseEvent e) {
            selectedShopItem = shopList.getSelectedValue();  
        }
    }

    /**
     * Action listener for the buy button. It buys the selected item from the shop.
     */
    private class BuyItemListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (selectedShopItem != null) {
                manager.buyItem(selectedShopItem);  
                refresh(); 
            }
        }
    }

    /**
     * Action listener for the sell button. It sells the selected item from the player's inventory.
     */
    private class SellItemListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (selectedPlayerItem != null) {
                manager.sellItem(selectedPlayerItem);  
                refresh();  
            }
        }
    }
}

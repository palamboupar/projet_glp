package gui;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import engine.process.ElementInterface;
import engine.stats.Equipement;
import engine.stats.Item;
import engine.stats.Potion;

/**
 * Panel class that displays the player's equipment in the GUI.
 * The panel includes labels for various equipment slots such as main weapon, secondary weapon, and armor.
 * Users can right-click on a label to unequip the corresponding item.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class EquipementPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    private JLabel nameLabel = new JLabel("Equipment : ");
    private JLabel weaponLabel = new JLabel("Arme principale :");
    private JLabel clothesLabel = new JLabel("Tenue:");
    private JLabel secondaryLabel = new JLabel("Secondary weapon:");
    private JLabel rightLabel = new JLabel("");
    private JLabel leftLabel = new JLabel("");
    private JLabel upLabel = new JLabel("");
    private JLabel downLabel = new JLabel("");
    private JLabel centerLabel = new JLabel("");
    private JLabel center2Label = new JLabel("");
    private ElementInterface manager;
    private JPopupMenu contextMenu;
    private JLabel selectedLabel;
    private int selectedIndex;

    /**
     * Constructs an EquipementPanel object with the specified manager.
     * Initializes the layout and adds all components to the panel.
     * 
     * @param manager the manager handling the equipment data
     */
    public EquipementPanel(ElementInterface manager) {
        this.manager = manager;
        setLayout(new BorderLayout());
        setBackground(Color.GRAY);
        Border blackline = BorderFactory.createLineBorder(Color.black);
        JPanel northPanel = new JPanel(new GridLayout(3,1));
        northPanel.setBackground(Color.GRAY);
        northPanel.setBorder(blackline);
        northPanel.add(nameLabel);
        northPanel.add(clothesLabel);
        northPanel.add(upLabel);
        JPanel centerPanel = new JPanel(new GridLayout(2,1));
        centerPanel.setBackground(Color.GRAY);
        centerPanel.setBorder(blackline);
        centerPanel.add(centerLabel);
        centerPanel.add(center2Label);
        JPanel southPanel = new JPanel(new GridLayout(1,1));
        southPanel.setBackground(Color.GRAY);
        southPanel.setBorder(blackline);
        southPanel.add(downLabel);
        JPanel eastPanel = new JPanel(new GridLayout(2,1));
        eastPanel.setBackground(Color.GRAY);
        eastPanel.setBorder(blackline);
        eastPanel.add(weaponLabel);
        eastPanel.add(rightLabel);
        JPanel westPanel = new JPanel(new GridLayout(2,1));
        westPanel.setBackground(Color.GRAY);
        westPanel.setBorder(blackline);
        westPanel.add(secondaryLabel);
        westPanel.add(leftLabel);
        add(northPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(southPanel, BorderLayout.SOUTH);
        add(eastPanel, BorderLayout.EAST);
        add(westPanel, BorderLayout.WEST);
        initContextMenu();  
        addRightClickListener(upLabel, 0);
        addRightClickListener(centerLabel, 1);
        addRightClickListener(center2Label, 2);
        addRightClickListener(downLabel, 3);
        addRightClickListener(leftLabel, 4);
        addRightClickListener(rightLabel, -1); 
    }

    /**
     * Initializes the context menu for item interactions, such as unequipping items.
     */
    private void initContextMenu() {
        contextMenu = new JPopupMenu();
        JMenuItem unequipItem = new JMenuItem("déséquiper");
        contextMenu.add(unequipItem);
        unequipItem.addActionListener(new UnequipItemListener());
    }

    /**
     * Adds a right-click listener to the specified label to show the context menu.
     * 
     * @param label the label to add the listener to
     * @param index the index of the equipment slot (or -1 for main weapon)
     */
    private void addRightClickListener(JLabel label, int index) {
        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e) && !label.getText().isEmpty()) {
                    selectedLabel = label;
                    selectedIndex = index;
                    contextMenu.show(label, e.getX(), e.getY());
                }
            }
        });
    }

    /**
     * Listener for unequipping items when selected from the context menu.
     */
    private class UnequipItemListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (selectedLabel != null && selectedIndex >= 0) {
                manager.unequipItem(manager.getP().getStats().getEquipements().get(selectedIndex));
            } else if (selectedIndex == -1) {
                manager.unequipItem(manager.getP().getStats().getPlayerWeapon());
            }
        }
    }

    /**
     * Updates the values displayed for the equipped items.
     */
    public void updateValuesEquip() {
        ArrayList<Item> equip = manager.getP().getStats().getEquipements();
        rightLabel.setText(manager.getP().getStats().getPlayerWeapon().getName());
        
        if (equip.get(0) instanceof Equipement) {
            upLabel.setText(String.valueOf(equip.get(0).getName()));
        } else {
            upLabel.setText("");
        }
        
        if (equip.get(1) instanceof Equipement) {
            centerLabel.setText(String.valueOf(equip.get(1).getName()));
        } else {
            centerLabel.setText("");
        }
        
        if (equip.get(2) instanceof Equipement) {
            center2Label.setText(String.valueOf(equip.get(2).getName()));
        } else {
            center2Label.setText("");
        }
        
        if (equip.get(3) instanceof Equipement) {
            downLabel.setText(String.valueOf(equip.get(3).getName()));
        } else {
            downLabel.setText("");
        }
        
        if (equip.get(4) instanceof Potion) {
            leftLabel.setText(String.valueOf(equip.get(4).getName()));
        } else {
            leftLabel.setText("");
        }
    }
}

package gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * This class represents the class selection menu in the RPG game.
 * The player can choose between different character classes or close the game.
 * 
 * @author PALEOLOGOS Amaël & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class ClassMenu extends JFrame {

	private static final long serialVersionUID = 1L;
	private final static Dimension preferredSize = new Dimension(500, 80);
	private JLabel northText;
	private JButton westText;
	private JButton centerText;
	private JButton eastText;
	private JButton southText;

	/**
	 * Constructor for ClassMenu
	 * @param title the window title
	 */
	public ClassMenu(String title) {
		super(title);
		init();
	}

	/**
	 * Initializes the GUI components and action listeners for each button.
	 */
	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER));
		contentPane.setPreferredSize(preferredSize);

		northText = new JLabel("Choose your class");
		westText = new JButton("warior");
		centerText = new JButton("mage");
		eastText = new JButton("assasin");
		southText = new JButton("close");
		
		add(northText);

		westText.addActionListener(new wariorAction());
		add(westText);

		centerText.addActionListener(new mageAction());
		add(centerText);

		eastText.addActionListener(new assasinAction());
		add(eastText);

		southText.addActionListener(new closeAction());
		add(southText);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		setPreferredSize(preferredSize);
		setResizable(true);
	}

	/**
	 * Action for selecting the "warior" class. Starts the game with that class.
	 */
	private class wariorAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			GameGUI gameMainGUI = new GameGUI("RPG", "warior");
			Thread gameThread = new Thread(gameMainGUI);
			gameThread.start();
			dispose();
		}
	}

	/**
	 * Action for selecting the "mage" class. Starts the game with that class.
	 */
	private class mageAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			GameGUI gameMainGUI = new GameGUI("RPG", "mage");
			Thread gameThread = new Thread(gameMainGUI);
			gameThread.start();
			dispose();
		}
	}

	/**
	 * Action for selecting the "assasin" class. Starts the game with that class.
	 */
	private class assasinAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			GameGUI gameMainGUI = new GameGUI("RPG", "assasin");
			Thread gameThread = new Thread(gameMainGUI);
			gameThread.start();
			dispose();
		}
	}

	/**
	 * Action for closing the application.
	 */
	private class closeAction implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			System.exit(0);
		}
	}
}

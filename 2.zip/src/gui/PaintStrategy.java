package gui;

import java.awt.*;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import config.GameConfig;
import engine.map.Tile;
import engine.map.Map;
import engine.player.PlayerEntity;
import engine.mobile.Boss;
import engine.mobile.Enemy;
import engine.staticObject.Chest;
import engine.staticObject.Shop;
import engine.staticObject.Wall;
import log.LoggerUtility;
import engine.process.Utility;

/**
 * PaintStrategy is responsible for managing and rendering all visual elements of the game map,
 * including the player, enemies, walls, chests, and other static elements. It handles the
 * drawing of textures for different levels and objects on the screen using the Graphics API.
 * This class provides methods to load textures, paint game entities, and update the rendering
 * of the game world dynamically based on the state of the game.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class PaintStrategy {
    private static Logger logger = LoggerUtility.getLogger(PaintStrategy.class, "html");
    private int tileSize;
    private Image warior1 = Utility.readImage("bin/images/warriorLeft.png");
    private Image warior2 = Utility.readImage("bin/images/warriorRight.png");
    private Image warior3 = Utility.readImage("bin/images/warriorUp.png");
    private Image warior4 = Utility.readImage("bin/images/warriorDown.png");
    private Image mage1 = Utility.readImage("bin/images/mageLeft.png");
    private Image mage2 = Utility.readImage("bin/images/mageRight.png");
    private Image mage3 = Utility.readImage("bin/images/mageUp.png");
    private Image mage4 = Utility.readImage("bin/images/mageDown.png");
    private Image assasin1 = Utility.readImage("bin/images/assasinLeft.png");
    private Image assasin2 = Utility.readImage("bin/images/assasinRight.png");
    private Image assasin3 = Utility.readImage("bin/images/assasinUp.png");
    private Image assasin4 = Utility.readImage("bin/images/assasinDown.png");
    private Image floor1;
    private Image floor2;
    private Image wallimg;
    private String enemy1;
    private Image enemy1_1;
    private Image enemy1_2;
    private Image enemy1_3;
    private Image enemy1_4;
    private String enemy2;
    private Image enemy2_1;
    private Image enemy2_2;
    private Image enemy2_3;
    private Image enemy2_4;
    private String enemy3;
    private Image enemy3_1;
    private Image enemy3_2;
    private Image enemy3_3;
    private Image enemy3_4;
    private Image boss;
    private Image chestTexture = Utility.readImage("bin/images/chest.png");
    private Image shopTexture = Utility.readImage("bin/images/shop.png");
    private Color orangeTransparent = new Color(255, 128, 0, 150);
    private Color redTransparent = new Color(255, 0, 0, 50);

    /**
     * Loads textures specific to Level 1.
     */
    public void loadLv1Textures() {
        this.tileSize = GameConfig.TILE_SIZE1;
        this.floor1 = Utility.readImage("bin/images/sol1_niveau_1.png");
        this.floor2 = Utility.readImage("bin/images/sol2_niveau_1.png");
        this.wallimg = Utility.readImage("bin/images/wall_niveau_1.png");
        this.enemy1 = "slime";
        this.enemy1_1 = Utility.readImage("bin/images/slimeLeft.png");
        this.enemy1_2 = Utility.readImage("bin/images/slimeRight.png");
        this.enemy1_3 = Utility.readImage("bin/images/slimeUp.png");
        this.enemy1_4 = Utility.readImage("bin/images/slimeDown.png");
        this.enemy2 = "zombie";
        this.enemy2_1 = Utility.readImage("bin/images/zombieLeft.png");
        this.enemy2_2 = Utility.readImage("bin/images/zombieRight.png");
        this.enemy2_3 = Utility.readImage("bin/images/zombieUp.png");
        this.enemy2_4 = Utility.readImage("bin/images/zombieDown.png");
        this.enemy3 = "ghost";
        this.enemy3_1 = Utility.readImage("bin/images/ghostLeft.png");
        this.enemy3_2 = Utility.readImage("bin/images/ghostRight.png");
        this.enemy3_3 = Utility.readImage("bin/images/ghostUp.png");
        this.enemy3_4 = Utility.readImage("bin/images/ghostDown.png");
        this.boss = Utility.readImage("bin/images/boss1.png");
        logger.info("Level 1 textures loaded");
    }

    /**
     * Loads textures specific to Level 2.
     */
    public void loadLv2Textures() {
        this.tileSize = GameConfig.TILE_SIZE2;
        this.floor1 = Utility.readImage("bin/images/sol1_niveau_2.png");
        this.floor2 = Utility.readImage("bin/images/sol2_niveau_2.png");
        this.wallimg = Utility.readImage("bin/images/wall_niveau_2.png");
        this.enemy1 = "spirit";
        this.enemy1_1 = Utility.readImage("bin/images/spiritLeft.png");
        this.enemy1_2 = Utility.readImage("bin/images/spiritRight.png");
        this.enemy1_3 = Utility.readImage("bin/images/spiritUp.png");
        this.enemy1_4 = Utility.readImage("bin/images/spiritDown.png");
        this.enemy2 = "salamander";
        this.enemy2_1 = Utility.readImage("bin/images/salamanderLeft.png");
        this.enemy2_2 = Utility.readImage("bin/images/salamanderRight.png");
        this.enemy2_3 = Utility.readImage("bin/images/salamanderUp.png");
        this.enemy2_4 = Utility.readImage("bin/images/salamanderDown.png");
        this.enemy3 = "fire_skeleton";
        this.enemy3_1 = Utility.readImage("bin/images/fireskeletonLeft.png");
        this.enemy3_2 = Utility.readImage("bin/images/fireskeletonRight.png");
        this.enemy3_3 = Utility.readImage("bin/images/fireskeletonUp.png");
        this.enemy3_4 = Utility.readImage("bin/images/fireskeletonDown.png");
        this.boss = Utility.readImage("bin/images/boss2.png");
        logger.info("Level 2 textures loaded");
    }

    /**
     * Loads textures specific to Level 3.
     */
    public void loadLv3Textures() {
        this.tileSize = GameConfig.TILE_SIZE3;
        this.floor1 = Utility.readImage("bin/images/sol1_niveau_3.png");
        this.floor2 = Utility.readImage("bin/images/sol2_niveau_3.png");
        this.wallimg = Utility.readImage("bin/images/wall_niveau_3.png");
        this.enemy1 = "big_spirit";
        this.enemy1_1 = Utility.readImage("bin/images/bigspiritLeft.png");
        this.enemy1_2 = Utility.readImage("bin/images/bigspiritRight.png");
        this.enemy1_3 = Utility.readImage("bin/images/bigspiritUp.png");
        this.enemy1_4 = Utility.readImage("bin/images/bigspiritDown.png");
        this.enemy2 = "golem";
        this.enemy2_1 = Utility.readImage("bin/images/golemLeft.png");
        this.enemy2_2 = Utility.readImage("bin/images/golemRight.png");
        this.enemy2_3 = Utility.readImage("bin/images/golemUp.png");
        this.enemy2_4 = Utility.readImage("bin/images/golemDown.png");
        this.enemy3 = "ice_octopus";
        this.enemy3_1 = Utility.readImage("bin/images/iceoctopusLeft.png");
        this.enemy3_2 = Utility.readImage("bin/images/iceoctopustRight.png");
        this.enemy3_3 = Utility.readImage("bin/images/iceoctopusUp.png");
        this.enemy3_4 = Utility.readImage("bin/images/iceoctopusDown.png");
        this.boss = Utility.readImage("bin/images/boss3.png");
        logger.info("Level 3 textures loaded");
    }

    /**
     * Paints the map onto the screen based on the current level textures.
     * 
     * @param map the current game map
     * @param graphics the graphics object used for drawing
     */
    public void paint(Map map, Graphics graphics) {
        for (int lineIndex = 0; lineIndex < map.getLineCount(); lineIndex++) {
            for (int columnIndex = 0; columnIndex < map.getColumnCount(); columnIndex++) {
                if ((lineIndex + columnIndex) % 2 == 0) {
                    graphics.drawImage(floor1, columnIndex * tileSize, lineIndex * tileSize, tileSize, tileSize, null);
                } else {
                    graphics.drawImage(floor2, columnIndex * tileSize, lineIndex * tileSize, tileSize, tileSize, null);
                }
            }
        }
    }

    /**
     * Paints the player onto the screen based on their current position and movement direction.
     * 
     * @param player the player object to be drawn
     * @param graphics the graphics object used for drawing
     */
    public void paint(PlayerEntity player, Graphics graphics) {
        Tile position = player.getPosition();
        int lastMovement = player.getLM();
        int y = position.getLine();
        int x = position.getColumn();

        if (player.getStats().getType().equals("warior")) {
            switch (lastMovement) {
                case 0: {
                    graphics.drawImage(warior1, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
                case 1: {
                    graphics.drawImage(warior2, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
                case 2: {
                    graphics.drawImage(warior3, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
                case 3: {
                    graphics.drawImage(warior4, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
            }
        } else if (player.getStats().getType().equals("mage")) {
            switch (lastMovement) {
                case 0: {
                    graphics.drawImage(mage1, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
                case 1: {
                    graphics.drawImage(mage2, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
                case 2: {
                    graphics.drawImage(mage3, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
                case 3: {
                    graphics.drawImage(mage4, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
            }
        } else if (player.getStats().getType().equals("assasin")) {
            switch (lastMovement) {
                case 0: {
                    graphics.drawImage(assasin1, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
                case 1: {
                    graphics.drawImage(assasin2, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
                case 2: {
                    graphics.drawImage(assasin3, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
                case 3: {
                    graphics.drawImage(assasin4, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    break;
                }
            }
        }
    }

    /**
     * Paints walls on the map.
     * 
     * @param walls the list of walls to be painted
     * @param graphics the graphics object used for drawing
     */
    public void paintW(ArrayList<Wall> walls, Graphics graphics) {
        for (Wall wall : walls) {
            int y = wall.getPosition().getLine();
            int x = wall.getPosition().getColumn();
            graphics.drawImage(wallimg, x * tileSize, y * tileSize, tileSize, tileSize, null);
        }
    }

    /**
     * Paints the boss on the map, including a health bar.
     * 
     * @param b the boss object to be painted
     * @param graphics the graphics object used for drawing
     */
    public void paintB(Boss b, Graphics graphics) {
        int y = b.getPosition().getLine();
        int x = b.getPosition().getColumn();
        graphics.drawImage(boss, x * tileSize, y * tileSize, tileSize, tileSize, null);
        
        int barWidth = tileSize;
        int barHeight = 5;
        int padding = 2;
        x = b.getPosition().getColumn() * tileSize;
        y = b.getPosition().getLine() * tileSize - (barHeight + padding);

        int currentHP = b.getStats().getEnemyStats().get(0).getValue();
        int maxHP = b.getStats().getEnemyStats().get(5).getValue();
        int healthBarFill = (int) ((currentHP / (double) maxHP) * barWidth);

        graphics.setColor(Color.DARK_GRAY);
        graphics.fillRect(x, y, barWidth, barHeight);
        
        if (currentHP > maxHP / 2) {
            graphics.setColor(Color.GREEN);
        } else {
            graphics.setColor(Color.RED);
        }
        graphics.fillRect(x, y, healthBarFill, barHeight);

        graphics.setColor(Color.BLACK);
        graphics.drawRect(x, y, barWidth, barHeight);
    }

    /**
     * Paints enemies on the map, including their movement and health bar.
     * 
     * @param enemies the list of enemies to be painted
     * @param graphics the graphics object used for drawing
     */
    public void paintE(ArrayList<Enemy> enemies, Graphics graphics) {
        for (Enemy enemy : enemies) {
            int lastMovement = enemy.getLM();
            int y = enemy.getPosition().getLine();
            int x = enemy.getPosition().getColumn();

            switch (lastMovement) {
                case 0: {
                    if (enemy.getStats().getType().equals(enemy1)) {
                        graphics.drawImage(enemy1_1, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else if (enemy.getStats().getType().equals(enemy2)) {
                        graphics.drawImage(enemy2_1, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else if (enemy.getStats().getType().equals(enemy3)) {
                        graphics.drawImage(enemy3_1, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else {
                        graphics.setColor(Color.RED);
                        graphics.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
                    }
                    break;
                }
                case 1: {
                    if (enemy.getStats().getType().equals(enemy1)) {
                        graphics.drawImage(enemy1_2, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else if (enemy.getStats().getType().equals(enemy2)) {
                        graphics.drawImage(enemy2_2, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else if (enemy.getStats().getType().equals(enemy3)) {
                        graphics.drawImage(enemy3_2, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else {
                        graphics.setColor(Color.RED);
                        graphics.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
                    }
                    break;
                }
                case 2: {
                    if (enemy.getStats().getType().equals(enemy1)) {
                        graphics.drawImage(enemy1_3, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else if (enemy.getStats().getType().equals(enemy2)) {
                        graphics.drawImage(enemy2_3, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else if (enemy.getStats().getType().equals(enemy3)) {
                        graphics.drawImage(enemy3_3, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else {
                        graphics.setColor(Color.RED);
                        graphics.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
                    }
                    break;
                }
                case 3: {
                    if (enemy.getStats().getType().equals(enemy1)) {
                        graphics.drawImage(enemy1_4, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else if (enemy.getStats().getType().equals(enemy2)) {
                        graphics.drawImage(enemy2_4, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else if (enemy.getStats().getType().equals(enemy3)) {
                        graphics.drawImage(enemy3_4, x * tileSize, y * tileSize, tileSize, tileSize, null);
                    } else {
                        graphics.setColor(Color.RED);
                        graphics.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
                    }
                    break;
                }
            }
            drawHealthBar(graphics, enemy);
        }
    }

    /**
     * Draws the health bar for the given enemy.
     * 
     * @param graphics the graphics object used for drawing
     * @param enemy the enemy whose health bar is being drawn
     */
    private void drawHealthBar(Graphics graphics, Enemy enemy) {
        int barWidth = tileSize;
        int barHeight = 5;
        int padding = 2;

        int x = enemy.getPosition().getColumn() * tileSize;
        int y = enemy.getPosition().getLine() * tileSize - (barHeight + padding);

        int currentHP = enemy.getStats().getEnemyStats().get(0).getValue();
        int maxHP = enemy.getStats().getEnemyStats().get(5).getValue();

        int healthBarFill = (int) ((currentHP / (double) maxHP) * barWidth);

        graphics.setColor(Color.DARK_GRAY);
        graphics.fillRect(x, y, barWidth, barHeight);

        if (currentHP > maxHP / 2) {
            graphics.setColor(Color.GREEN);
        } else {
            graphics.setColor(Color.RED);
        }
        graphics.fillRect(x, y, healthBarFill, barHeight);

        graphics.setColor(Color.BLACK);
        graphics.drawRect(x, y, barWidth, barHeight);
    }

    /**
     * Paints the attack zone for the player (orange).
     * 
     * @param attackZoneLast the list of tiles in the attack zone
     * @param graphics the graphics object used for drawing
     */
    public void paintAZ(ArrayList<Tile> attackZoneLast, Graphics graphics) {
        for (Tile tile : attackZoneLast) {
            int y = tile.getLine();
            int x = tile.getColumn();
            graphics.setColor(orangeTransparent);
            graphics.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
        }
    }

    /**
     * Paints the enemy's attack zone (red).
     * 
     * @param attackZoneELast the list of tiles in the enemy's attack zone
     * @param graphics the graphics object used for drawing
     */
    public void paintAZEL(ArrayList<Tile> attackZoneELast, Graphics graphics) {
        for (Tile tile : attackZoneELast) {
            int y = tile.getLine();
            int x = tile.getColumn();
            graphics.setColor(redTransparent);
            graphics.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
        }
    }
    
    public void paintAZSL(ArrayList<Tile> attackZonzSpellLast,Graphics graphics) {
    	for (Tile tile : attackZonzSpellLast) {
            int y = tile.getLine();
            int x = tile.getColumn();
            graphics.setColor(redTransparent);
            graphics.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
    	}
    }

    /**
     * Paints chests on the map.
     * 
     * @param chests the list of chests to be painted
     * @param graphics the graphics object used for drawing
     */
    public void paintC(ArrayList<Chest> chests, Graphics graphics) {
        for (Chest chest : chests) {
            int x = chest.getPosition().getLine();
            int y = chest.getPosition().getColumn();
            graphics.drawImage(chestTexture, x * tileSize, y * tileSize, tileSize, tileSize, null);
        }
    }

    /**
     * Paints the shop on the map.
     * 
     * @param shop the shop object to be painted
     * @param graphics the graphics object used for drawing
     */
    public void paint(Shop shop, Graphics graphics) {
        int x = shop.getPosition().getLine();
        int y = shop.getPosition().getColumn();
        graphics.drawImage(shopTexture, x * tileSize, y * tileSize, tileSize, tileSize, null);
    }
}

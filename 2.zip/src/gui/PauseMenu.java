package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * PauseMenu displays a modal dialog with options when the game is paused.
 */
public class PauseMenu extends JDialog {

    private static final long serialVersionUID = 1L;

    public PauseMenu(JFrame parent) {
        super(parent, "Pause", true);
        setSize(300, 200);
        setUndecorated(true);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(4, 1));

        JButton resumeButton = new JButton("Reprendre");
        JButton menuButton = new JButton("Menu Principal");
        JButton quitButton = new JButton("Quitter");

        resumeButton.addActionListener(new ResumeButtonListener());
        menuButton.addActionListener(new MenuButtonListener(parent));
        quitButton.addActionListener(new QuitButtonListener());

        add(resumeButton);
        add(menuButton);
        add(quitButton);

        setVisible(true);
    }

    /**
     * Action listener for the "Reprendre" button.
     * Resumes the game and closes the pause menu.
     */
    private class ResumeButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            GameGUI.runing = true;
            dispose();
        }
    }

    /**
     * Action listener for the "Menu Principal" button.
     * Closes both the pause menu and the game window, then shows the start menu.
     */
    private class MenuButtonListener implements ActionListener {
        private JFrame parent;

        public MenuButtonListener(JFrame parent) {
            this.parent = parent;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            parent.dispose();
            GameGUI.runing = true;
            new StartMenu("RPG");
        }
    }

    /**
     * Action listener for the "Quitter" button.
     * Exits the application immediately.
     */
    private class QuitButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }
}

package gui;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import engine.player.PlayerEntity;
import engine.player.PlayerStatistics;

/**
 * Panel class responsible for displaying the player's information in the GUI.
 * It shows the player's level, experience points, and gold.
 * The values are updated regularly to reflect the player's current status.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class InfoPanel extends JPanel {
    
    private static final long serialVersionUID = 1L;
    
    private JLabel titleLabel = new JLabel("Info : "); 
    private JLabel spacerLabel = new JLabel("");  
    private JLabel lvlLabel = new JLabel("Level : ");  
    private JLabel lvlValLabel = new JLabel("");  
    private JLabel xpLabel = new JLabel("Xp : ");  
    private JLabel xpValLabel = new JLabel("");  
    private JLabel goldLabel = new JLabel("Gold : "); 
    private JLabel goldValLabel = new JLabel("");  

    /**
     * Constructs the InfoPanel object and sets up the layout and components.
     * It arranges the labels for the title, level, XP, and gold in a grid layout.
     */
    public InfoPanel() {
        setLayout(new GridLayout(4, 2));  
        setBackground(Color.GRAY); 
        add(titleLabel);  
        add(spacerLabel);  
        add(lvlLabel);
        add(lvlValLabel);
        add(xpLabel);
        add(xpValLabel);
        add(goldLabel);
        add(goldValLabel);
    }

    /**
     * Updates the values displayed in the info panel with the player's current level, XP, and gold.
     * 
     * @param p the player whose stats are to be displayed
     */
    public void updateValuesInfo(PlayerEntity p) {
        PlayerStatistics stats = p.getStats(); 
        lvlValLabel.setText(String.valueOf(stats.getLevel()));  
        xpValLabel.setText(String.valueOf(stats.getXp()));  
        goldValLabel.setText(String.valueOf(stats.getGold())); 
    }
}

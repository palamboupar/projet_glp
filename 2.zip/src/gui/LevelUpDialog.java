package gui;

import javax.swing.*;

import engine.process.ElementInterface;

import java.awt.*;
import java.awt.event.*;

/**
 * LevelUpDialog is displayed when the player levels up.
 * It allows the player to choose one stat to increase.
 */
public class LevelUpDialog extends JDialog {

    private static final long serialVersionUID = 1L;
    private ElementInterface manager;

    public LevelUpDialog(JFrame parent, ElementInterface manager) {
        super(parent, "Niveau Supérieur !", true);
        this.manager=manager;

        setSize(350, 200);
        setUndecorated(true);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(4, 1));

        JLabel message = new JLabel("Choisissez une statistique à améliorer :", JLabel.CENTER);
        JButton hpButton = new JButton("Augmenter la Vie");
        JButton manaButton = new JButton("Augmenter le Mana");
        JButton staminaButton = new JButton("Augmenter la Stamina");

        hpButton.addActionListener(new HPButtonListener());
        manaButton.addActionListener(new ManaButtonListener());
        staminaButton.addActionListener(new StaminaButtonListener());

        add(message);
        add(hpButton);
        add(manaButton);
        add(staminaButton);

        setVisible(true);
    }

    /**
     * Augmente les points de vie du joueur.
     */
    private class HPButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
        	manager.increaseLife();
            JOptionPane.showMessageDialog(LevelUpDialog.this, "Vie augmentée !");
            dispose();
        }
    }

    /**
     * Augmente le mana du joueur.
     */
    private class ManaButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
        	manager.increaseMana();
            JOptionPane.showMessageDialog(LevelUpDialog.this, "Mana augmenté !");
            dispose();
        }
    }

    /**
     * Augmente la stamina du joueur.
     */
    private class StaminaButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
        	manager.increaseStam();
            JOptionPane.showMessageDialog(LevelUpDialog.this, "Stamina augmentée !");
            dispose();
        }
    }
}
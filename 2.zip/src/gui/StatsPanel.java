package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;

import config.GameConfig;
import engine.player.PlayerEntity;
import engine.stats.Stat;

/**
 * Class that represents the statistics panel in the game UI.
 * Displays the player's health, mana, and stamina values on the screen.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class StatsPanel extends JPanel {
    private static final long serialVersionUID = 1L;

    private Font font = new Font(Font.MONOSPACED, Font.BOLD, 20);
    
    private JLabel hpLabel = new JLabel("Health :");
    private JLabel manaLabel = new JLabel("Mana   :");
    private JLabel stamLabel = new JLabel("Stamina:");
    private JLabel hpValue = new JLabel("");
    private JLabel manaValue = new JLabel("");
    private JLabel stamValue = new JLabel("");
    
    private final static Dimension preferredSize = new Dimension(80, GameConfig.WINDOW_HEIGHT - GameConfig.MAP_HEIGHT);

    /**
     * Constructor for the StatsPanel class.
     * Initializes the labels and layout for displaying player statistics.
     */
    public StatsPanel() {
        setLayout(new GridLayout(3, 2));

        setBackground(Color.GRAY);

        hpLabel.setFont(font);
        manaLabel.setFont(font);
        stamLabel.setFont(font);

        add(hpLabel);
        add(hpValue);
        add(manaLabel);
        add(manaValue);
        add(stamLabel);
        add(stamValue);

        setPreferredSize(preferredSize);
    }

    /**
     * Updates the displayed values of the player's health, mana, and stamina.
     * 
     * @param p The player entity whose statistics are being displayed.
     */
    public void updateValuesStats(PlayerEntity p) {
        ArrayList<Stat> stat = p.getStats().getPlayerStats();
        hpValue.setText(String.valueOf(stat.get(0).getValue()) + " / " + String.valueOf(stat.get(1).getValue()));
        manaValue.setText(String.valueOf(stat.get(3).getValue()) + " / " + String.valueOf(stat.get(4).getValue()));
        stamValue.setText(String.valueOf(stat.get(6).getValue()) + " / " + String.valueOf(stat.get(7).getValue()));
    }
}

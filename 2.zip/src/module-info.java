/**
 * This module requires the following modules:
 * - java.desktop: Provides classes for building graphical user interfaces (GUI), including Swing and AWT components.
 * - log4j: Used for logging functionality to help with application logging and error tracking.
 * - junit: Provides the JUnit framework for unit testing.
 * These dependencies are necessary for the proper functioning of the RPG application, including GUI elements, logging, and testing.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
module GLP_RPG_2 {
    requires java.desktop;  
    requires log4j;        
    requires junit;         
}

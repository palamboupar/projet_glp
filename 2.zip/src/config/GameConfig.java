package config;

/**
 * Configuration class for the game window and map settings.
 * Stores constants related to window size, map dimensions,
 * tile sizes for different levels, and the game speed.
 * 
 * started : 29/01/2025  
 * last modified : 30/01/2025
 * 
 * @author PALEOLOGOS amael
 * @version 0.1
 */
public class GameConfig {

    /** Width of the game window in pixels */
    public static final int WINDOW_WIDTH = 1300;

    /** Height of the game window in pixels */
    public static final int WINDOW_HEIGHT = 800;

    /** Width of the map area in pixels */
    public static final int MAP_WIDTH = 1100;

    /** Height of the map area in pixels */
    public static final int MAP_HEIGHT = 700;

    /** Tile size for level 1 in pixels */
    public static final int TILE_SIZE1 = 35;

    /** Number of rows in the map for level 1 */
    public static final int LINE_COUNT1 = MAP_HEIGHT / TILE_SIZE1;

    /** Number of columns in the map for level 1 */
    public static final int COLUMN_COUNT1 = MAP_WIDTH / TILE_SIZE1;

    /** Tile size for level 2 in pixels */
    public static final int TILE_SIZE2 = 32;

    /** Number of rows in the map for level 2 */
    public static final int LINE_COUNT2 = MAP_HEIGHT / TILE_SIZE2;

    /** Number of columns in the map for level 2 */
    public static final int COLUMN_COUNT2 = MAP_WIDTH / TILE_SIZE2;

    /** Tile size for level 3 in pixels */
    public static final int TILE_SIZE3 = 30;

    /** Number of rows in the map for level 3 */
    public static final int LINE_COUNT3 = MAP_HEIGHT / TILE_SIZE3;

    /** Number of columns in the map for level 3 */
    public static final int COLUMN_COUNT3 = MAP_WIDTH / TILE_SIZE3;

    /** Game update speed in milliseconds */
    public static final int GAME_SPEED = 500;
}

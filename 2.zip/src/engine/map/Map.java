package engine.map;

/**
 * this class represents the map made of {@link Tile}
 * @see Tile
 * @author PALEOLOGOS amael
 * @version 0.1
 */
public class Map {
	private Tile[][]tiles;
	private int lineCount;
	private int columnCount;
	/**
	 * builder
	 * @param lineCount
	 * @param columnCount
	 */
	public Map(int lineCount, int columnCount) {
		init(lineCount, columnCount);

		for (int lineIndex = 0; lineIndex < lineCount; lineIndex++) {
			for (int columnIndex = 0; columnIndex < columnCount; columnIndex++) {
				tiles[lineIndex][columnIndex] = new Tile(lineIndex, columnIndex);
			}
		}
	}
	/**
	 * Initialise tiles to the wanted size
	 * @param lineCount
	 * @param columnCount
	 */
	private void init(int lineCount, int columnCount) {
		this.lineCount = lineCount;	
		this.columnCount = columnCount;

		tiles = new Tile[lineCount][columnCount];
	}
	/**
	 * getter for tiles in the map
	 * @param line
	 * @param column
	 * @return tile at [line][column]
	 */
	public Tile getTile(int line, int column) {
		return tiles[line][column];
	}
	/**
	 * getter for all the list tiles
	 * @return tiles
	 */
	public Tile[][] getTiles() {
		return tiles;
	}
	/**
	 * setter for tiles
	 * @param tiles
	 */
	public void setTiles(Tile[][] tiles) {
		this.tiles = tiles;
	}
	/**
	 * getter for the number of lines of the map
	 * @return int lineCount
	 */
	public int getLineCount() {
		return lineCount;
	}
	/**
	 * getter for the number of columns of the map
	 * @return int columnCount
	 */
	public int getColumnCount() {
		return columnCount;
	}
}

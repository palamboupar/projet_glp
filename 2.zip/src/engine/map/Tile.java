package engine.map;

/**
 * represents Tile that compose the {@link Map}
 * @author PALEOLOGOS amael
 * @version 0.1
 * 
 */
public class Tile {
	private int line;
	private int column;
	/**
	 * builder
	 * @param line
	 * @param column
	 */
	public Tile(int line, int column) {
		this.line = line;
		this.column = column;
	}
	/**
	 * getter
	 * @return line
	 */
	public int getLine() {
		return line;
	}
	/**
	 * getter
	 * @return column
	 */
	public int getColumn() {
		return column;
	}
}

package engine.player;

import engine.map.Tile;

/**
 * this is a class representing the player
 * @see PlayerStatistics
 * @see PlayerFactory
 * @author PALEOLOGOS amael
 * @version 0.1
 */ 
public class PlayerEntity {
	private Tile position;
	private int lastMovement; //0=left 1=right 2=up 3=down
	private PlayerStatistics stats;
	
	
	/**
	 * builder
	 * @param position
	 * @param stats
	 */
	public PlayerEntity(Tile position,PlayerStatistics stats) {
		this.position=position;
		lastMovement=2;
		this.stats=stats ;
	}
	
	/**
	 * getter
	 * @return position
	 */
	public Tile getPosition() {
		return position;
	}
	
	/**
	 * setter
	 * @param position
	 */
	public void setPosition(Tile position) {
		this.position=position;
	}

	/**
	 * getter
	 * @return lastLovement
	 */
	public int getLM() {
		return lastMovement;
	}

	/**
	 * setter
	 * @param lastMovement
	 */
	public void setLM(int lastMovement) {
		this.lastMovement = lastMovement;
	}

	/**
	 * getter
	 * @return stats
	 */
	public PlayerStatistics getStats() {
		return stats;
	}

	/**
	 * setter
	 * @param stats
	 */
	public void setStats(PlayerStatistics stats) {
		this.stats = stats;
	}
}

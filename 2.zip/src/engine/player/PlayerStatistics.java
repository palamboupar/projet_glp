package engine.player;

import engine.stats.*;
import java.util.ArrayList;

/**
 * this is a class representing the statistics of the player
 * @see PlayerEntity
 * @see PlayerFactory
 * @author PALEOLOGOS amael
 * @version 0.1
 */ 
public class PlayerStatistics {
	private String type;
	private Weapon playerWeapon;
	private ArrayList<Stat> playerStats;
	private ArrayList<Item> equipements;
	private ArrayList<Item> inventory;
	private int level;
	private int xp;
	private int gold;
	private int[] accessibleSpell;
	private int[] unlockedSpell;
	
	/**
	 * builder
	 * @param type
	 * @param playerWeapon
	 * @param playerStats
	 * @param equipements
	 * @param inventory
	 */
	public PlayerStatistics(String type,Weapon playerWeapon,ArrayList<Stat> playerStats,ArrayList<Item> equipements,ArrayList<Item> inventory) {
		this.type=type;
		this.playerWeapon=playerWeapon;
		this.playerStats=playerStats;
		this.equipements=equipements;
		this.inventory = inventory;
		this.level=1;
		this.xp=0;
		this.gold=50;
	}

	/**
	 * getter
	 * @return type
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * setter
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * getter
	 * @return playerStats
	 */
	public ArrayList<Stat> getPlayerStats() {
		return playerStats;
	}

	/**
	 * setter
	 * @param playerStats
	 */
	public void setPlayerStats(ArrayList<Stat> playerStats) {
		this.playerStats = playerStats;
	}

	/**
	 * getter
	 * @return equipements
	 */
	public ArrayList<Item> getEquipements() {
		return equipements;
	}

	/**
	 * setter
	 * @param equipements
	 */
	public void setEquipements(ArrayList<Item> equipements) {
		this.equipements = equipements;
	}

	/**
	 * getter
	 * @return level
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * setter
	 * @param level
	 */
	public void setLevel(int level) {
		this.level = level;
	}
	
	/**
	 * getter
	 * @return xp
	 */
	public int getXp() {
		return xp;
	}

	/**
	 * setter
	 * @param xp
	 */
	public void setXp(int xp) {
		this.xp = xp;
	}
	
	/**
	 * getter
	 * @return gold
	 */
	public int getGold() {
		return gold;
	}

	/**
	 * setter
	 * @param gold
	 */
	public void setGold(int gold) {
		this.gold = gold;
	}
	
	/**
	 * getter
	 * @return playerWeapon
	 */
	public Weapon getPlayerWeapon() {
		return playerWeapon;
	}

	/**
	 * setter
	 * @param playerWeapon
	 */
	public void setPlayerWeapon(Weapon playerWeapon) {
		this.playerWeapon = playerWeapon;
	}
	
	/**
	 * getter
	 * @return inventory
	 */
	public ArrayList<Item> getInventory() {
		return inventory;
	}

	/**
	 * setter
	 * @param inventory
	 */
	public void setInventory(ArrayList<Item> inventory) {
		this.inventory = inventory;
	}

	public int[] getAccessibleSpell() {
		return accessibleSpell;
	}

	public void setAccessibleSpell(int[] accessibleSpell) {
		this.accessibleSpell = accessibleSpell;
	}

	public int[] getUnlockedSpell() {
		return unlockedSpell;
	}

	public void setUnlockedSpell(int[] unlockedSpell) {
		this.unlockedSpell = unlockedSpell;
	}
	
	
}

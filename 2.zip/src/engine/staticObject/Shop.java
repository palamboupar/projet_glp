package engine.staticObject;

import java.util.ArrayList;

import engine.map.Tile;
import engine.stats.*;

/**
 * Class representing a shop in the game, which is a static element.
 * The shop contains a stock of items for sale and a certain amount of gold.
 * It is positioned on a specific tile on the map.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class Shop extends StaticElement {

    private ArrayList<Item> stock;
    private int shopGold;

    /**
     * Constructs a Shop object with the specified position, stock, and gold.
     * 
     * @param position the tile where the shop is located
     * @param stock the items available for sale in the shop
     * @param shopGold the amount of gold the shop has
     */
    public Shop(Tile position, ArrayList<Item> stock, int shopGold) {
        super(position); 
        this.stock = stock;
        this.shopGold = shopGold;
    }

    /**
     * Returns the list of items available in the shop's stock.
     * 
     * @return the shop's stock of items
     */
    public ArrayList<Item> getStock() {
        return stock;
    }

    /**
     * Sets the stock of items in the shop.
     * 
     * @param stock the stock of items to set
     */
    public void setStock(ArrayList<Item> stock) {
        this.stock = stock;
    }

    /**
     * Returns the amount of gold the shop has.
     * 
     * @return the shop's gold
     */
    public int getShopGold() {
        return shopGold;
    }

    /**
     * Sets the amount of gold the shop has.
     * 
     * @param shopGold the gold amount to set
     */
    public void setShopGold(int shopGold) {
        this.shopGold = shopGold;
    }
}

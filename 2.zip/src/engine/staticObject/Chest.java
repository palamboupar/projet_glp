package engine.staticObject;

import java.util.ArrayList;
import engine.map.Tile;
import engine.stats.*;

/**
 * Class representing a chest in the game, which is a static element.
 * The chest contains loot items and gold that can be collected by the player.
 * It is positioned on a specific tile on the map.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class Chest extends StaticElement {
	
    private ArrayList<Item> chestLoot;
    private int chestGold;

    /**
     * Constructs a Chest object with the specified position, loot, and gold.
     * 
     * @param position the tile where the chest is located
     * @param chestLoot the items contained in the chest
     * @param chestGold the amount of gold contained in the chest
     */
    public Chest(Tile position, ArrayList<Item> chestLoot, int chestGold) {
        super(position); 
        this.chestLoot = chestLoot;
        this.chestGold = chestGold;
    }

    /**
     * Returns the list of items contained in the chest.
     * 
     * @return the chest's loot items
     */
    public ArrayList<Item> getChestLoot() {
        return chestLoot;
    }

    /**
     * Sets the loot items contained in the chest.
     * 
     * @param chestLoot the loot items to set
     */
    public void setChestLoot(ArrayList<Item> chestLoot) {
        this.chestLoot = chestLoot;
    }

    /**
     * Returns the amount of gold contained in the chest.
     * 
     * @return the chest's gold
     */
    public int getChestGold() {
        return chestGold;
    }

    /**
     * Sets the amount of gold contained in the chest.
     * 
     * @param chestGold the amount of gold to set
     */
    public void setChestGold(int chestGold) {
        this.chestGold = chestGold;
    }
}

package engine.staticObject;

import engine.map.Tile;

/**
 * Abstract class representing a static element in the game, such as a chest or shop.
 * A static element has a position on the map and is not movable during the game.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public abstract class StaticElement {
	
    private Tile position;

    /**
     * Constructs a StaticElement object with the specified position.
     * 
     * @param position the tile where the static element is located
     */
    public StaticElement(Tile position) {
        this.position = position;
    }

    /**
     * Returns the position of the static element on the map.
     * 
     * @return the position of the static element
     */
    public Tile getPosition() {
        return position;
    }

    /**
     * Sets the position of the static element on the map.
     * 
     * @param position the position to set
     */
    public void setPosition(Tile position) {
        this.position = position;
    }
}

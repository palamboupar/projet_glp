package engine.staticObject;

import engine.map.Tile;

/**
 * Class representing a wall in the game, which is a static element.
 * Walls are obstacles that players and other entities cannot pass through.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class Wall extends StaticElement {

    /**
     * Constructs a Wall object with the specified position.
     * 
     * @param position the tile where the wall is located
     */
    public Wall(Tile position) {
        super(position);  
    }
}

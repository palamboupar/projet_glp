package engine.stats;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import log.LoggerUtility;

/**
 * Abstract class representing an item in the game. 
 * Items can have various attributes such as name, stats, price, and type.
 * The item can represent different categories like equipment, potions, or weapons.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public abstract class Item {
  
    private static Logger logger = LoggerUtility.getLogger(Item.class, "html");
    private String name; 
    private ArrayList<Stat> itemStats;  
    private int price;  
    private int type;  

    /**
     * Constructs an Item with specified attributes.
     * @param name the name of the item
     * @param itemStats the list of stats associated with the item (e.g., damage, defense)
     * @param price the price of the item
     * @param type the type of the item (0 = head, 1 = chest, 2 = legging, 3 = boots, 4 = potion, 5 = weapon, 6 = no equipment)
     */
    public Item(String name, ArrayList<Stat> itemStats, int price, int type) {
        this.name = name;
        this.itemStats = itemStats;
        this.price = price;
        this.type = type;
        logger.info("Item creation with name : " + name + " and type : " + type);
    }

    /**
     * Returns the name of the item.
     * @return the name of the item
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the item.
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the list of stats associated with the item.
     * @return the list of item stats
     */
    public ArrayList<Stat> getItemStats() {
        return itemStats;
    }

    /**
     * Sets the list of stats associated with the item.
     * @param itemStats the stats to set
     */
    public void setItemStats(ArrayList<Stat> itemStats) {
        this.itemStats = itemStats;
    }

    /**
     * Returns the price of the item.
     * @return the price of the item
     */
    public int getPrice() {
        return price;
    }

    /**
     * Sets the price of the item.
     * @param price the price to set
     */
    public void setPrice(int price) {
        this.price = price;
    }

    /**
     * Returns the type of the item.
     * @return the type of the item
     */
    public int getType() {
        return type;
    }

    /**
     * Sets the type of the item.
     * @param type the type to set
     */
    public void setType(int type) {
        this.type = type;
    }

    /**
     * Returns a string representation of the item.
     * @return the name of the item
     */
    public String toString() {
        return name;
    }
}

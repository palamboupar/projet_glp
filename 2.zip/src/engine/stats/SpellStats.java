package engine.stats;

import java.util.ArrayList;

import engine.map.Tile;

/**
 * Class representing the stats of a spell, including its name, mana cost, and effect area.
 * Spells are magical abilities that can be cast by characters in the game.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class SpellStats {

    private String name; 
    private ArrayList<Stat> stats;  
    private ArrayList<Tile> aoe;  
    private int type;//0=heal(personal effect) 1=attack

    /**
     * Constructs a SpellStats object with the specified attributes.
     * @param name the name of the spell
     * @param manaCost the mana cost of casting the spell
     * @param effectArea the area of effect for the spell
     */
    public SpellStats(String name,ArrayList<Stat> stats, ArrayList<Tile> aoe,int type) {
    	
        this.name = name;
        this.stats = stats;
        this.aoe = aoe;
        this.type=type;
    }

    /**
     * Returns the name of the spell.
     * @return the name of the spell
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the spell.
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
	/**
	 * @return the aoe
	 */
	public ArrayList<Tile> getAoe() {
		return aoe;
	}

	/**
	 * @param aoe the aoe to set
	 */
	public void setAoe(ArrayList<Tile> aoe) {
		this.aoe = aoe;
	}

	/**
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}

	/**
	 * @return the stats
	 */
	public ArrayList<Stat> getStats() {
		return stats;
	}

	/**
	 * @param stats the stats to set
	 */
	public void setStats(ArrayList<Stat> stats) {
		this.stats = stats;
	}

   
}

package engine.stats;

import java.util.ArrayList;

/**
 * Class representing the statistics and properties of an enemy, including its type, stats, loot, experience points, and gold.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class EnemyStatistics {

    private String type; 
    private ArrayList<Stat> enemyStats;  
    private ArrayList<Item> enemyLoot;  
    private int enemyXp; 
    private int enemyGold; 

    /**
     * Constructs an EnemyStatistics object with specified values.
     * @param type the type of the enemy
     * @param enemyStats the stats of the enemy
     * @param enemyLoot the loot dropped by the enemy
     * @param enemyXp the experience points awarded for defeating the enemy
     * @param enemyGold the gold dropped by the enemy
     */
    public EnemyStatistics(String type, ArrayList<Stat> enemyStats, ArrayList<Item> enemyLoot, int enemyXp, int enemyGold) {
        this.type = type;
        this.enemyStats = enemyStats;
        this.enemyLoot = enemyLoot;
        this.enemyXp = enemyXp;
        this.enemyGold = enemyGold;
    }

    /**
     * Returns the type of the enemy.
     * @return the type of the enemy
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type of the enemy.
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Returns the list of stats associated with the enemy.
     * @return the list of enemy stats
     */
    public ArrayList<Stat> getEnemyStats() {
        return enemyStats;
    }

    /**
     * Sets the list of stats associated with the enemy.
     * @param enemyStats the stats to set
     */
    public void setEnemyStats(ArrayList<Stat> enemyStats) {
        this.enemyStats = enemyStats;
    }

    /**
     * Returns the list of loot dropped by the enemy.
     * @return the list of enemy loot
     */
    public ArrayList<Item> getEnemyLoot() {
        return enemyLoot;
    }

    /**
     * Sets the list of loot dropped by the enemy.
     * @param enemyLoot the loot to set
     */
    public void setEnemyLoot(ArrayList<Item> enemyLoot) {
        this.enemyLoot = enemyLoot;
    }

    /**
     * Returns the experience points awarded for defeating the enemy.
     * @return the enemy's experience points
     */
    public int getEnemyXp() {
        return enemyXp;
    }

    /**
     * Sets the experience points awarded for defeating the enemy.
     * @param enemyXp the experience points to set
     */
    public void setEnemyXp(int enemyXp) {
        this.enemyXp = enemyXp;
    }

    /**
     * Returns the amount of gold dropped by the enemy.
     * @return the enemy's gold
     */
    public int getEnemyGold() {
        return enemyGold;
    }

    /**
     * Sets the amount of gold dropped by the enemy.
     * @param enemyGold the gold to set
     */
    public void setEnemyGold(int enemyGold) {
        this.enemyGold = enemyGold;
    }
}

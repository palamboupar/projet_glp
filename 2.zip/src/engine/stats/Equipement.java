package engine.stats;

import java.util.ArrayList;

/**
 * Class representing an equipment item, which extends from the base Item class.
 * Equipments are items that can be equipped by the player, such as weapons or armor.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class Equipement extends Item {

    /**
     * Constructs an Equipement object with the specified attributes.
     * @param name the name of the equipment
     * @param itemStats the list of stats associated with the equipment (e.g., damage, defense)
     * @param price the price of the equipment
     * @param type the type of the equipment (e.g., weapon, armor)
     */
    public Equipement(String name, ArrayList<Stat> itemStats, int price, int type) {
        super(name, itemStats, price, type);
    }

    /**
     * Returns the range of the equipment.
     * For an Equipement, the range is always 0 as this class represents general equipment, 
     * and the range might not be applicable for all types of equipment.
     * @return 0
     */
    public int getRange() {
        return 0;
    }
}

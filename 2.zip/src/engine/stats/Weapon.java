package engine.stats;

import java.util.ArrayList;

/**
 * Class representing a weapon item, which extends from the base Item class.
 * Weapons are items that can be equipped by the player to deal damage in combat, 
 * with specific attributes such as forward range and side range for attacks.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class Weapon extends Item {

    private int rangeFwd;  
    private int rangeSide; 

    /**
     * Constructs a Weapon object with the specified attributes.
     * @param name the name of the weapon
     * @param itemStats the list of stats associated with the weapon (e.g., damage, attack speed)
     * @param price the price of the weapon
     * @param rangeFwd the forward attack range of the weapon
     * @param rangeSide the side attack range of the weapon
     * @param type the type of the weapon (e.g., 5 for weapons)
     */
    public Weapon(String name, ArrayList<Stat> itemStats, int price, int rangeFwd, int rangeSide, int type) {
        super(name, itemStats, price, type);
        this.rangeFwd = rangeFwd;
        this.rangeSide = rangeSide;
    }

    /**
     * Returns the forward range of the weapon's attack.
     * @return the forward range of the weapon
     */
    public int getRangeFwd() {
        return rangeFwd;
    }

    /**
     * Sets the forward range of the weapon's attack.
     * @param rangeFwd the forward range to set
     */
    public void setRangeFwd(int rangeFwd) {
        this.rangeFwd = rangeFwd;
    }

    /**
     * Returns the side range of the weapon's attack.
     * @return the side range of the weapon
     */
    public int getRangeSide() {
        return rangeSide;
    }

    /**
     * Sets the side range of the weapon's attack.
     * @param rangeSide the side range to set
     */
    public void setRangeSide(int rangeSide) {
        this.rangeSide = rangeSide;
    }
}

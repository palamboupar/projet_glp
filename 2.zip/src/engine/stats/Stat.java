package engine.stats;

/**
 * Class representing a stat associated with a game entity, such as a character or an item.
 * Stats include a name (e.g., "health", "damage") and a value representing its magnitude.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class Stat {

    private String name;  
    private int value;    

    /**
     * Constructs a Stat object with the specified name and value.
     * @param name the name of the stat
     * @param value the value of the stat
     */
    public Stat(String name, int value) {
        this.name = name;
        this.value = value;
    }

    /**
     * Returns the name of the stat.
     * @return the name of the stat
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the stat.
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the value of the stat.
     * @return the value of the stat
     */
    public int getValue() {
        return value;
    }

    /**
     * Sets the value of the stat.
     * @param value the value to set
     */
    public void setValue(int value) {
        this.value = value;
    }
}

package engine.stats;

import java.util.ArrayList;

/**
 * Class representing a potion item, which extends from the base Item class.
 * Potions are consumable items that provide specific effects when used.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class Potion extends Item {

    /**
     * Constructs a Potion object with the specified attributes.
     * @param name the name of the potion
     * @param itemStats the list of stats associated with the potion (e.g., healing, mana restoration)
     * @param price the price of the potion
     * @param type the type of the potion (e.g., 4 for potions)
     */
    public Potion(String name, ArrayList<Stat> itemStats, int price, int type) {
        super(name, itemStats, price, type);
    }

    /**
     * Returns the range of the potion.
     * Since potions are consumables, their range is always 0.
     * @return 0
     */
    public int getRange() {
        return 0;
    }
}

package engine.mobile;

import org.apache.log4j.Logger;
import engine.map.Tile;
import engine.stats.EnemyStatistics;
import log.LoggerUtility;

/**
 * this class represents an enemy made of {@link Tile} and {@link EnemyStatistics}
 * @see Tile
 * @author PALEOLOGOS amael
 * @version 0.1
 */ 
public class Enemy extends MobileElement{
	private static Logger logger = LoggerUtility.getLogger(Enemy.class,"html");
	private EnemyStatistics stats;
	private int lastMovement; //0=left 1=right 2=up 3=down
	
	/**
	 * builder
	 * @param position
	 * @param stats
	 */
	public Enemy(Tile position,EnemyStatistics stats) {
		super(position);
		try {
			this.stats=stats ;
			this.lastMovement=0;
		} catch (IllegalArgumentException e) {
			logger.error("Enemy couldn't be created.");
		}
	}
	
	/**
	 * getter
	 * @return stats
	 */
	public EnemyStatistics getStats() {
		return stats;
	}
	
	/**
	 * setter
	 * @param stats
	 */
	public void setStats(EnemyStatistics stats) {
		this.stats = stats;
	}
	
	/**
	 * getter
	 * @return lastMovement
	 */
	public int getLM() {
		return lastMovement;
	}

	/**
	 * setter
	 * @param LastMovement
	 */
	public void setLM(int lastMovement) {
		this.lastMovement = lastMovement;
	}
}
package engine.mobile;



import engine.map.Tile;
import engine.stats.SpellStats;

/**
 * Represents a magical spell entity in the game.
 * A spell is a type of {@link MobileElement} that can move or interact within the map.
 *
 * @see MobileElement
 * @see Tile
 * @author Auto
 * @version 0.1
 */
public class Spell extends MobileElement {
	private SpellStats stat ;
	private int spellnumber;

    /**
     * Constructs a spell at the specified position on the map.
     * 
     * @param position the tile where the spell is initially located
     */
    public Spell(Tile position,SpellStats stat,int spellnumber) {
        super(position);
        this.stat=stat;
        this.spellnumber=spellnumber;
    }

	/**
	 * @return the stat
	 */
	public SpellStats getStat() {
		return stat;
	}

	/**
	 * @param stat the stat to set
	 */
	public void setStat(SpellStats stat) {
		this.stat = stat;
	}

	/**
	 * @return the spellnumber
	 */
	public int getSpellnumber() {
		return spellnumber;
	}

	/**
	 * @param spellnumber the spellnumber to set
	 */
	public void setSpellnumber(int spellnumber) {
		this.spellnumber = spellnumber;
	}
	
}

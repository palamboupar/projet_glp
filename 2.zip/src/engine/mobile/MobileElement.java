package engine.mobile;

import org.apache.log4j.Logger;
import engine.map.Tile;
import log.LoggerUtility;

/**
 * this is an abstract class representing all the mobile elements except the player
 * @author PALEOLOGOS amael
 * @version 0.1
 */ 
public abstract class MobileElement {
	private static Logger logger = LoggerUtility.getLogger(MobileElement.class,"html");
	private Tile position;
	
	/**
	 * builder
	 * @param position
	 */
	public MobileElement(Tile position) {
		try {
			this.position=position;
		} catch (IllegalArgumentException e) {
			logger.error("Mobile entity couldn't be created.");
		}
	}
	
	/**
	 * getter
	 * @return position
	 */
	public Tile getPosition() {
		return position;
	}

	/**
	 * setter
	 * @param position
	 */
	public void setPosition(Tile position) {
		this.position = position;
	}
}
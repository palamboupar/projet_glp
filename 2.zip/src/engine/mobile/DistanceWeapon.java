package engine.mobile;

import engine.map.Tile;

/**
 * Represents a distance weapon in the game, such as a projectile or ranged attack.
 * This class extends {@link MobileElement} and is positioned on a {@link Tile}.
 *
 * @see MobileElement
 * @see Tile
 * @author Auto
 * @version 0.1
 */
public class DistanceWeapon extends MobileElement {

    /**
     * Constructs a distance weapon at the given position.
     * 
     * @param position the tile where the weapon is initially placed
     */
    public DistanceWeapon(Tile position) {
        super(position);
    }
}
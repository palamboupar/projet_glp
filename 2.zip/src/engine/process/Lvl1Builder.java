package engine.process;

import java.util.ArrayList;

import config.GameConfig;
import engine.map.Tile;
import engine.mobile.Boss;
import engine.mobile.Enemy;
import engine.map.Map;
import engine.player.PlayerEntity;
import engine.process.factory.EnemyFactory;
import engine.process.factory.LootTableFactory;
import engine.process.factory.PlayerFactory;
import engine.staticObject.Chest;
import engine.staticObject.Shop;
import engine.staticObject.Wall;

/**
 * Class responsible for building level 1 maps and initializing game elements such as enemies, walls, chests, and the player.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class Lvl1Builder {
	private static ArrayList<Tile> tilesNoWall = new ArrayList<Tile>();
    /**
     * Builds the map for level 1.
     * @return the map object for level 1
     */
    public static Map buildMap() {
        return new Map(GameConfig.LINE_COUNT1, GameConfig.COLUMN_COUNT1);
    }

    /**
     * Initializes all mobile entities and elements for level 1.
     * @param map the map object where the entities will be placed
     * @param type the type of player to initialize (e.g., "warrior", "mage", "assassin")
     * @return the manager object that handles the entities
     */
    public static ElementInterface buildInitMobile(Map map, String type) {
        ElementInterface manager = new ElementManager(map);
        initializeBoss(manager);    
        intializePlayer(map, manager, type);
        initializeChest(manager);   
        initializeShop(manager); 
        initializeWall(manager); 
        initializeSlime(manager);   
        initializeZombie(manager);
        initializeGhost(manager);
        
        return manager;
    }

    /**
     * Initializes the walls for the map.
     * Walls are placed around the boundaries and certain areas of the map.
     * @param manager the manager handling the entities
     */
    private static void initializeWall(ElementInterface manager) {
        
        int x = 0;
        int y = 0;
        for (int lineIndex = 0; lineIndex < GameConfig.LINE_COUNT1; lineIndex++) {
            Wall w = new Wall(new Tile(lineIndex, 0));
            manager.add(w);
            Wall z = new Wall(new Tile(lineIndex, GameConfig.COLUMN_COUNT1 - 1));
            manager.add(z);
        }
        for (int columnIndex = 0; columnIndex < GameConfig.COLUMN_COUNT1; columnIndex++) {
            Wall w = new Wall(new Tile(0, columnIndex));
            manager.add(w);
            Wall z = new Wall(new Tile(GameConfig.LINE_COUNT1 - 1, columnIndex));
            manager.add(z);
        }
        x = manager.getP().getPosition().getLine();
        y = manager.getP().getPosition().getColumn();
        for(int i=x-2;i>1;i--)
        tilesNoWall.add(new Tile( manager.getP().getPosition().getLine()-i, manager.getP().getPosition().getColumn()));

        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                if (i >= 0 && i < GameConfig.COLUMN_COUNT1 && j >= 0 && j < GameConfig.LINE_COUNT1) {
                    tilesNoWall.add(new Tile(i, j));
                }
            }
        }

        x = 2;
        y = 4;
        tilesNoWall.add(new Tile( x+3, y));
        for (int i = x - 2; i <= x + 2; i++) {
            for (int j = y - 2; j <= y + 2; j++) {
                if (i >= 0 && i < GameConfig.LINE_COUNT1 && j >= 0 && j < GameConfig.COLUMN_COUNT1) {
                    tilesNoWall.add(new Tile(i, j));
                }
            }
        }
        x = 2;
        y = (GameConfig.COLUMN_COUNT1 - 1) / 2;
        tilesNoWall.add(new Tile( x+3, y));
        for (int i = x - 2; i <= x + 2; i++) {
            for (int j = y - 2; j <= y + 2; j++) {
                if (i >= 0 && i < GameConfig.LINE_COUNT1 && j >= 0 && j < GameConfig.COLUMN_COUNT1) {
                    tilesNoWall.add(new Tile(i, j));
                }
            }
        }
        x = 2;
        y = (GameConfig.COLUMN_COUNT1 - 5);
        tilesNoWall.add(new Tile( x+3, y));
        for (int i = x - 2; i <= x + 2; i++) {
            for (int j = y - 2; j <= y + 2; j++) {
                if (i >= 0 && i < GameConfig.LINE_COUNT1 && j >= 0 && j < GameConfig.COLUMN_COUNT1) {
                    tilesNoWall.add(new Tile(i, j));
                }
            }
        }
        
        x = 10;
        y = 8;
        tilesNoWall.add(new Tile( x+4, y));
        tilesNoWall.add(new Tile( x-4, y));
        tilesNoWall.add(new Tile( x, y+4));
        tilesNoWall.add(new Tile( x, y-4));
        for (int i = x - 3; i <= x + 3; i++) {
            for (int j = y - 3; j <= y + 3; j++) {
                if (i >= 0 && i < GameConfig.LINE_COUNT1 && j >= 0 && j < GameConfig.COLUMN_COUNT1) {
                    tilesNoWall.add(new Tile(i, j));
                }
            }
        }
        
        x = 11;
        y = (GameConfig.COLUMN_COUNT1 - 8);
        tilesNoWall.add(new Tile( x+4, y));
        tilesNoWall.add(new Tile( x-4, y));
        tilesNoWall.add(new Tile( x, y+4));
        tilesNoWall.add(new Tile( x, y-4));
        for (int i = x - 3; i <= x + 3; i++) {
            for (int j = y - 3; j <= y + 3; j++) {
                if (i >= 0 && i < GameConfig.LINE_COUNT1 && j >= 0 && j < GameConfig.COLUMN_COUNT1) {
                    tilesNoWall.add(new Tile(i, j));
                }
            }
        }
        
        // Zone autour du shop (3x3)
        x = manager.getShop().getPosition().getLine();
        y = manager.getShop().getPosition().getColumn();
        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                if (i >= 0 && i < GameConfig.COLUMN_COUNT1 && j >= 0 && j < GameConfig.LINE_COUNT1) {
                    tilesNoWall.add(new Tile(j, i));
                }
            }
        }
        

        // Zone autour des chests (3x3)
        ArrayList<Chest> chests = manager.getChests();
        for (Chest c : chests) {
            x = c.getPosition().getLine();
            y = c.getPosition().getColumn();
            for (int i = x - 1; i <= x + 1; i++) {
                for (int j = y - 1; j <= y + 1; j++) {
                    if (i >= 0 && i < GameConfig.COLUMN_COUNT1 && j >= 0 && j < GameConfig.LINE_COUNT1) {
                        tilesNoWall.add(new Tile(j, i));
                    }
                }
            }
        }
        
        for(int j=0;j<GameConfig.COLUMN_COUNT1;j++) {
        	tilesNoWall.add(new Tile(6, j));
        }
        for(int j=0;j<GameConfig.LINE_COUNT1-3;j++) {
        	tilesNoWall.add(new Tile(j,GameConfig.COLUMN_COUNT1-5));
        }
        for(int j=0;j<GameConfig.LINE_COUNT1-3;j++) {
        	tilesNoWall.add(new Tile(j,4));
        }
        
        
        for(int i=0;i<GameConfig.LINE_COUNT1;i++) {
        	for(int j=0;j<GameConfig.COLUMN_COUNT1;j++) {
        		boolean placeW=true;
        		for (Tile t : tilesNoWall) {
        			if(t.getColumn()==j&&t.getLine()==i) {
        				placeW=false;
        			}
        		}
        		if(placeW==true) {
        			int a = Utility.getRandomNumber(0, 9);
        			if(a<8) {
        				manager.add(new Wall(new Tile(i,j)));
        			}
        		}
        	}
        }
    }



    /**
     * Initializes Slime enemies for the map.
     * Slimes are randomly placed within the map.
     * @param manager the manager handling the entities
     */
    private static void initializeSlime(ElementInterface manager) {
        for (int i = Utility.getRandomNumber(3, 6); i > 0; i--) {
            int j= Utility.getRandomNumber(1,tilesNoWall.size());
            Enemy e = EnemyFactory.slime(tilesNoWall.get(j-1));
            manager.add(e);
        }
    }

    /**
     * Initializes Zombie enemies for the map.
     * Zombies are randomly placed within the map.
     * @param manager the manager handling the entities
     */
    private static void initializeZombie(ElementInterface manager) {
    	for (int i = Utility.getRandomNumber(2, 5); i > 0; i--) {
            int j= Utility.getRandomNumber(1,tilesNoWall.size());
            Enemy e = EnemyFactory.zombie(tilesNoWall.get(j-1));
            manager.add(e);
        }
    }

    /**
     * Initializes Ghost enemies for the map.
     * Ghosts are randomly placed within the map.
     * @param manager the manager handling the entities
     */
    private static void initializeGhost(ElementInterface manager) {
    	for (int i = Utility.getRandomNumber(1, 4); i > 0; i--) {
            int j= Utility.getRandomNumber(1,tilesNoWall.size());
            Enemy e = EnemyFactory.ghost(tilesNoWall.get(j-1));
            manager.add(e);
        }
    }

    /**
     * Initializes the Boss for the map at a random position.
     * @param manager the manager handling the entities
     */
    private static void initializeBoss(ElementInterface manager) {
        int x = 0;
        int y = 0;
        int a = Utility.getRandomNumber(1, 3);
        switch (a) {
            case 1: {
                x = 2;
                y = 4;
                break;
            }
            case 2: {
                x = 2;
                y = (GameConfig.COLUMN_COUNT1 - 1) / 2;
                break;
            }
            case 3: {
                x = 2;
                y = (GameConfig.COLUMN_COUNT1 - 5);
                break;
            }
        }

        Tile t = new Tile(x, y);
        Boss b = EnemyFactory.boss1(t);
        manager.setB(b);
    }

    /**
     * Initializes the player with a specified type (warrior, mage, assassin).
     * @param map the map to place the player on
     * @param manager the manager handling the entities
     * @param type the type of player to initialize
     */
    private static void intializePlayer(Map map, ElementInterface manager, String type) {
        Tile tile = map.getTile(GameConfig.LINE_COUNT1 - 2, (GameConfig.COLUMN_COUNT1 - 1) / 2);
        switch (type) {
            case "warior": {
                PlayerEntity player = PlayerFactory.warior(tile);
                manager.setP(player);
                break;
            }
            case "mage": {
                PlayerEntity player = PlayerFactory.mage(tile);
                manager.setP(player);
                break;
            }
            case "assasin": {
                PlayerEntity player = PlayerFactory.assasin(tile);
                manager.setP(player);
                break;
            }
        }
    }

    /**
     * Initializes a chest on the map with random loot.
     * @param manager the manager handling the entities
     */
    private static void initializeChest(ElementInterface manager) {
        int w = 0;
        int x = 0;
        int y = 0;
        int z = 0;
        int a = Utility.getRandomNumber(1, 3);
        switch (a) {
        case 1:
        	w=2;
        	x=13;
        	y=(GameConfig.COLUMN_COUNT1 - 3);
        	z=15;
        	break;
        case 2:
        	w=2;
        	x=15;
        	y=(GameConfig.COLUMN_COUNT1 - 3);
        	z=12;
        	break;
        case 3:
        	w=2;
        	x=17;
        	y=(GameConfig.COLUMN_COUNT1 - 3);
        	z=11;
        	break;
        }
        Tile t1 = new Tile(w, x);
        Chest c1 = new Chest(t1, LootTableFactory.lv1Chest(), Utility.getRandomNumber(0, 10));
        Tile t2 = new Tile(y, z);
        Chest c2 = new Chest(t2, LootTableFactory.lv1Chest(), Utility.getRandomNumber(0, 10));
        manager.add(c1);
        manager.add(c2);
    }

    /**
     * Initializes a shop on the map with a specified loot table.
     * @param manager the manager handling the entities
     */
    private static void initializeShop(ElementInterface manager) {
    	int x = 0;
    	int y = 0;
    	int a = Utility.getRandomNumber(1, 2);
        switch (a) {
        case 1:
        	x = 6;
        	y = 7;
        	break;
        case 2:
        	x = (GameConfig.COLUMN_COUNT1 -6);
        	y = (GameConfig.LINE_COUNT1 - 6);
        	break;
        }
        Tile t = new Tile(x, y);
        Shop s = new Shop(t, LootTableFactory.lv1Shop(), 100);
        manager.setShop(s);
    }
}

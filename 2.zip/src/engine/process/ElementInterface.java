package engine.process;

import java.util.ArrayList;

import engine.map.Map;
import engine.map.Tile;
import engine.mobile.Boss;
import engine.mobile.Enemy;
import engine.mobile.Spell;
import engine.player.PlayerEntity;
import engine.staticObject.Chest;
import engine.staticObject.Shop;
import engine.staticObject.Wall;
import engine.stats.Item;

/**
 * Interface representing a general element that has a position on the map.
 * Any class implementing this interface must provide access to its position.
 * 
 * @author Auto
 * @version 0.1
 */
public interface ElementInterface {

    void setP(PlayerEntity player);
    void moveLeftPlayer();
    void moveRightPlayer();
    void moveUpPlayer();
    void moveDownPlayer();
    void add(Wall w);
    void add(Enemy e);
    void add(Chest c);
    void nextRound();
    void moveEnemy();
    void attack();
    void use();
    void enemyAttack();
    void dropItem(Item i);
    void equipItem(Item i1);
    void unequipItem(Item i1);
    PlayerEntity getP();
    ArrayList<Wall> getW();
    ArrayList<Enemy> getE();
    ArrayList<Chest> getChests();
    Shop getShop();
    Boss getB();
    void setMap(Map map);
    void setW(ArrayList<Wall> w);
    void setE(ArrayList<Enemy> e);
    void setChests(ArrayList<Chest> chests);
    void setShop(Shop shop);
    void setB(Boss b);
    void setT(int i);
    ArrayList<Tile> getAZ();
    ArrayList<Tile> getAZL();
    ArrayList<Tile> getAZEL();
    void setAZ(ArrayList<Tile> az);
    void setAZL(ArrayList<Tile> azl);
    void setAZEL(ArrayList<Tile> azeLast);
    boolean shopAccess();
    void buyItem(Item item);
    void sellItem(Item item);
    void useSpell(Spell s);
    ArrayList<Tile> getAZSL();
    void setAZSL(ArrayList<Tile> attackZoneSpellLast);
    void setLvlUp(int lvl);
    int getLvlUp();
    void increaseLife();
    void increaseMana();
    void increaseStam();
}

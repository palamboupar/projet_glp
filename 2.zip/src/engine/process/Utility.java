package engine.process;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.log4j.Logger;

import log.LoggerUtility;

/**
 * Utility class providing helper methods for various game functionalities, such as reading images and generating random numbers.
 * 
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class Utility {
    private static Logger logger = LoggerUtility.getLogger(Utility.class,"html");

    /**
     * Reads an image from a specified file path.
     * @param filePath the path to the image file
     * @return the Image object read from the file, or null if there is an error
     */
    public static Image readImage(String filePath) {
        try {
            return ImageIO.read(new File(filePath));
        } catch (IOException e) {
            logger.error("Missing textures in game files");
            return null;
        }
    }

    /**
     * Generates a random number between a given range.
     * @param min the minimum value of the range
     * @param max the maximum value of the range
     * @return a random integer between min and max (inclusive)
     */
    public static int getRandomNumber(int min, int max) {
        return (int) (Math.random() * (max + 1 - min)) + min;
    }
}

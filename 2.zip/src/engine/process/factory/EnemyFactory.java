package engine.process.factory;

import java.util.ArrayList;
import engine.map.Tile;
import engine.mobile.Boss;
import engine.mobile.Enemy;
import engine.stats.EnemyStatistics;
import engine.stats.Stat;

/**
 * Factory class used to create instances of enemies and bosses.
 * Each method generates a specific type of enemy with predefined stats and loot.
 * 
 * @author Auto
 * @version 0.1
 */
public class EnemyFactory {

    /**
     * Creates a 'slime' enemy.
     * @param tile initial position on the map
     * @return a new Enemy instance
     */
    public static Enemy slime(Tile tile) {
        String type="slime";
        Stat hp=new Stat("HP",2);
        Stat speed=new Stat("Speed",2);
        Stat dmg=new Stat("dmg",1);
        Stat rangeFwd=new Stat("rangeFwd",0);
        Stat rangeSide=new Stat("rangeSide",0);
        Stat maxHp=new Stat("maxHp",2);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=1;
        int enemyGold=1;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.lvl1mobLoot(), enemyXp, enemyGold);
        return new Enemy(tile, stats);
    }

    /**
     * Creates a 'zombie' enemy.
     * @param tile initial position on the map
     * @return a new Enemy instance
     */
    public static Enemy zombie(Tile tile) {
        String type="zombie";
        Stat hp=new Stat("HP",3);
        Stat speed=new Stat("Speed",3);
        Stat dmg=new Stat("dmg",3);
        Stat rangeFwd=new Stat("rangeFwd",0);
        Stat rangeSide=new Stat("rangeSide",1);
        Stat maxHp=new Stat("maxHp",3);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=2;
        int enemyGold=1;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.lvl1mobLoot(), enemyXp, enemyGold);
        return new Enemy(tile, stats);
    }

    /**
     * Creates a 'ghost' enemy.
     * @param tile initial position on the map
     * @return a new Enemy instance
     */
    public static Enemy ghost(Tile tile) {
        String type="ghost";
        Stat hp=new Stat("HP",3);
        Stat speed=new Stat("Speed",3);
        Stat dmg=new Stat("dmg",2);
        Stat rangeFwd=new Stat("rangeFwd",1);
        Stat rangeSide=new Stat("rangeSide",1);
        Stat maxHp=new Stat("maxHp",3);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=2;
        int enemyGold=2;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.lvl1mobLoot(), enemyXp, enemyGold);
        return new Enemy(tile, stats);
    }

    /**
     * Creates the first boss of the game.
     * @param tile initial position on the map
     * @return a new Boss instance
     */
    public static Boss boss1(Tile tile) {
        String type="boss1";
        Stat hp=new Stat("HP",20);
        Stat speed=new Stat("Speed",2);
        Stat dmg=new Stat("dmg",10);
        Stat rangeFwd=new Stat("rangeFwd",2);
        Stat rangeSide=new Stat("rangeSide",2);
        Stat maxHp=new Stat("maxHp",20);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=10;
        int enemyGold=10;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.boss1mobLoot(), enemyXp, enemyGold);
        return new Boss(tile, stats);
    }

    /**
     * Creates a 'spirit' enemy.
     * @param tile initial position on the map
     * @return a new Enemy instance
     */
    public static Enemy spirit(Tile tile) {
        String type="spirit";
        Stat hp=new Stat("HP",4);
        Stat speed=new Stat("Speed",4);
        Stat dmg=new Stat("dmg",4);
        Stat rangeFwd=new Stat("rangeFwd",2);
        Stat rangeSide=new Stat("rangeSide",2);
        Stat maxHp=new Stat("maxHp",4);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=4;
        int enemyGold=4;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.lvl2mobLoot(), enemyXp, enemyGold);
        return new Enemy(tile, stats);
    }

    /**
     * Creates a 'salamander' enemy.
     * @param tile initial position on the map
     * @return a new Enemy instance
     */
    public static Enemy salamander(Tile tile) {
        String type="salamander";
        Stat hp=new Stat("HP",4);
        Stat speed=new Stat("Speed",1);
        Stat dmg=new Stat("dmg",3);
        Stat rangeFwd=new Stat("rangeFwd",1);
        Stat rangeSide=new Stat("rangeSide",2);
        Stat maxHp=new Stat("maxHp",4);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=3;
        int enemyGold=5;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.lvl2mobLoot(), enemyXp, enemyGold);
        return new Enemy(tile, stats);
    }

    /**
     * Creates a 'fire skeleton' enemy.
     * @param tile initial position on the map
     * @return a new Enemy instance
     */
    public static Enemy fire_skeleton(Tile tile) {
        String type="fire_skeleton";
        Stat hp=new Stat("HP",5);
        Stat speed=new Stat("Speed",3);
        Stat dmg=new Stat("dmg",6);
        Stat rangeFwd=new Stat("rangeFwd",2);
        Stat rangeSide=new Stat("rangeSide",4);
        Stat maxHp=new Stat("maxHp",5);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=5;
        int enemyGold=3;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.lvl2mobLoot(), enemyXp, enemyGold);
        return new Enemy(tile, stats);
    }

    /**
     * Creates the second boss of the game.
     * @param tile initial position on the map
     * @return a new Boss instance
     */
    public static Boss boss2(Tile tile) {
        String type="boss2";
        Stat hp=new Stat("HP",30);
        Stat speed=new Stat("Speed",2);
        Stat dmg=new Stat("dmg",15);
        Stat rangeFwd=new Stat("rangeFwd",3);
        Stat rangeSide=new Stat("rangeSide",3);
        Stat maxHp=new Stat("maxHp",30);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=10;
        int enemyGold=10;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.boss1mobLoot(), enemyXp, enemyGold);
        return new Boss(tile, stats);
    }

    /**
     * Creates a 'big spirit' enemy.
     * @param tile initial position on the map
     * @return a new Enemy instance
     */
    public static Enemy big_spirit(Tile tile) {
        String type="big_spirit";
        Stat hp=new Stat("HP",6);
        Stat speed=new Stat("Speed",2);
        Stat dmg=new Stat("dmg",6);
        Stat rangeFwd=new Stat("rangeFwd",4);
        Stat rangeSide=new Stat("rangeSide",4);
        Stat maxHp=new Stat("maxHp",6);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=6;
        int enemyGold=6;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.lvl3mobLoot(), enemyXp, enemyGold);
        return new Enemy(tile, stats);
    }

    /**
     * Creates a 'golem' enemy.
     * @param tile initial position on the map
     * @return a new Enemy instance
     */
    public static Enemy golem(Tile tile) {
        String type="golem";
        Stat hp=new Stat("HP",8);
        Stat speed=new Stat("Speed",3);
        Stat dmg=new Stat("dmg",7);
        Stat rangeFwd=new Stat("rangeFwd",5);
        Stat rangeSide=new Stat("rangeSide",2);
        Stat maxHp=new Stat("maxHp",8);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=8;
        int enemyGold=8;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.lvl3mobLoot(), enemyXp, enemyGold);
        return new Enemy(tile, stats);
    }

    /**
     * Creates an 'ice octopus' enemy.
     * @param tile initial position on the map
     * @return a new Enemy instance
     */
    public static Enemy ice_octopus(Tile tile) {
        String type="ice_octopus";
        Stat hp=new Stat("HP",8);
        Stat speed=new Stat("Speed",4);
        Stat dmg=new Stat("dmg",5);
        Stat rangeFwd=new Stat("rangeFwd",3);
        Stat rangeSide=new Stat("rangeSide",6);
        Stat maxHp=new Stat("maxHp",8);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=6;
        int enemyGold=10;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.lvl3mobLoot(), enemyXp, enemyGold);
        return new Enemy(tile, stats);
    }
    
    /**
     * Creates the second boss of the game.
     * @param tile initial position on the map
     * @return a new Boss instance
     */
    public static Boss boss3(Tile tile) {
        String type="boss2";
        Stat hp=new Stat("HP",40);
        Stat speed=new Stat("Speed",2);
        Stat dmg=new Stat("dmg",20);
        Stat rangeFwd=new Stat("rangeFwd",4);
        Stat rangeSide=new Stat("rangeSide",4);
        Stat maxHp=new Stat("maxHp",40);
        ArrayList<Stat> tmpStats=new ArrayList <Stat>();
        tmpStats.add(hp); tmpStats.add(speed); tmpStats.add(dmg);
        tmpStats.add(rangeFwd); tmpStats.add(rangeSide); tmpStats.add(maxHp);
        int enemyXp=10;
        int enemyGold=10;
        EnemyStatistics stats=new EnemyStatistics(type, tmpStats, LootTableFactory.boss3mobLoot(), enemyXp, enemyGold);
        return new Boss(tile, stats);
    }
}

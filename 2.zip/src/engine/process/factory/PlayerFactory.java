package engine.process.factory;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import engine.map.Tile;
import engine.player.*;
import engine.stats.Item;
import engine.stats.Stat;
import engine.stats.Weapon;
import log.LoggerUtility;

/**
 * Factory class for creating different player classes: warrior, mage, and assassin.
 * Each method returns a fully initialized PlayerEntity with appropriate stats and equipment.
 * 
 * @author Auto
 * @version 0.1
 */
public class PlayerFactory {

    private static Logger logger = LoggerUtility.getLogger(PlayerFactory.class, "html");

    /**
     * Creates a Warrior class player with high HP and strength.
     * @param tile the starting position of the player
     * @return a new PlayerEntity of type 'warior'
     */
    public static PlayerEntity warior(Tile tile) {
        String type = "warior";
        Weapon playerWeapon = ItemFactory.woodenSword();
        Stat hp = new Stat("HP", 15);
        Stat maxHP = new Stat("maxHP", 10);
        Stat str = new Stat("Str", 3);
        Stat mana = new Stat("Mana", 10);
        Stat maxMana = new Stat("maxMana", 10);
        Stat magic = new Stat("Magic", 2);
        Stat stam = new Stat("Stam", 10);
        Stat maxStam = new Stat("maxStam", 10);
        Stat def = new Stat("Def", 2);
        ArrayList<Stat> tmpStats = new ArrayList<Stat>();
        tmpStats.add(hp);       // 0
        tmpStats.add(maxHP);    // 1
        tmpStats.add(str);      // 2
        tmpStats.add(mana);     // 3
        tmpStats.add(maxMana);  // 4
        tmpStats.add(magic);    // 5
        tmpStats.add(stam);     // 6
        tmpStats.add(maxStam);  // 7
        tmpStats.add(def);      // 8

        ArrayList<Item> equipementsTmp = new ArrayList<Item>();
        equipementsTmp.add(0, ItemFactory.woodenHelmet());     // 0
        equipementsTmp.add(1, ItemFactory.woodenChestplate()); // 1
        equipementsTmp.add(2, ItemFactory.woodenLegging());    // 2
        equipementsTmp.add(3, ItemFactory.woodenBoots());      // 3
        equipementsTmp.add(4, ItemFactory.healthPotion());     // 4

        ArrayList<Item> inventoryTmp = new ArrayList<Item>();
        inventoryTmp.add(ItemFactory.manaPotion());

        PlayerStatistics stats = new PlayerStatistics(type, playerWeapon, tmpStats, equipementsTmp, inventoryTmp);
        PlayerEntity player = new PlayerEntity(tile, stats);
        logger.info("Player creation with class : " + player.getStats().getType());
        return player;
    }
    
    /**
     * Creates a Mage class player with high mana and magic stats.
     * @param tile the starting position of the player
     * @return a new PlayerEntity of type 'mage'
     */
    public static PlayerEntity mage(Tile tile) {
        String type = "mage";
        Weapon playerWeapon = ItemFactory.woodenSword();
        Stat hp = new Stat("HP", 10);
        Stat maxHP = new Stat("maxHP", 10);
        Stat str = new Stat("Str", 1);
        Stat mana = new Stat("Mana", 30);
        Stat maxMana = new Stat("maxMana", 10);
        Stat magic = new Stat("Magic", 3);
        Stat stam = new Stat("Stam", 20);
        Stat maxStam = new Stat("maxStam", 10);
        Stat def = new Stat("Def", 2);

        ArrayList<Stat> tmpStats = new ArrayList<Stat>();
        tmpStats.add(hp); tmpStats.add(maxHP); tmpStats.add(str);
        tmpStats.add(mana); tmpStats.add(maxMana); tmpStats.add(magic);
        tmpStats.add(stam); tmpStats.add(maxStam); tmpStats.add(def);

        ArrayList<Item> equipementsTmp = new ArrayList<Item>();
        equipementsTmp.add(0, ItemFactory.woodenHelmet());
        equipementsTmp.add(1, ItemFactory.woodenChestplate());
        equipementsTmp.add(2, ItemFactory.woodenLegging());
        equipementsTmp.add(3, ItemFactory.woodenBoots());
        equipementsTmp.add(4, ItemFactory.healthPotion());

        ArrayList<Item> inventoryTmp = new ArrayList<Item>();
        inventoryTmp.add(ItemFactory.healthPotion());

        PlayerStatistics stats = new PlayerStatistics(type, playerWeapon, tmpStats, equipementsTmp, inventoryTmp);
        PlayerEntity player = new PlayerEntity(tile, stats);
        logger.info("Player creation with class : " + player.getStats().getType());
        return player;
    }
    
    /**
     * Creates an Assassin class player with high stamina and defense.
     * @param tile the starting position of the player
     * @return a new PlayerEntity of type 'assasin'
     */
    public static PlayerEntity assasin(Tile tile) {
        String type = "assasin";
        Weapon playerWeapon = ItemFactory.woodenSword();
        Stat hp = new Stat("HP", 20);
        Stat maxHP = new Stat("maxHP", 10);
        Stat str = new Stat("Str", 2);
        Stat mana = new Stat("Mana", 10);
        Stat maxMana = new Stat("maxMana", 10);
        Stat magic = new Stat("Magic", 1);
        Stat stam = new Stat("Stam", 30);
        Stat maxStam = new Stat("maxStam", 10);
        Stat def = new Stat("Def", 3);

        ArrayList<Stat> tmpStats = new ArrayList<Stat>();
        tmpStats.add(hp); tmpStats.add(maxHP); tmpStats.add(str);
        tmpStats.add(mana); tmpStats.add(maxMana); tmpStats.add(magic);
        tmpStats.add(stam); tmpStats.add(maxStam); tmpStats.add(def);

        ArrayList<Item> equipementsTmp = new ArrayList<Item>();
        equipementsTmp.add(0, ItemFactory.woodenHelmet());
        equipementsTmp.add(1, ItemFactory.woodenChestplate());
        equipementsTmp.add(2, ItemFactory.woodenLegging());
        equipementsTmp.add(3, ItemFactory.woodenBoots());
        equipementsTmp.add(4, ItemFactory.manaPotion());

        ArrayList<Item> inventoryTmp = new ArrayList<Item>();
        inventoryTmp.add(ItemFactory.healthPotion());

        PlayerStatistics stats = new PlayerStatistics(type, playerWeapon, tmpStats, equipementsTmp, inventoryTmp);
        PlayerEntity player = new PlayerEntity(tile, stats);
        logger.info("Player creation with class : " + player.getStats().getType());
        return player;
    }
}




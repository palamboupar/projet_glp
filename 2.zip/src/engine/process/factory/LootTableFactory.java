package engine.process.factory;

import java.util.ArrayList;
import engine.process.Utility;
import engine.stats.Item;

/**
 * Factory class responsible for generating loot tables based on level or enemy type.
 * Each method returns a list of items that can drop from a specific type of enemy or chest.
 * 
 * @author Auto
 * @version 0.1
 */
public class LootTableFactory {

    /**
     * Returns a random loot list for level 1 monsters.
     * @return list of items
     */
    public static ArrayList<Item> lvl1mobLoot() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 7);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.knife());
                    break;
            }
        }
        return tmpLoot;
    }

    /**
     * Returns a random loot list for level 2 monsters.
     * @return list of items
     */
    public static ArrayList<Item> lvl2mobLoot() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 9);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.boomerang());
                    break;
                case 7:
                    tmpLoot.add(ItemFactory.ironSword());
                    break;
                case 8:
                    tmpLoot.add(ItemFactory.woodenLegging());
                    break;
            }
        }
        return tmpLoot;
    }

    /**
     * Returns a random loot list for level 3 monsters.
     * @return list of items
     */
    public static ArrayList<Item> lvl3mobLoot() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 9);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.goldBoots());
                    break;
                case 7:
                    tmpLoot.add(ItemFactory.ironSword());
                    break;
                case 8:
                    tmpLoot.add(ItemFactory.goldLegging());
                    break;
            }
        }
        return tmpLoot;
    }

    /**
     * Returns the loot list for the first boss.
     * @return list of items
     */
    public static ArrayList<Item> boss1mobLoot() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 9);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.woodenHelmet());
                    break;
                case 7:
                    tmpLoot.add(ItemFactory.woodenSword());
                    break;
                case 8:
                    tmpLoot.add(ItemFactory.woodenLegging());
                    break;
            }
        }
        return tmpLoot;
    }

    /**
     * Returns the loot list for the second boss.
     * @return list of items
     */
    public static ArrayList<Item> boss2mobLoot() {
    	ArrayList<Item> tmpLoot = new ArrayList<Item>();
    	for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 9);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.goldChestplate());
                    break;
                case 7:
                    tmpLoot.add(ItemFactory.knife());
                    break;
                case 8:
                    tmpLoot.add(ItemFactory.goldLegging());
                    break;
            }
        }
        return tmpLoot;
    }
    
    /**
     * Returns the loot list for the third boss.
     * @return list of items
     */
    public static ArrayList<Item> boss3mobLoot() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        return tmpLoot;
    }


    /**
     * Returns the loot list for a level 1 chest.
     * @return list of items
     */
    public static ArrayList<Item> lv1Chest() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 7);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.woodenChestplate());
                    break;
            }
        }
        return tmpLoot;
    }

    /**
     * Returns the loot list for a level 2 chest.
     * @return list of items
     */
    public static ArrayList<Item> lv2Chest() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 7);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.goldChestplate());
                    break;
            }
        }
        return tmpLoot;
    }

    /**
     * Returns the loot list for a level 3 chest.
     * @return list of items
     */
    public static ArrayList<Item> lv3Chest() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 7);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.knife());
                    break;
            }
        }
        return tmpLoot;
    }

    /**
     * Returns the loot list for a level 1 shop.
     * @return list of items
     */
    public static ArrayList<Item> lv1Shop() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 7);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.knife());
                    break;
            }
        }
        return tmpLoot;
    }

    /**
     * Returns the loot list for a level 2 shop.
     * @return list of items
     */
    public static ArrayList<Item> lv2Shop() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 8);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.ironSword());
                    break;
                case 7:
                    tmpLoot.add(ItemFactory.boomerang());
                    break;
            }
        }
        return tmpLoot;
    }

    /**
     * Returns the loot list for a level 3 shop.
     * @return list of items
     */
    public static ArrayList<Item> lv3Shop() {
        ArrayList<Item> tmpLoot = new ArrayList<Item>();
        for (int i = Utility.getRandomNumber(0, 2); i > 0; i--) {
            int j = Utility.getRandomNumber(0, 8);
            switch (j) {
                case 0: case 1:
                    tmpLoot.add(ItemFactory.healthPotion());
                    break;
                case 2: case 3:
                    tmpLoot.add(ItemFactory.manaPotion());
                    break;
                case 4: case 5:
                    tmpLoot.add(ItemFactory.stamPotion());
                    break;
                case 6:
                    tmpLoot.add(ItemFactory.goldHelmet());
                    break;
                case 7:
                    tmpLoot.add(ItemFactory.goldBoots());
                    break;
            }
        }
        return tmpLoot;
    }
}
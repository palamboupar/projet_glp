package engine.process.factory;

import java.util.ArrayList;

import engine.stats.Equipement;
import engine.stats.Potion;
import engine.stats.Stat;
import engine.stats.Weapon;

/**
 * Factory class used to create various in-game items including equipment, weapons, and potions.
 * Each static method creates a specific item with associated stats and properties.
 * 
 * @author Auto
 * @version 0.1
 */
public class ItemFactory {

    /**
     * equipment  
     * stats (dans l'ordre) :
     * - hpMaxBonus
     * - manaMaxBonus
     * - stamMaxBonus
     * - strenghBonus
     * - magicBonus
     * - defenseBonus
     */

    /**
     * Creates a default equipment with no stat bonuses.
     * @return rien item
     */
    public static Equipement rien() {
        Stat hpMaxBonus = new Stat("hpMaxBonus", 0);
        Stat manaMaxBonus = new Stat("manaMaxBonus", 0);
        Stat stamMaxBonus = new Stat("stamMaxBonus", 0);
        Stat strenghBonus = new Stat("strenghBonus", 0);
        Stat magicBonus = new Stat("magicBonus", 0);
        Stat defenseBonus = new Stat("defenseBonus", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hpMaxBonus); stats.add(manaMaxBonus); stats.add(stamMaxBonus);
        stats.add(strenghBonus); stats.add(magicBonus); stats.add(defenseBonus);
        return new Equipement("rien", stats, 0, 6);
    }

    /**
     * Creates a basic helmet that gives a small HP bonus.
     * @return woodenHelmet item
     */
    public static Equipement woodenHelmet() {
        Stat hpMaxBonus = new Stat("hpMaxBonus", 1);
        Stat manaMaxBonus = new Stat("manaMaxBonus", 0);
        Stat stamMaxBonus = new Stat("stamMaxBonus", 0);
        Stat strenghBonus = new Stat("strenghBonus", 0);
        Stat magicBonus = new Stat("magicBonus", 0);
        Stat defenseBonus = new Stat("defenseBonus", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hpMaxBonus); stats.add(manaMaxBonus); stats.add(stamMaxBonus);
        stats.add(strenghBonus); stats.add(magicBonus); stats.add(defenseBonus);
        return new Equipement("wooden helmet", stats, 3, 0);
    }

    /**
     * Creates an advanced helmet with higher overall stats.
     * @return goldHelmet item
     */
    public static Equipement goldHelmet() {
        Stat hpMaxBonus = new Stat("hpMaxBonus", 0);
        Stat manaMaxBonus = new Stat("manaMaxBonus", 0);
        Stat stamMaxBonus = new Stat("stamMaxBonus", 0);
        Stat strenghBonus = new Stat("strenghBonus", 0);
        Stat magicBonus = new Stat("magicBonus", 0);
        Stat defenseBonus = new Stat("defenseBonus", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hpMaxBonus); stats.add(manaMaxBonus); stats.add(stamMaxBonus);
        stats.add(strenghBonus); stats.add(magicBonus); stats.add(defenseBonus);
        return new Equipement("gold helmet", stats, 19, 0);
    }
    
    /**
     * Creates a basic chestplate offering minimal defense.
     * @return woodenChestplate item
     */
    public static Equipement woodenChestplate() {
        Stat hpMaxBonus = new Stat("hpMaxBonus", 0);
        Stat manaMaxBonus = new Stat("manaMaxBonus", 2);
        Stat stamMaxBonus = new Stat("stamMaxBonus", 0);
        Stat strenghBonus = new Stat("strenghBonus", 0);
        Stat magicBonus = new Stat("magicBonus", 0);
        Stat defenseBonus = new Stat("defenseBonus", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hpMaxBonus); stats.add(manaMaxBonus); stats.add(stamMaxBonus);
        stats.add(strenghBonus); stats.add(magicBonus); stats.add(defenseBonus);
        return new Equipement("wooden chestplate", stats, 3, 1);
    }

    /**
     * Creates a high-level chestplate with strong bonuses.
     * @return goldChestplate item
     */
    public static Equipement goldChestplate() {
        Stat hpMaxBonus = new Stat("hpMaxBonus", 0);
        Stat manaMaxBonus = new Stat("manaMaxBonus", 0);
        Stat stamMaxBonus = new Stat("stamMaxBonus", 0);
        Stat strenghBonus = new Stat("strenghBonus", 0);
        Stat magicBonus = new Stat("magicBonus", 0);
        Stat defenseBonus = new Stat("defenseBonus", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hpMaxBonus); stats.add(manaMaxBonus); stats.add(stamMaxBonus);
        stats.add(strenghBonus); stats.add(magicBonus); stats.add(defenseBonus);
        return new Equipement("gold chestplate", stats, 22, 1);
    }

    /**
     * Creates a basic legging with stamina bonus.
     * @return woodenLegging item
     */
    public static Equipement woodenLegging() {
        Stat hpMaxBonus = new Stat("hpMaxBonus", 0);
        Stat manaMaxBonus = new Stat("manaMaxBonus", 0);
        Stat stamMaxBonus = new Stat("stamMaxBonus", 3);
        Stat strenghBonus = new Stat("strenghBonus", 0);
        Stat magicBonus = new Stat("magicBonus", 0);
        Stat defenseBonus = new Stat("defenseBonus", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hpMaxBonus); stats.add(manaMaxBonus); stats.add(stamMaxBonus);
        stats.add(strenghBonus); stats.add(magicBonus); stats.add(defenseBonus);
        return new Equipement("wooden legging", stats, 3, 2);
    }

    /**
     * Creates a high-level legging with balanced stats.
     * @return goldLegging item
     */
    public static Equipement goldLegging() {
        Stat hpMaxBonus = new Stat("hpMaxBonus", 0);
        Stat manaMaxBonus = new Stat("manaMaxBonus", 0);
        Stat stamMaxBonus = new Stat("stamMaxBonus", 0);
        Stat strenghBonus = new Stat("strenghBonus", 0);
        Stat magicBonus = new Stat("magicBonus", 0);
        Stat defenseBonus = new Stat("defenseBonus", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hpMaxBonus); stats.add(manaMaxBonus); stats.add(stamMaxBonus);
        stats.add(strenghBonus); stats.add(magicBonus); stats.add(defenseBonus);
        return new Equipement("gold legging", stats, 20, 2);
    }
    
    /**
     * Creates beginner boots with a small speed bonus.
     * @return woodenBoots item
     */
    public static Equipement woodenBoots() {
        Stat hpMaxBonus = new Stat("hpMaxBonus", 0);
        Stat manaMaxBonus = new Stat("manaMaxBonus", 0);
        Stat stamMaxBonus = new Stat("stamMaxBonus", 0);
        Stat strenghBonus = new Stat("strenghBonus", 0);
        Stat magicBonus = new Stat("magicBonus", 0);
        Stat defenseBonus = new Stat("defenseBonus", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hpMaxBonus); stats.add(manaMaxBonus); stats.add(stamMaxBonus);
        stats.add(strenghBonus); stats.add(magicBonus); stats.add(defenseBonus);
        return new Equipement("wooden boots", stats, 3, 3);
    }

    /**
     * Creates gold-plated boots for improved mobility.
     * @return goldBoots item
     */
    public static Equipement goldBoots() {
        Stat hpMaxBonus = new Stat("hpMaxBonus", 0);
        Stat manaMaxBonus = new Stat("manaMaxBonus", 0);
        Stat stamMaxBonus = new Stat("stamMaxBonus", 0);
        Stat strenghBonus = new Stat("strenghBonus", 0);
        Stat magicBonus = new Stat("magicBonus", 0);
        Stat defenseBonus = new Stat("defenseBonus", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hpMaxBonus); stats.add(manaMaxBonus); stats.add(stamMaxBonus);
        stats.add(strenghBonus); stats.add(magicBonus); stats.add(defenseBonus);
        return new Equipement("gold boots", stats, 17, 3);
    }

    // Weapons

    /**
     * Creates a basic wooden sword.
     * @return woodenSword item
     */
    public static Weapon woodenSword() {
        Stat Dmg = new Stat("Dmg", 1);
        Stat StamCost = new Stat("StamCost", 1);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(Dmg); stats.add(StamCost);
        return new Weapon("wooden Sword", stats, 10, 2, 1, 5);
    }

    /**
     * Creates a stronger iron sword.
     * @return ironSword item
     */
    public static Weapon ironSword() {
        Stat Dmg = new Stat("Dmg", 4);
        Stat StamCost = new Stat("StamCost", 3);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(Dmg); stats.add(StamCost);
        return new Weapon("iron sword", stats, 20, 2, 1, 5);
    }
    
    /**
     * Creates a fast knife with high stamina cost.
     * @return knife item
     */
    public static Weapon knife() {
        Stat Dmg = new Stat("Dmg", 2);
        Stat StamCost = new Stat("StamCost", 5);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(Dmg); stats.add(StamCost);
        return new Weapon("knife", stats, 15, 1, 1, 5);
    }

    /**
     * Creates a boomerang with forward and side range.
     * @return boomerang item
     */
    public static Weapon boomerang() {
        Stat Dmg = new Stat("Dmg", 3);
        Stat StamCost = new Stat("StamCost", 4);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(Dmg); stats.add(StamCost);
        return new Weapon("boomerang", stats, 12, 1, 5, 1);
    }

    // Potions

    /**
     * Creates a potion that does nothing.
     * @return rienp potion
     */
    public static Potion rienp() {
        Stat hphealed = new Stat("hp", 0);
        Stat duration = new Stat("duration", 0);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hphealed); stats.add(duration);
        return new Potion("rien", stats, 0, 4);
    }

    /**
     * Creates a health potion that restores HP over time.
     * @return healthPotion item
     */
    public static Potion healthPotion() {
        Stat hphealed = new Stat("hp", 2);
        Stat duration = new Stat("duration", 10);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hphealed); stats.add(duration);
        return new Potion("health potion", stats, 10, 4);
    }

    /**
     * Creates a potion to restore mana.
     * @return manaPotion item
     */
    public static Potion manaPotion() {
        Stat manahealed = new Stat("mana", 1);
        Stat duration = new Stat("duration", 10);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(manahealed); stats.add(duration);
        return new Potion("mana potion", stats, 10, 4);
    }

    /**
     * Creates a potion to restore stamina.
     * @return stamPotion item
     */
    public static Potion stamPotion() {
        Stat stamhealed = new Stat("stamina", 2);
        Stat duration = new Stat("duration", 10);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(stamhealed); stats.add(duration);
        return new Potion("stamina potion", stats, 10, 4);
    }
    public static Potion ImortalitySpell() {//not realy a potion but works the same
        Stat hphealed = new Stat("imortality", 0);
        Stat duration = new Stat("duration", 20);
        ArrayList<Stat> stats = new ArrayList<>();
        stats.add(hphealed); stats.add(duration);
        return new Potion("imortality", stats, 0, 4);
    }
}



    

package engine.process.factory;

import java.util.ArrayList;

//import org.apache.log4j.Logger;

import engine.map.Tile;
import engine.mobile.Spell;
import engine.player.PlayerEntity;
import engine.stats.SpellStats;
import engine.stats.Stat;
//import log.LoggerUtility;

public class SpellFactory {
	//private static Logger logger = LoggerUtility.getLogger(PlayerFactory.class, "html");

    /**
     * Creates a Warrior class player with high HP and strength.
     * @param tile the starting position of the player
     * @return a new PlayerEntity of type 'warior'
     */
    public static Spell fireball(PlayerEntity player) {
    	int type=1;
    	Stat manaCost=new Stat("manaCost",3);
    	Stat damage=new Stat("dammage",5);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		int lm=player.getLM();
		switch(lm){
		case(0):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()-3));
			break;
		case(1):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()-3));
		break;
		case(2):
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()-1));
			break;
		case(3):
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()-1));
			break;
		}
		SpellStats stat=new SpellStats("fireball", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,1);
    }
    
    public static Spell explosion(PlayerEntity player) {
    	int type=1;
    	Stat manaCost=new Stat("manaCost",9);
    	Stat damage=new Stat("dammage",7);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		int lm=player.getLM();
		switch(lm){
		case(0):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-5));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-6));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()-5));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()-5));
			break;
		case(1):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+5));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+6));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()+5));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()+5));
			break;
		case(2):
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-5,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-6,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()-1));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()-1));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine()-5,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()-5,player.getPosition().getColumn()-1));
			break;
		case(3):
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+5,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+6,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()-1));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()-1));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine()+5,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()+5,player.getPosition().getColumn()-1));
		}
		SpellStats stat=new SpellStats("explosion", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,2);
    }
    
    public static Spell firezone(PlayerEntity player) {
    	int type=1;
    	Stat manaCost=new Stat("manaCost",3);
    	Stat damage=new Stat("dammage",5);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		int lm=player.getLM();
		switch(lm){
		case(0):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()-3));
			break;
		case(1):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()-3));
		break;
		case(2):
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()-1));
			break;
		case(3):
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()-1));
			break;
		}
		SpellStats stat=new SpellStats("fire zone", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,3);
    }
    
    public static Spell volcanoBlast(PlayerEntity player) {
    	int type=1;
    	Stat manaCost=new Stat("manaCost",17);
    	Stat damage=new Stat("dammage",12);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		int lm=player.getLM();
		switch(lm){
		case(0):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-4));
			break;
		case(1):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+4));
		break;
		case(2):
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()));
			
			break;
		case(3):
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()));
			
			break;
		}
		SpellStats stat=new SpellStats("volcano blast", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,4);
    }
    
    public static Spell iceSpike(PlayerEntity player) {
    	int type=1;
    	Stat manaCost=new Stat("manaCost",4);
    	Stat damage=new Stat("dammage",6);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		int lm=player.getLM();
		switch(lm){
		case(0):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-1));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-5));
			break;
		case(1):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+5));
		break;
		case(2):
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-5,player.getPosition().getColumn()));
			break;
		case(3):
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+5,player.getPosition().getColumn()));
			break;
		}
		SpellStats stat=new SpellStats("ice spike", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,5);
    }
    public static Spell frost(PlayerEntity player) {
    	int type=1;
    	Stat manaCost=new Stat("manaCost",4);
    	Stat damage=new Stat("dammage",6);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		int lm=player.getLM();
		switch(lm){
		case(0):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-1));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-5));
			break;
		case(1):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+5));
		break;
		case(2):
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-5,player.getPosition().getColumn()));
			break;
		case(3):
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+5,player.getPosition().getColumn()));
			break;
		}
		SpellStats stat=new SpellStats("frost", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,6);
    }
    public static Spell tornado(PlayerEntity player) {
    	int type=1;
    	Stat manaCost=new Stat("manaCost",4);
    	Stat damage=new Stat("dammage",6);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		int lm=player.getLM();
		switch(lm){
		case(0):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-1));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-5));
			break;
		case(1):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+5));
		break;
		case(2):
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-5,player.getPosition().getColumn()));
			break;
		case(3):
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+5,player.getPosition().getColumn()));
			break;
		}
		SpellStats stat=new SpellStats("tornado", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,7);
    }
    public static Spell snowfall(PlayerEntity player) {
    	int type=1;
    	Stat manaCost=new Stat("manaCost",4);
    	Stat damage=new Stat("dammage",6);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		int lm=player.getLM();
		switch(lm){
		case(0):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-1));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()-5));
			break;
		case(1):
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+1));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+2));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+3));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+4));
			aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()+5));
		break;
		case(2):
			aoe.add(new Tile(player.getPosition().getLine()-1,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()-5,player.getPosition().getColumn()));
			break;
		case(3):
			aoe.add(new Tile(player.getPosition().getLine()+1,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+2,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+3,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+4,player.getPosition().getColumn()));
			aoe.add(new Tile(player.getPosition().getLine()+5,player.getPosition().getColumn()));
			break;
		}
		SpellStats stat=new SpellStats("snowfall", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,8);
    }
    public static Spell minorheal(PlayerEntity player) {
    	int type=0;
    	Stat manaCost=new Stat("manaCost",4);
    	Stat damage=new Stat("dammage",6);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()));
		SpellStats stat=new SpellStats("minor heal", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,9);
    }
    public static Spell majorrheal(PlayerEntity player) {
    	int type=0;
    	Stat manaCost=new Stat("manaCost",4);
    	Stat damage=new Stat("dammage",6);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()));
		SpellStats stat=new SpellStats("major heal", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,10);
    }
    public static Spell invincibility(PlayerEntity player) {
    	int type=0;
    	Stat manaCost=new Stat("manaCost",4);
    	Stat damage=new Stat("dammage",6);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()));
		SpellStats stat=new SpellStats("invincibility", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,11);
    }
    public static Spell secondchance(PlayerEntity player) {
    	int type=0;
    	Stat manaCost=new Stat("manaCost",4);
    	Stat damage=new Stat("dammage",6);
		ArrayList<Stat> stats =new ArrayList<Stat>();
		stats.add(damage);
		stats.add(manaCost);
		ArrayList<Tile> aoe =new ArrayList<Tile>();
		aoe.add(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()));
		SpellStats stat=new SpellStats("second chance", stats, aoe, type);
		return new Spell(new Tile(player.getPosition().getLine(),player.getPosition().getColumn()),stat,12);
    }
}

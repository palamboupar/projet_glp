package engine.process;

import java.util.ArrayList;
import java.util.Iterator;

import config.GameConfig;
import engine.map.*;
import engine.mobile.Boss;
import engine.mobile.Enemy;
import engine.mobile.Spell;
import engine.player.PlayerEntity;
import engine.process.factory.ItemFactory;
import engine.staticObject.Chest;
import engine.staticObject.Shop;
import engine.staticObject.Wall;
import engine.stats.Item;
import engine.stats.Potion;
import engine.stats.Weapon;
import gui.GameGUI;

/**
 * Class responsible for managing game elements like players, enemies, walls, and items.
 * Handles movement, combat, and interactions on the map.
 * 
 * @author PALEOLOGOS amael & BOUCHELAGHEM Ali
 * @version 0.1
 */
public class ElementManager implements ElementInterface, Runnable {
    private Map map;
    private ArrayList<Wall> walls = new ArrayList<Wall>();
    private PlayerEntity player;
    private ArrayList<Enemy> enemies = new ArrayList<Enemy>();
    int t = 0;
    private ArrayList<Tile> attackZone = new ArrayList<Tile>();
    private ArrayList<Tile> attackZoneLast = new ArrayList<Tile>();
    private ArrayList<Tile> attackZoneSpell = new ArrayList<Tile>();
    private ArrayList<Tile> attackZoneSpellLast = new ArrayList<Tile>();
    private ArrayList<Tile> attackZoneE = new ArrayList<Tile>();
    private ArrayList<Tile> attackZoneELast = new ArrayList<Tile>();
    private ArrayList<Chest> chests = new ArrayList<Chest>();
    private Boss b;
    private Item usedPotion;
    private Shop shop;
    private int lvlUp=0;
	private int secondChance=2;

    /**
     * Constructs the ElementManager for the given map.
     * @param map the game map to manage
     */
    public ElementManager(Map map) {
        this.map = map;
    }

    /**
     * Sets the game map in the manager.
     * @param map the map to manage
     */
    public void setMap(Map map) {
        this.map = map;
    }

    /**
     * Sets the list of walls on the map.
     * @param walls the walls to manage
     */
    public void setW(ArrayList<Wall> walls) {
        this.walls = walls;
    }

    /**
     * Sets the list of enemies on the map.
     * @param e the enemies to manage
     */
    public void setE(ArrayList<Enemy> e) {
        this.enemies = e;
    }

    /**
     * Returns the current turn counter.
     * @return the turn number
     */
    public int getT() {
        return t;
    }

    /**
     * Sets the current turn counter.
     * @param t the turn number to set
     */
    public void setT(int t) {
        this.t = t;
    }

    /**
     * Retrieves the list of enemy attack zone tiles from the last turn.
     * @return list of attack zone tiles
     */
    public ArrayList<Tile> getAZEL() {
        return attackZoneELast;
    }

    /**
     * Sets the list of enemy attack zone tiles from the last turn.
     * @param attackZoneELast the tiles to set
     */
    public void setAZEL(ArrayList<Tile> attackZoneELast) {
        this.attackZoneELast = attackZoneELast;
    }

    /**
     * Returns the list of chests on the map.
     * @return list of chests
     */
    public ArrayList<Chest> getChests() {
        return chests;
    }

    /**
     * Sets the list of chests on the map.
     * @param chests the chests to manage
     */
    public void setChests(ArrayList<Chest> chests) {
        this.chests = chests;
    }

    /**
     * Returns the shop instance on the map.
     * @return the shop
     */
    public Shop getShop() {
        return shop;
    }

    /**
     * Sets the shop instance on the map.
     * @param shop the shop to set
     */
    public void setShop(Shop shop) {
        this.shop = shop;
    }

    /**
     * Adds a wall to the map.
     * @param w the wall to add
     */
    public void add(Wall w) {
        walls.add(w);
    }

    /**
     * Adds an enemy to the map.
     * @param e the enemy to add
     */
    public void add(Enemy e) {
        enemies.add(e);
    }

    /**
     * Adds a chest to the map.
     * @param c the chest to add
     */
    public void add(Chest c) {
        chests.add(c);
    }

    /**
     * Returns the list of walls.
     * @return list of walls
     */
    public ArrayList<Wall> getW() {
        return walls;
    }

    /**
     * Returns the list of enemies.
     * @return list of enemies
     */
    public ArrayList<Enemy> getE() {
        return enemies;
    }

    /**
     * Sets the player entity.
     * @param player the player to set
     */
    public void setP(PlayerEntity player) {
        this.player = player;
    }

    /**
     * Returns the player entity.
     * @return the player
     */
    public PlayerEntity getP() {
        return player;
    }

    /**
     * Returns the previous attack zone tiles.
     * @return list of tiles
     */
    public ArrayList<Tile> getAZL() {
        return attackZoneLast;
    }

    /**
     * Sets the previous attack zone tiles.
     * @param azl the tiles to set
     */
    public void setAZL(ArrayList<Tile> azl) {
        this.attackZoneLast = azl;
    }

    /**
     * Sets the current attack zone tiles.
     * @param az the tiles to set
     */
    public void setAZ(ArrayList<Tile> az) {
        this.attackZone = az;
    }

    /**
     * Returns the current attack zone tiles.
     * @return list of tiles
     */
    public ArrayList<Tile> getAZ() {
        return attackZone;
    }

    /**
     * Returns the boss instance.
     * @return the boss
     */
    public Boss getB() {
        return b;
    }

    /**
     * Sets the boss instance.
     * @param b the boss to set
     */
    public void setB(Boss b) {
        this.b = b;
    }
    
    

    /**
	 * @return the attackZoneSpellLast
	 */
	public ArrayList<Tile> getAZSL() {
		return attackZoneSpellLast;
	}

	/**
	 * @param attackZoneSpellLast the attackZoneSpellLast to set
	 */
	public void setAZSL(ArrayList<Tile> attackZoneSpellLast) {
		this.attackZoneSpellLast = attackZoneSpellLast;
	}
	
	
	/**
	 * @return the lvlUp
	 */
	public int getLvlUp() {
		return lvlUp;
	}

	/**
	 * @param lvlUp the lvlUp to set
	 */
	public void setLvlUp(int lvlUp) {
		this.lvlUp = lvlUp;
	}

	/**
     * Advances the game to the next round.
     */
    public void nextRound() {
        t = t + 1;
        updateMaxStats();
        moveEnemy();
        regenMana();
        regenStam();
        enemyAttack();
        lootChest();
        death();
        levelUp();
    }
    
    /**
     * Iterates through walls to check if there's a wall at the specified tile.
     * @param t the tile to check
     * @return true if there's a wall, false otherwise
     */
    public Boolean iterWall(Tile t) {
        Iterator<Wall> iter = walls.iterator();
        while (iter.hasNext()) {
            Tile tile = iter.next().getPosition();
            if (tile.getLine() == t.getLine() && tile.getColumn() == t.getColumn()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Moves the player left if possible (no wall in the way).
     */
    public void moveLeftPlayer() {
        Tile position = player.getPosition();
        Tile wantedPosition = map.getTile(position.getLine(), position.getColumn() - 1);

        if (iterWall(wantedPosition) == false) {
            player.setPosition(wantedPosition);
            player.setLM(0);
        }
    }

    /**
     * Moves the player right if possible (no wall in the way).
     */
    @Override
    public void moveRightPlayer() {
        Tile position = player.getPosition();
        Tile wantedPosition = map.getTile(position.getLine(), position.getColumn() + 1);

        if (iterWall(wantedPosition) == false) {
            player.setPosition(wantedPosition);
            player.setLM(1);
        }
    }

    /**
     * Moves the player up if possible (no wall in the way).
     */
    @Override
    public void moveUpPlayer() {
        Tile position = player.getPosition();
        Tile wantedPosition = map.getTile(position.getLine() - 1, position.getColumn());

        if (iterWall(wantedPosition) == false) {
            player.setPosition(wantedPosition);
            player.setLM(2);
        }
    }

    /**
     * Moves the player down if possible (no wall in the way).
     */
    @Override
    public void moveDownPlayer() {
        Tile position = player.getPosition();
        Tile wantedPosition = map.getTile(position.getLine() + 1, position.getColumn());

        if (iterWall(wantedPosition) == false) {
            player.setPosition(wantedPosition);
            player.setLM(3);
        }
    }
    
    /**
     * Executes movement for all enemies.
     */
    public void moveEnemy() {
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy e = enemies.get(i);
            if (t % e.getStats().getEnemyStats().get(1).getValue() == 0) {
                enemies.remove(i);
                int move = Utility.getRandomNumber(0, 4);
                switch (move) {
                    case 0:
                        Tile l = new Tile(e.getPosition().getLine(), e.getPosition().getColumn() - 1);
                        if (iterWall(l) == false) {
                            e.setPosition(l);
                            e.setLM(0);
                        }
                        break;
                    case 1:
                        Tile r = new Tile(e.getPosition().getLine(), e.getPosition().getColumn() + 1);
                        if (iterWall(r) == false) {
                            e.setPosition(r);
                            e.setLM(1);
                        }
                        break;
                    case 2:
                        Tile u = new Tile(e.getPosition().getLine() - 1, e.getPosition().getColumn());
                        if (iterWall(u) == false) {
                            e.setPosition(u);
                            e.setLM(2);
                        }
                        break;
                    case 3:
                        Tile d = new Tile(e.getPosition().getLine() + 1, e.getPosition().getColumn());
                        if (iterWall(d) == false) {
                            e.setPosition(d);
                            e.setLM(3);
                        }
                        break;
                }
                enemies.add(i, e);
            }
        }
    }

    /**
     * Executes the player's attack action.
     */
    public void attack() {
        int stam = player.getStats().getPlayerStats().get(6).getValue();
        int stamCost = player.getStats().getPlayerWeapon().getItemStats().get(1).getValue();
        int dmg = player.getStats().getPlayerWeapon().getItemStats().get(0).getValue();
        if (stam >= stamCost) {
            stam -= stamCost;
            player.getStats().getPlayerStats().get(6).setValue(stam);
            Tile position = player.getPosition();
            int LM = player.getLM();
            int rangeFwd = player.getStats().getPlayerWeapon().getRangeFwd();
            int rangeSide = player.getStats().getPlayerWeapon().getRangeSide();
            switch (LM) {
                case 0: {
                    for (int i = 1; i <= rangeFwd; i++) {
                        attackZone.add(new Tile(position.getLine(), position.getColumn() - i));
                    }
                    for (int i = 1; i <= rangeSide; i++) {
                        attackZone.add(new Tile(position.getLine() - i, position.getColumn() - 1));
                        attackZone.add(new Tile(position.getLine() + i, position.getColumn() - 1));
                    }
                    break;
                }
                case 1: {
                    for (int i = 1; i <= rangeFwd; i++) {
                        attackZone.add(new Tile(position.getLine(), position.getColumn() + i));
                    }
                    for (int i = 1; i <= rangeSide; i++) {
                        attackZone.add(new Tile(position.getLine() - i, position.getColumn() + 1));
                        attackZone.add(new Tile(position.getLine() + i, position.getColumn() + 1));
                    }
                    break;
                }
                case 2: {
                    for (int i = 1; i <= rangeFwd; i++) {
                        attackZone.add(new Tile(position.getLine() - i, position.getColumn()));
                    }
                    for (int i = 1; i <= rangeSide; i++) {
                        attackZone.add(new Tile(position.getLine() - 1, position.getColumn() - i));
                        attackZone.add(new Tile(position.getLine() - 1, position.getColumn() + i));
                    }
                    break;
                }
                case 3: {
                    for (int i = 1; i <= rangeFwd; i++) {
                        attackZone.add(new Tile(position.getLine() + i, position.getColumn()));
                    }
                    for (int i = 1; i <= rangeSide; i++) {
                        attackZone.add(new Tile(position.getLine() + 1, position.getColumn() - i));
                        attackZone.add(new Tile(position.getLine() + 1, position.getColumn() + i));
                    }
                    break;
                }
            }
            for (Tile tile : attackZone) {
                attackZoneLast.add(tile);
                ArrayList<Enemy> toRemove = new ArrayList<Enemy>();
                Iterator<Enemy> iter = enemies.iterator();
                while (iter.hasNext()) {
                    Enemy e = iter.next();
                    if (tile.getLine() == e.getPosition().getLine() && tile.getColumn() == e.getPosition().getColumn()) {
                        if (e.getStats().getEnemyStats().get(0).getValue() - dmg > 0) {
                            e.getStats().getEnemyStats().get(0).setValue(e.getStats().getEnemyStats().get(0).getValue() - dmg);
                        } else {
                            toRemove.add(e);
                        }
                    }
                }
                if (b != null) {
                    if (tile.getLine() == b.getPosition().getLine() && tile.getColumn() == b.getPosition().getColumn()) {
                        if (b.getStats().getEnemyStats().get(0).getValue() - dmg > 0) {
                            b.getStats().getEnemyStats().get(0).setValue(b.getStats().getEnemyStats().get(0).getValue() - dmg);
                        } else {
                            b = null;
                        }
                    }
                }
                for (Enemy e : toRemove) {
                    lootEnemy(e);
                    enemies.remove(e);
                }
                toRemove.clear();
            }
        }
        attackZone.clear();
    }
    
    /**
     * Processes loot dropped by an enemy.
     * @param e the enemy to loot
     */
    public void lootEnemy(Enemy e) {
        player.getStats().setGold(player.getStats().getGold() + e.getStats().getEnemyGold());
        player.getStats().setXp(player.getStats().getXp() + e.getStats().getEnemyXp());
        if (e.getStats().getEnemyLoot() != null) {
            for (Item item : e.getStats().getEnemyLoot()) {
                player.getStats().getInventory().add(item);
            }
        }
    }

    /**
     * Updates the maximum stats of the player.
     */
    public void updateMaxStats() {
        int maxHP = (player.getStats().getPlayerStats().get(2).getValue()) * 5;
        for (int i = 0; i < 4; i++) {
            maxHP += player.getStats().getEquipements().get(i).getItemStats().get(0).getValue();
        }
        player.getStats().getPlayerStats().get(1).setValue(maxHP);
        if (player.getStats().getPlayerStats().get(0).getValue() > player.getStats().getPlayerStats().get(1).getValue()) {
            player.getStats().getPlayerStats().get(0).setValue(maxHP);
        }
        int maxMana = (player.getStats().getPlayerStats().get(5).getValue()) * 5;
        for (int i = 0; i < 4; i++) {
            maxMana += player.getStats().getEquipements().get(i).getItemStats().get(1).getValue();
        }
        player.getStats().getPlayerStats().get(4).setValue(maxMana);
        if (player.getStats().getPlayerStats().get(3).getValue() > player.getStats().getPlayerStats().get(4).getValue()) {
            player.getStats().getPlayerStats().get(3).setValue(maxMana);
        }
        int maxStam = (player.getStats().getPlayerStats().get(8).getValue()) * 5;
        for (int i = 0; i < 4; i++) {
            maxStam += player.getStats().getEquipements().get(i).getItemStats().get(2).getValue();
        }
        player.getStats().getPlayerStats().get(7).setValue(maxStam);
        if (player.getStats().getPlayerStats().get(6).getValue() > player.getStats().getPlayerStats().get(7).getValue()) {
            player.getStats().getPlayerStats().get(6).setValue(maxStam);
        }
    }

    /**
     * Regenerates the player's mana.
     */
    public void regenMana() {
        if (t % 2 == 0) {
            int mana = player.getStats().getPlayerStats().get(3).getValue();
            int maxMana = (player.getStats().getPlayerStats().get(4).getValue());
            if (mana < maxMana) {
                mana = mana + 1;
                player.getStats().getPlayerStats().get(3).setValue(mana);
            }
        }
    }

    /**
     * Regenerates the player's stamina.
     */
    public void regenStam() {
        if (t % 2 == 0) {
            int stam = player.getStats().getPlayerStats().get(6).getValue();
            int maxStam = (player.getStats().getPlayerStats().get(7).getValue());

            if (stam < maxStam) {
                stam = stam + 1;
                player.getStats().getPlayerStats().get(6).setValue(stam);
            }
        }
    }

    /**
     * Executes the player's use action (e.g., using a potion).
     */
    public void use() {
        if (player.getStats().getEquipements().get(4) instanceof Potion) {
            usedPotion = player.getStats().getEquipements().get(4);
            Thread potionThread = new Thread(this);
            potionThread.start();
            player.getStats().getEquipements().set(4, ItemFactory.rienp());
        }
    }

    /**
     * Entry point for thread execution when using an item (e.g., a potion).
     */
    public void run() {
        String name = usedPotion.getItemStats().get(0).getName();
        int effect = usedPotion.getItemStats().get(0).getValue();
        int duration = usedPotion.getItemStats().get(1).getValue();
        while (duration > 0) {
            try {
                Thread.sleep(GameConfig.GAME_SPEED);
                duration--;
                switch (name) {
                    case "hp": {
                        if (player.getStats().getPlayerStats().get(0).getValue() + effect <= player.getStats().getPlayerStats().get(1).getValue()) {
                            int val = player.getStats().getPlayerStats().get(0).getValue();
                            val += effect;
                            player.getStats().getPlayerStats().get(0).setValue(val);
                        } else {
                            player.getStats().getPlayerStats().get(0).setValue(player.getStats().getPlayerStats().get(1).getValue());
                        }
                        break;
                    }
                    case "mana": {
                        if (player.getStats().getPlayerStats().get(3).getValue() + effect <= player.getStats().getPlayerStats().get(4).getValue()) {
                            int val = player.getStats().getPlayerStats().get(3).getValue();
                            val += effect;
                            player.getStats().getPlayerStats().get(3).setValue(val);
                        } else {
                            player.getStats().getPlayerStats().get(3).setValue(player.getStats().getPlayerStats().get(4).getValue());
                        }
                        break;
                    }
                    case "stamina": {
                        if (player.getStats().getPlayerStats().get(6).getValue() + effect <= player.getStats().getPlayerStats().get(7).getValue()) {
                            int val = player.getStats().getPlayerStats().get(6).getValue();
                            val += effect;
                            player.getStats().getPlayerStats().get(6).setValue(val);
                        } else {
                            player.getStats().getPlayerStats().get(6).setValue(player.getStats().getPlayerStats().get(7).getValue());
                        }
                        break;
                    }
                    case "imortality":
                            player.getStats().getPlayerStats().get(0).setValue(player.getStats().getPlayerStats().get(1).getValue());
                        break;
                }
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
    }
    
    /**
     * Executes attack actions for all enemies.
     */
    public void enemyAttack() {
        attackZoneE.clear();
        attackZoneELast.clear();
        for (Enemy e : enemies) {
            Tile position = e.getPosition();
            int rangeFwd = e.getStats().getEnemyStats().get(3).getValue();
            int rangeSide = e.getStats().getEnemyStats().get(4).getValue();
            int dmg = e.getStats().getEnemyStats().get(2).getValue();
            switch (e.getLM()) {
                case 0: {
                    for (int i = 0; i <= rangeFwd; i++) {
                        attackZoneE.add(new Tile(position.getLine(), position.getColumn() - i));
                    }
                    for (int i = 1; i <= rangeSide; i++) {
                        attackZoneE.add(new Tile(position.getLine() - i, position.getColumn() - 1));
                        attackZoneE.add(new Tile(position.getLine() + i, position.getColumn() - 1));
                    }
                    break;
                }
                case 1: {
                    for (int i = 0; i <= rangeFwd; i++) {
                        attackZoneE.add(new Tile(position.getLine(), position.getColumn() + i));
                    }
                    for (int i = 1; i <= rangeSide; i++) {
                        attackZoneE.add(new Tile(position.getLine() - i, position.getColumn() + 1));
                        attackZoneE.add(new Tile(position.getLine() + i, position.getColumn() + 1));
                    }
                    break;
                }
                case 2: {
                    for (int i = 0; i <= rangeFwd; i++) {
                        attackZoneE.add(new Tile(position.getLine() - i, position.getColumn()));
                    }
                    for (int i = 1; i <= rangeSide; i++) {
                        attackZoneE.add(new Tile(position.getLine() - 1, position.getColumn() - i));
                        attackZoneE.add(new Tile(position.getLine() - 1, position.getColumn() + i));
                    }
                    break;
                }
                case 3: {
                    for (int i = 0; i <= rangeFwd; i++) {
                        attackZoneE.add(new Tile(position.getLine() + i, position.getColumn()));
                    }
                    for (int i = 1; i <= rangeSide; i++) {
                        attackZoneE.add(new Tile(position.getLine() + 1, position.getColumn() - i));
                        attackZoneE.add(new Tile(position.getLine() + 1, position.getColumn() + i));
                    }
                    break;
                }
            }
            for (Tile tile : attackZoneE) {
                attackZoneELast.add(tile);
                if (tile.getLine() == player.getPosition().getLine() && tile.getColumn() == player.getPosition().getColumn()) {
                    if (player.getStats().getPlayerStats().get(0).getValue() - dmg > 0) {
                        player.getStats().getPlayerStats().get(0).setValue(player.getStats().getPlayerStats().get(0).getValue() - dmg);
                    } else {
                        player.getStats().getPlayerStats().get(0).setValue(0);
                    }
                }
            }
            attackZoneE.clear();
        }
    }

    /**
     * Removes an item from the player's inventory.
     * @param i the item to remove
     */
    public void dropItem(Item i) {
        ArrayList<Item> inv = player.getStats().getInventory();
        inv.remove(i);
        player.getStats().setInventory(inv);
    }

    /**
     * Causes the player to equip an item.
     * @param i1 the item to equip
     */
    public void equipItem(Item i1) {
        ArrayList<Item> inv = player.getStats().getInventory();
        ArrayList<Item> equip = player.getStats().getEquipements();
        inv.remove(i1);
        int t = i1.getType();
        switch (t) {
            case (0):
            case (1):
            case (2):
            case (3):
            case (4): {
                Item i2 = equip.get(t);
                equip.set(t, i1);
                if (i2.getType() == 6 || (i2.getType() == 4 && i2.getName().equals("rien"))) {
                } else {
                    inv.add(i2);
                }
                player.getStats().setEquipements(equip);
                player.getStats().setInventory(inv);
                break;
            }
            case (5): {
                Item i2 = player.getStats().getPlayerWeapon();
                player.getStats().setPlayerWeapon((Weapon) i1);
                if (i2.getType() != 6) {
                    inv.add(i2);
                }
                player.getStats().setInventory(inv);
                break;
            }
        }
    }

    /**
     * Causes the player to unequip an item.
     * @param i the item to unequip
     */
    public void unequipItem(Item i) {
        ArrayList<Item> inv = player.getStats().getInventory();
        ArrayList<Item> equip = player.getStats().getEquipements();
        int t = i.getType();
        switch (t) {
            case (0):
            case (1):
            case (2):
            case (3): {
                equip.set(t, ItemFactory.rien());
                if (i.getType() == 6) {
                } else {
                    inv.add(i);
                }
                player.getStats().setEquipements(equip);
                player.getStats().setInventory(inv);
                break;
            }
            case (4): {
                equip.set(t, ItemFactory.rienp());
                if (i.getType() == 4 && i.getName().equals("rien")) {
                } else {
                    inv.add(i);
                }
                break;
            }
            case (5): {

                break;
            }
        }
    }

    /**
     * Processes loot found in a chest.
     */
    public void lootChest() {
    	
        int px = player.getPosition().getLine();
        int py = player.getPosition().getColumn();
        ArrayList<Chest> toRemove = new ArrayList<>();
        for (Chest c : chests) {
            if (c.getPosition().getLine() == py && c.getPosition().getColumn() == px) {
                player.getStats().setGold(player.getStats().getGold() + c.getChestGold());
                if (c.getChestLoot() != null) {
                    for (Item item : c.getChestLoot()) {
                        player.getStats().getInventory().add(item);
                    }
                }
                toRemove.add(c);
            }
        }
        chests.removeAll(toRemove);
    }

    /**
     * Checks if the player can access the shop.
     * @return true if shop is accessible
     */
    public boolean shopAccess() {
        int px = player.getPosition().getLine();
        int py = player.getPosition().getColumn();
        if (shop.getPosition().getLine() == py && shop.getPosition().getColumn() == px) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Buys an item from the shop.
     * @param item the item to buy
     */
    public void buyItem(Item item) {
        if (player.getStats().getGold() >= item.getPrice()) {
            player.getStats().setGold(player.getStats().getGold() - item.getPrice());
            player.getStats().getInventory().add(item);
            shop.setShopGold(shop.getShopGold() + item.getPrice());
            shop.getStock().remove(item);
        } else {
        }
    }

    /**
     * Sells an item to the shop.
     * @param item the item to sell
     */
    public void sellItem(Item item) {
        if (shop.getShopGold() >= item.getPrice()) {
            player.getStats().setGold(player.getStats().getGold() + (item.getPrice() / 2));
            player.getStats().getInventory().remove(item);
            shop.getStock().add(item);
            shop.setShopGold(shop.getShopGold() - (item.getPrice() / 2));
        }
    }
    public void useSpell(Spell s) {
    	int type=s.getStat().getType();
    	switch(type) {
    	case 0:
    		healingSpell(s);
    		break;
    	case 1:
    		attackSpell(s);
    		break;
    	}
    }
    public void healingSpell(Spell s) {
    	int spellNumber=s.getSpellnumber();
    	switch(spellNumber) {
    	case 9:
    		int hp= player.getStats().getPlayerStats().get(0).getValue();
            int maxHp = (player.getStats().getPlayerStats().get(1).getValue());

            if (hp < maxHp-6) {
                hp = hp + 6;
                player.getStats().getPlayerStats().get(0).setValue(hp);
            }
            else if (hp > maxHp-6) {
            	hp = maxHp;
                player.getStats().getPlayerStats().get(0).setValue(hp);
            }
    		break;
    	case 10:
    		hp= player.getStats().getPlayerStats().get(0).getValue();
            maxHp = (player.getStats().getPlayerStats().get(1).getValue());

            if (hp < maxHp-12) {
                hp = hp + 6;
                player.getStats().getPlayerStats().get(0).setValue(hp);
            }
            else if (hp > maxHp-12) {
            	hp = maxHp;
                player.getStats().getPlayerStats().get(0).setValue(hp);
                
            }
    		break;
    	case 11:
    		usedPotion=ItemFactory.ImortalitySpell();
    		Thread imortalityThread = new Thread(this);
            imortalityThread.start();
    		break;
    	case 12:
    		if(secondChance==2) {
    			secondChance=1;
    		}
    		break;
    	}
    }
    public void attackSpell(Spell s) {
    	int mana = player.getStats().getPlayerStats().get(3).getValue();
        int manaCost = s.getStat().getStats().get(1).getValue();
        int dmg = s.getStat().getStats().get(0).getValue();
        if (mana >= manaCost) {
        	mana -= manaCost;
            player.getStats().getPlayerStats().get(3).setValue(mana);
            for (Tile tile : s.getStat().getAoe()) {
            	attackZoneSpell.add(tile);
            }
            for (Tile tile : attackZoneSpell) {
                attackZoneSpellLast.add(tile);
                ArrayList<Enemy> toRemove = new ArrayList<Enemy>();
                Iterator<Enemy> iter = enemies.iterator();
                while (iter.hasNext()) {
                    Enemy e = iter.next();
                    if (tile.getLine() == e.getPosition().getLine() && tile.getColumn() == e.getPosition().getColumn()) {
                        if (e.getStats().getEnemyStats().get(0).getValue() - dmg > 0) {
                            e.getStats().getEnemyStats().get(0).setValue(e.getStats().getEnemyStats().get(0).getValue() - dmg);
                        } else {
                            toRemove.add(e);
                        }
                    }
                }
                if (b != null) {
                    if (tile.getLine() == b.getPosition().getLine() && tile.getColumn() == b.getPosition().getColumn()) {
                        if (b.getStats().getEnemyStats().get(0).getValue() - dmg > 0) {
                            b.getStats().getEnemyStats().get(0).setValue(b.getStats().getEnemyStats().get(0).getValue() - dmg);
                        } else {
                            b = null;
                        }
                    }
                }
                for (Enemy e : toRemove) {
                    lootEnemy(e);
                    enemies.remove(e);
                }
                toRemove.clear();
            }
        }
        attackZoneSpell.clear();
    }
    public void levelUp() {
    	if(player.getStats().getXp()>=5) {
    		player.getStats().setXp(player.getStats().getXp()-5);
    		player.getStats().setLevel(player.getStats().getLevel()+1);
    		lvlUp=1;
    	}
    }
    public void increaseLife(){
    	int stat=player.getStats().getPlayerStats().get(2).getValue();
    	player.getStats().getPlayerStats().get(2).setValue(stat+1);
        stat=player.getStats().getPlayerStats().get(0).getValue();
        player.getStats().getPlayerStats().get(0).setValue(stat+5);
    }
    public void increaseMana(){
    	int stat=player.getStats().getPlayerStats().get(5).getValue();
    	player.getStats().getPlayerStats().get(5).setValue(stat+1);
        stat=player.getStats().getPlayerStats().get(3).getValue();
        player.getStats().getPlayerStats().get(3).setValue(stat+5);
    }
    public void increaseStam(){
    	int stat=player.getStats().getPlayerStats().get(8).getValue();
    	player.getStats().getPlayerStats().get(8).setValue(stat+1);
        stat=player.getStats().getPlayerStats().get(6).getValue();
        player.getStats().getPlayerStats().get(6).setValue(stat+5);
    }
    public void death() {
    	if (player.getStats().getPlayerStats().get(0).getValue()==0) {
			if(secondChance==1) {
				player.getStats().getPlayerStats().get(0).setValue(player.getStats().getPlayerStats().get(1).getValue());
				secondChance=0;
			}
			else {
				player.getStats().getPlayerStats().get(0).setValue(9999);
				GameGUI.death=1;

			}
    	}
    }
}
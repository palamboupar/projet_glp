package gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import config.GameConfig;
import engine.map.Map;
import engine.process.GameBuilder;
import engine.process.MobileInterface;

public class FakeTmpGUI extends JFrame implements Runnable{
	
	private static final long serialVersionUID = 1L;
	private Map map;
	private MobileInterface manager;

	public FakeTmpGUI(String title) {
		super(title);
		init();
	}

	private void init() {

		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		KeyControls keyControls = new KeyControls();
		JTextField textField = new JTextField();
		textField.addKeyListener(keyControls);
		contentPane.add(textField, BorderLayout.SOUTH);

		map = GameBuilder.buildMap();
		manager = GameBuilder.buildInitMobile(map);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		setResizable(false);
	}
	public void run() {
		while (true) {
			try {
				Thread.sleep(GameConfig.GAME_SPEED);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}

			manager.nextRound();
		}
	}
	private class KeyControls implements KeyListener {

		@Override
		public void keyPressed(KeyEvent event) {
			char keyChar = event.getKeyChar();
			switch (keyChar) {
			case 'q':
				manager.moveLeftPlayer();
				break;
			case 'd':
				manager.moveRightPlayer();
				break;
			case 'z':
				manager.moveUpPlayer();
				break;
			case 's':
				manager.moveDownPlayer();
				break;
			default:
				break;
			}
		}

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
}

package engine.map;

/**
 * class for the map
 * started : 29/01/2025
 * last modified : 30/01/2025
 * @author PALEOLOGOS amael & BOUCHELAGHEM Ali
 * @version 0.1
 * 
 */

public class Map {
	private Tile[][]tiles;
	
	private int lineCount;
	private int columnCount;
	
	public Map(int lineCount, int columnCount) {
		init(lineCount, columnCount);

		for (int lineIndex = 0; lineIndex < lineCount; lineIndex++) {
			for (int columnIndex = 0; columnIndex < columnCount; columnIndex++) {
				tiles[lineIndex][columnIndex] = new Tile(lineIndex, columnIndex);
			}
		}
		for (int lineIndex=0;lineIndex < lineCount; lineIndex++) {
			Tile t=tiles[lineIndex][0];
			t.setState(2);
			tiles[lineIndex][0]=t;
			t=tiles[lineIndex][columnCount-1];
			t.setState(2);
			tiles[lineIndex][columnCount-1]=t;
		}
		for (int columnIndex = 0; columnIndex < columnCount; columnIndex++) {
			Tile t=tiles[0][columnIndex];
			t.setState(2);
			tiles[0][columnIndex]=t;
			t=tiles[lineCount-1][columnIndex];
			t.setState(2);
			tiles[lineCount-1][columnIndex]=t;
		}
	}
	private void init(int lineCount, int columnCount) {
		this.lineCount = lineCount;	
		this.columnCount = columnCount;

		tiles = new Tile[lineCount][columnCount];
		
	
	}
	public Tile getTile(int line, int column) {
		return tiles[line][column];
	}

	//pour la classe test
	public String toString() {
		String str="";
		
		for (int lineIndex = lineCount-1; lineIndex >=0; lineIndex--) {
			for (int columnIndex = 0; columnIndex < columnCount; columnIndex++) {
				str+=tiles[lineIndex][columnIndex]+" ";
			}
			str+="\n";
		}
		return str;
	}
	
}

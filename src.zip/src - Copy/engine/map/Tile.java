package engine.map;

/**
 * class for the tiles
 * started : 29/01/2025
 * last modified : 30/01/2025
 * @author PALEOLOGOS amael & BOUCHELAGHEM Ali
 * @version 0.1
 * 
 */

public class Tile {
	private int line;
	private int column;
	private int state;

	public Tile(int line, int column) {
		this.line = line;
		this.column = column;
		this.state=1;
	}

	public int getLine() {
		return line;
	}

	public int getColumn() {
		return column;
	}

	public void setState(int state) {
		this.state = state;
	}
	public int getState() {
		return state;
	}

	public String toString() {
		switch (state) {
			case 1://tile
				return "□";
			case 2://wall
				return "■";
			case 3://player
				return "▲";
			case 4://enemy
				return "⬤";
			case 5://chest
				return "▣";
			default://default(tile)
				return "□";
				
		}
		
	}
	public String toString1() {
		return "Block [line=" + line + ", column=" + column + "]";
	}

}

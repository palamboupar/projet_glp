package engine.mobile;

import engine.map.Tile;
/**
 * class for the player system
 * started : 27/01/2025
 * last modified : 29/01/2025
 * @author PALEOLOGOS amael
 * @version 0.11
 * 
 */

public class Player extends MobileElement{
	
	public Player(Tile position) {
		super(position);
	}
}
	
/**
 * 
 */
package engine.mobile;

import engine.map.Tile;

/**
 * abstract class for the diferent type of moving objects
 * started : 29/01/2025
 * last modified : 29/01/2025
 * @author PALEOLOGOS amael
 * @version 0.1
 * 
 */

public abstract class MobileElement {
	private Tile position;

	public MobileElement(Tile position) {
		this.position = position;
	}

	public Tile getPosition() {
		return position;
	}

	public void setPosition(Tile position) {
		this.position = position;
	}

}
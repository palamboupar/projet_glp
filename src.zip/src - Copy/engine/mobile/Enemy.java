package engine.mobile;

import engine.map.Tile;

/**
 * abstract class for the enemy system
 * started : 29/01/2025
 * last modified : 29/01/2025
 * @author PALEOLOGOS amael
 * @version 0.1
 * 
 */
public abstract class Enemy extends MobileElement {
	
	public Enemy(Tile position) {
		super(position);
	}

}

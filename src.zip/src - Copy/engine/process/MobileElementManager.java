package engine.process;

import engine.map.Map;
import engine.map.Tile;
import engine.mobile.Player;

/**
 * class for the map
 * started : 30/01/2025
 * last modified : 30/01/2025
 * @author PALEOLOGOS amael & BOUCHELAGHEM Ali
 * @version 0.1
 * 
 */
public class MobileElementManager implements MobileInterface {
	private Map map;
	private Player player;
	
	public MobileElementManager(Map map) {
		this.map = map;
	}
	@Override
	public void set(Player player) {
		this.player=player;
		
	}
	@Override
	public Player getP() {
		return player;
	}
	@Override
	public void moveLeftPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine(), position.getColumn() - 1);

		if (wantedPosition.getState()!=2) {
			position.setState(1);
			player.setPosition(wantedPosition);
			wantedPosition.setState(3);
		}

	}

	@Override
	public void moveRightPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine(), position.getColumn() + 1);

		if (wantedPosition.getState()!=2) {
			position.setState(1);
			player.setPosition(wantedPosition);
			wantedPosition.setState(3);
		}
	}
	@Override
	public void moveUpPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine()+1, position.getColumn());

		if (wantedPosition.getState()!=2) {
			position.setState(1);
			player.setPosition(wantedPosition);
			wantedPosition.setState(3);
		}
	}
	@Override
	public void moveDownPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine()-1, position.getColumn() );

		if (wantedPosition.getState()!=2) {
			position.setState(1);
			player.setPosition(wantedPosition);
			wantedPosition.setState(3);
		}
	}
	public void nextRound() {
		System.out.println(map.toString());
	}
}

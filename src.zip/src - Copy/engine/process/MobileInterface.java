package engine.process;

import engine.mobile.Player;

public interface MobileInterface {
	void set(Player player);

	Player getP();

	void moveLeftPlayer();

	void moveRightPlayer();

	void moveUpPlayer();

	void moveDownPlayer();
	
	void nextRound();
}

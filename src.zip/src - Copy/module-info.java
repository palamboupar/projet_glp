/**
 * 
 */
/**
 * 
 */
module GLP_RPG {
	requires java.desktop;
}
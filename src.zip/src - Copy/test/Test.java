package test;

import gui.FakeTmpGUI;
public class Test {

	/**public static void main (String[]args) {
		Map map=GameBuilder.buildMap();
		System.out.println(map.toString());
		MobileInterface manager = GameBuilder.buildInitMobile(map);
		System.out.println(map.toString());
		manager.moveLeftPlayer();
		System.out.println(map.toString());
		manager.moveRightPlayer();
		System.out.println(map.toString());
		manager.moveDownPlayer();
		System.out.println(map.toString());
		manager.moveUpPlayer();
		System.out.println(map.toString());
		manager.moveUpPlayer();
		System.out.println(map.toString());
		**/
		
	public static void main (String[]args) {
		Runnable game = new FakeTmpGUI("test");
		Thread gameThread = new Thread(game);
		gameThread.start();
			
	}
}
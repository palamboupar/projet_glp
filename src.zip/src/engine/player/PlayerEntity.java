package engine.player;

import engine.map.Tile;

public class PlayerEntity {
	private Tile position;
	
	public PlayerEntity(Tile position) {
		this.position=position;
	}

	public Tile getPosition() {
		return position;
	}
	
	public void setPosition(Tile position) {
		this.position=position;
	}
}

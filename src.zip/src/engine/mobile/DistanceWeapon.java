package engine.mobile;

import engine.map.Tile;

public class DistanceWeapon extends MobileElement{
	public DistanceWeapon(Tile position) {
		super(position);
	}
}

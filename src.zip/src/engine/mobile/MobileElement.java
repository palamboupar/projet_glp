package engine.mobile;

import engine.map.Tile;

public abstract class MobileElement {
	private Tile position;
	
	public MobileElement(Tile position) {
		this.position=position;
	}
	public Tile getPosition() {
		return position;
	}

	public void setPosition(Tile position) {
		this.position = position;
	}
}

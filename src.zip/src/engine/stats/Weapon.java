package engine.stats;

import java.util.ArrayList;

public class Weapon extends Item {
	
	public Weapon(String name, ArrayList<Stat> itemStats, int price) {
		super(name, itemStats, price);
	}
}

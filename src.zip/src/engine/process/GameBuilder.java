package engine.process;

import config.GameConfig;
import engine.map.Tile;
import engine.map.Map;
import engine.player.PlayerEntity;

/**
 * class for the map
 * started : 30/01/2025
 * last modified : 30/01/2025
 * @author PALEOLOGOS Amael & BOUCHELAGHEM Ali
 * @version 0.1
 * 
 */
public class GameBuilder {
	public static Map buildMap() {
		return new Map(GameConfig.LINE_COUNT, GameConfig.COLUMN_COUNT);
	}
	public static MobileInterface buildInitMobile(Map map) {
		MobileInterface manager = new MobileElementManager(map);
		
		intializePlayer(map, manager);
		
		return manager;
	}

	private static void intializePlayer(Map map, MobileInterface manager) {
		Tile tile = map.getTile(GameConfig.LINE_COUNT - 2, (GameConfig.COLUMN_COUNT - 1) / 2);
		PlayerEntity player = new PlayerEntity(tile);
		manager.setP(player);
	}


}

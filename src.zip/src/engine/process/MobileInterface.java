package engine.process;

import engine.player.PlayerEntity;

public interface MobileInterface {

	void setP(PlayerEntity player);

	void moveLeftPlayer();

	void moveRightPlayer();
	
	void moveUpPlayer();
	
	void moveDownPlayer();
}

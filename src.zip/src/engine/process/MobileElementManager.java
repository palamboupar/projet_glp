package engine.process;

import java.util.ArrayList;
import java.util.List;

import engine.map.*;
import engine.mobile.Enemy;
import engine.player.PlayerEntity;
import engine.staticObject.Wall;

/**
 * class for the map
 * started : 30/01/2025
 * last modified : 30/01/2025
 * @author PALEOLOGOS amael & BOUCHELAGHEM Ali
 * @version 0.1
 * 
 */
public class MobileElementManager implements MobileInterface {
	private Map map;
	private List<Wall> walls = new ArrayList<Wall>();
	private PlayerEntity player;
	private List<Enemy> enemies = new ArrayList<Enemy>();
	
	public MobileElementManager(Map map) {
		this.map = map;
	}
	
	public void setP(PlayerEntity player) {
		this.player=player;
	}
	public void moveLeftPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine(), position.getColumn() - 1);

		if (wantedPosition.getState()!=2) {
			position.setState(1);
			player.setPosition(wantedPosition);
			wantedPosition.setState(3);
		}

	}

	@Override
	public void moveRightPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine(), position.getColumn() + 1);

		if (wantedPosition.getState()!=2) {
			position.setState(1);
			player.setPosition(wantedPosition);
			wantedPosition.setState(3);
		}
	}
	@Override
	public void moveUpPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine()+1, position.getColumn());

		if (wantedPosition.getState()!=2) {
			position.setState(1);
			player.setPosition(wantedPosition);
			wantedPosition.setState(3);
		}
	}
	@Override
	public void moveDownPlayer() {
		Tile position = player.getPosition();
		Tile wantedPosition = map.getTile(position.getLine()-1, position.getColumn() );

		if (wantedPosition.getState()!=2) {
			position.setState(1);
			player.setPosition(wantedPosition);
			wantedPosition.setState(3);
		}
	}
}
